CREATE TABLE [versionHistory] (
[id] INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,
[version] VARCHAR(16) NULL,
[date] VARCHAR(16) NULL,
[revisor] VARCHAR(16) NULL,
[info] VARCHAR(128) NULL
);

INSERT INTO versionHistory values (1, '1.00', '2011-10-20', 'z00164626', 'add default linesettings; add version table.');


CREATE TABLE [mobilesetting] (
[id] INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,
[handsetid] INTEGER  NULL,
[name] VARCHAR(16)  NULL,
[hansetType] INTEGER  NULL,
[interceptable] INTEGER  NULL
);

CREATE TABLE [lanmap] (
[id] INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,
[name] VARCHAR(64)  NULL,
[mac] VARCHAR(32)  NULL,
[flag] INTEGER  NULL,
[setflag] INTEGER  NULL
);

CREATE TABLE [callrecord] (
[id] INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,
[handsetid] INTEGER  NULL,
[number] VARCHAR(32)  NULL,
[name] VARCHAR(32)  NULL,
[datetime] TIMESTAMP  NULL,
[linename] VARCHAR(32)  NULL,
[lineid] INTEGER  NULL,
[flags] INTEGER  NULL
);

CREATE TABLE [contact] (
[id] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
[name] VARCHAR(32)  NULL,
[fstname] VARCHAR(32)  NULL,
[num1] VARCHAR(32)  NULL,
[num1flag] INTEGER  NULL,
[num2] VARCHAR(32)  NULL,
[num2flag] INTEGER  NULL,
[num3] VARCHAR(32)  NULL,
[num3flag] INTEGER  NULL,
[numreserved] VARCHAR(32)  NULL,
[melody] INTEGER  NULL,
[lineid] INTEGER  NULL
);

CREATE TABLE [dectsetting] (
[id] INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,
[flags] INTEGER  NULL,
[pin] VARCHAR(8)  NULL,
[addr] VARCHAR(16)  NULL,
[netmask] VARCHAR(16)  NULL,
[gateway] VARCHAR(16)  NULL,
[dnsserver] VARCHAR(16)  NULL,
[firmwareVer] VARCHAR(8)  NULL,
[eepromVer] VARCHAR(8)  NULL,
[hardwareVer] VARCHAR(8)  NULL
);

CREATE TABLE [internalnames] (
[id] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
[number] INTEGER  NULL,
[name] VARCHAR(32)  NULL
);

CREATE TABLE [linesetting] (
[id] INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
[name] VARCHAR(32)  NULL,
[lineid] INTEGER  NULL,
[usable] INTEGER  NULL,
[bitmap] INTEGER  NULL,
[dialprefix] VARCHAR(32)  NULL,
[melody] INTEGER  NULL,
[fpvolume] INTEGER  NULL,
[mulcallmode] INTEGER  NULL,
[intrucall] INTEGER  NULL,
[clirValue] INTEGER  NULL,
[clirActcode] VARCHAR(32)  NULL,
[clirDeActcode] VARCHAR(32)  NULL,
[cfuValue] INTEGER  NULL,
[cfuActcode] VARCHAR(32)  NULL,
[cfuDeActcode] VARCHAR(32)  NULL,
[cfuNum] VARCHAR(32)  NULL,
[cfnrValue] INTEGER  NULL,
[cfnrSec] INTEGER  NULL,
[cfnrActcode] VARCHAR(32)  NULL,
[cfnrDeActcode] VARCHAR(32)  NULL,
[cfnrNum] VARCHAR(32)  NULL,
[cfbValue] INTEGER  NULL,
[cfbActcode] VARCHAR(32)  NULL,
[cfbDeActcode] VARCHAR(32)  NULL,
[cfbNum] VARCHAR(32)  NULL,
[blocked] VARCHAR(252)  NULL
);

CREATE VIEW [allcall] AS 
select * from callrecord;

CREATE VIEW [acceptedcall] AS 
select * from callrecord where flags=0;

CREATE VIEW [missedcall] AS 
select * from callrecord where flags=2 or flags=3;

CREATE VIEW [outcall] AS 
select * from callrecord where flags=1;

INSERT INTO linesetting values (27, 'ISDN',   27, 1, 31, '', 0, 0, 1, 0, 0, '', '', 0, '', '', '', 0, 0, '', '', '', 0, '', '', '', '');
INSERT INTO linesetting values (28, 'PSTN',   28, 1, 31, '', 0, 0, 0, 0, 0, '', '', 0, '', '', '', 0, 0, '', '', '', 0, '', '', '', '');
INSERT INTO linesetting values (29, 'CS',     29, 0, 31, '', 0, 0, 0, 0, 1, '', '', 0, '', '', '', 0, 0, '', '', '', 0, '', '', '', '');
INSERT INTO linesetting values (30, 'INCALL', 30, 0, 31, '', 0, 0, 1, 0, 0, '', '', 0, '', '', '', 0, 0, '', '', '', 0, '', '', '', '');

