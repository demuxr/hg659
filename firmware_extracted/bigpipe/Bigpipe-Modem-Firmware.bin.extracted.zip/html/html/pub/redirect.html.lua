
--lua_content_for__ include begin
 web.print('\
<!-- fake for iphone internet detect -->\
<!-- <HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML> -->\
');  html.lang('wizard_res.js')  web.print('\
');  html.lang('pin_res.js')  web.print('\
');  html.lang('wan_res.js')  web.print('\
');  html.lang('user_login_res.js')  web.print('\
');  html.script('/lib/base64.js')  web.print('\
');  html.script('/js/pin.js')  web.print('\
');  html.script('/js/link.js')  web.print('\
');  html.script('/js/wizardwan.js')  web.print('\
');  html.script('/js/pvcscan.js')  web.print('\
'); 
--lua_content_end__
 web.print('\
\
'); 
--lua_content_for__ script_tag begin
 web.print('\
<!-- fake for iphone internet detect -->\
<!-- <HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML> -->\
<script language="JavaScript" type="text/javascript">\
$(document).ready(function() {\
    pageload();\
    $("#home_menu").live("click",function() {\
		showLoginWindow();\
		go_aim = 2;\
    });\
    $("#internet_settings_menu").live("click",function(){\
		showLoginWindow();\
		go_aim =3;\
    });\
    $("#homenetwork_settings_menu").live("click",function(){\
		showLoginWindow();\
		go_aim = 4\
    });\
    $("#sharing_settings_menu").live("click",function(){\
		showLoginWindow();\
		go_aim =5;\
    });\
    $("#maintain_settings_menu").live("click",function(){\
		showLoginWindow();\
		go_aim = 6;\
    });\
    $("#index_window").live("click",function(){\
        $("#output_login").addClass("hide");\
        $("#output_login").hide();\
    });\
});\
\
</script>\
\
'); 
--lua_content_end__
 web.print('\
<div class="row rounddiv wizard_config_div">\
    {{view Atp.InternetWizardHeader}}\
    <div id="contentPage">\
        <div class="internet_config">\
            {{view Atp.DetectContainerView}}\
        </div>\
    </div>\
</div>\
\
'); 