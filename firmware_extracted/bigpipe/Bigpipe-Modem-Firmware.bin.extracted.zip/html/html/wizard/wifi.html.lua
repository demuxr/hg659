
--lua_content_for__ include begin
 web.print('\
');  html.lang('wizard_res.js')  web.print('\
');  html.lang('wlan_res.js')  web.print('\
');  html.lang('user_login_res.js')  web.print('\
');  html.script('/js/wlan.js')  web.print('\
');  html.script('/lib/customInput.jquery.js')  web.print('\
');  html.script('/js/wizard.js')  web.print('\
'); 
--lua_content_end__
 web.print('\
\
'); 
--lua_content_for__ script_tag begin
 web.print('\
<script language="JavaScript" type="text/javascript">\
function pageload(controller) {\
    // Load single controller\
    if (controller) {\
        controller.load(controller.loadFinished);\
        return;\
    }\
    pageload(Atp.WlanObjs);\
}\
$(document).ready(function(){ \
    pageload();\
    $(\'input\').customInput();\
    $("#show24password").live("click",function() {\
        Atp.WlanObj.set("isShow24Password",false);\
        if (!!$("#show24password").attr("checked")) {\
            Atp.WlanObj.set("isShow24Password",true);\
        }\
        return ;\
    });\
\
    $("#show5password").live("click",function() {\
        Atp.Wlan5gObj.set("isShow5Password",false);\
        if (!!$("#show5password").attr("checked")) {\
            Atp.Wlan5gObj.set("isShow5Password",true);\
        }\
        return ;\
    });\
\
});\
</script>\
'); 
--lua_content_end__
 web.print('\
<div class="container">\
    <div class="row rounddiv wizard_config_div">\
        <div class="internet_top rounddiv"><div class="wifi_top_line_left rounddiv">&nbsp;</div></div>\
        <div class="wifi_logo paddingleft_20">\
            <div class="margintop_15 pull-left ic_mid_wifi ie6image" />\
            <div class="margintop_15 pull-left">\
                <div class="wifi_config_title fontsize_18 paddingleft_20"><div>{{t home.internet.operation}}</div><div class="margintop_10">{{t home.wifi.title}}</div></div>\
            </div>\
        </div>\
\
        <div class="wifi_notice">{{t home.wifi.passwordplace}}</div>\
        <div class="wifi_config">\
            {{view Atp.WifiTwo_Four_On_OFFView }}\
            <!--first part-->\
            {{view Atp.WifiTwo_Four_SsidView}}\
            <!--second part-->\
            {{view Atp.WifiFive_On_OFFView }}\
            {{view Atp.WifiFive_SsidView}}\
            <div class="marginleft_20"><label class="clearboth fontweight_thicker third_menu_below_config_font">{{t wlan.enc.beacon}}:</label></div>\
            {{view Atp.Wlan24EncryptView }}\
        </div>\
        <!--footer button-->\
        {{view Atp.WifiSaveSsidAndPasswordView}}\
    </div>\
</div>\
'); 