Atp.LoadHelper.appendLangRes("security_res.js");
Atp.LoadHelper.appendLangRes("application_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/application.js");
Atp.LoadHelper.appendJs("/js/security.js");

Atp.LoadHelper.loadAll();

Atp.NetworkSecurityContainerView = Atp.PageContainerView.extend ({
    prefixName: "security",
    dataView: Em.View.extend({
        template: Em.Handlebars.compile('\
            {{view Atp.FirewallCollapseView}} \
            {{view Atp.AclCollapseView}} \
            {{view Atp.DmzCollapseView}} \
            {{view Atp.AppFilterCollapseView}} \
            {{view Atp.LanDeviceWindowView id="security_landevice_window"}} \
            {{view Atp.ApplicationWindowView type=4 elementId="security_application_id"}}')
    })
    
});

Atp.MenuController.createSubmenuView(Atp.NetworkSecurityContainerView,"network_security");