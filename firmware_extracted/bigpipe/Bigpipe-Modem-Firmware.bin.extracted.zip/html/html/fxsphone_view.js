Atp.LoadHelper.appendLangRes("fxsphone_res.js");
Atp.LoadHelper.appendJs("/js/fxsphone.js");

Atp.LoadHelper.loadAll();

Atp.FxsPhoneContainer = Atp.PageContainerView.extend ({
    prefixName: 'fxsphone',
    pageload:function(){
        Atp.FxsFullListController.load(function() {
            Atp.FxsphoneController.load();
        });
    },
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.FxsListCollapseViewOne instanceId=0 isClosed=false LabelId="fxsphone_1" }} \
            {{ view Atp.FxsListCollapseViewTwo instanceId=1 LabelId="fxsphone_2" }} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.FxsPhoneContainer, "fxsphone");