Atp.LoadHelper.appendLangRes("diagnose_res.js");
Atp.LoadHelper.appendJs("/js/diagnose.js");

Atp.LoadHelper.loadAll();

Atp.DiagToolContainerView = Atp.PageContainerView.extend ({
    prefixName: 'diagnose_tools',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{view Atp.DiagnosePingSingleView}} \
            {{view Atp.DiagnoseTracerouteSingleView}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.DiagToolContainerView, "diagnose_tools");