require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.Line.{i}.", {"DirectoryNumber", "Status", "CallState"});

local lines = {}
if nil ~= values then
    for k, v in pairs(values) do
        local line = {}
        line.ID = k
        line.SipNumber  = v["DirectoryNumber"]
        line.LineStatus = v["Status"]
        line.CallStatus = v["CallState"]
        table.insert(lines, line)
    end
    utils.multiObjSortByID(lines)
end

web.print(json.encode(lines))
