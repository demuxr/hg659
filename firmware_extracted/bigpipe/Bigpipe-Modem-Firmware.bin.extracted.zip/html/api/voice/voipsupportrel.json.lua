local dm  = require('dm')
local web = require('web')
local json = require('json')

local voipsupport = {}

local err, Commonvalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", {"X_PrackSupport"})

local  Common_obj = Commonvalues["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig."]
voipsupport.Support100REL = utils.toboolean(Common_obj["X_PrackSupport"])
web.print(json.encode(voipsupport))