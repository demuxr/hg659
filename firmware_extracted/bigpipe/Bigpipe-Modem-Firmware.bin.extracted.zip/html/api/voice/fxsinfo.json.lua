require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.PhyInterface.{i}.", {"X_AttachedLineList"});

local PhyAttachedList = {}
for k,v in pairs(values) do
    local attachedlist_obj = {}
    attachedlist_obj.AttachedList = v["X_AttachedLineList"]
    attachedlist_obj.ID = k
    table.insert(PhyAttachedList, attachedlist_obj)
end
utils.multiObjSortByID(PhyAttachedList)
web.print(json.encode(PhyAttachedList))
