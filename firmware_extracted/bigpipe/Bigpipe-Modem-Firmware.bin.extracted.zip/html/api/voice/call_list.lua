local utils = require('utils')
require('web')

local log_type = 106496
if data == nil then
    local login_user, login_level = web.getuserinfo()
    err = web.clearlog(log_type, login_user)
    utils.appenderror("errcode", err);
end
