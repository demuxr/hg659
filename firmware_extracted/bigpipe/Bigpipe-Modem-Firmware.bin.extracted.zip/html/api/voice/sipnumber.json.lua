local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues

--first read all number
local sipmumbers = {}
local errcode,allaccount = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.Line.{i}.",{"DirectoryNumber"});
for k,v in pairs(allaccount) do
	local account = {}
	account["ID"] = k
	account["Number"] = v["DirectoryNumber"]
	table.insert(sipmumbers,account)
end

errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsEnable"})
if values ~= nil then
    local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
    umtsEnable = utils.toboolean(obj["X_UmtsEnable"])
end
if umtsEnable ~= nil and umtsEnable == true then
    local umts_obj = {}
    umts_obj["ID"] = "cs"
    umts_obj["Number"] = "CS"
    table.insert(sipmumbers, umts_obj)
end
web.print(json.encode(sipmumbers))