require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local profiles = {}

local err, Commonvalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", {"X_STC"})
if Commonvalues ~= nil then
    local  Common_obj = Commonvalues["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig."]
    stc = Common_obj["X_STC"]
end

if stc == 1 then
    local voice_profile = {}
    voice_profile.ID = "0"
    voice_profile.ProviderName = "Name"
    voice_profile.RegistrarServer = "RegistrarServer"
    voice_profile.Head = true
    voice_profile.ProxyServer = ""
    voice_profile.SipDomain = ""
    voice_profile.OutboundServer = ""
    voice_profile.OutboundServerPort = ""
    voice_profile.MainRegisterPort = ""
    voice_profile.MainProxyPort = ""
    voice_profile.SecondRegistrarServer = ""
    voice_profile.SecondRegistrarPort = ""
    voice_profile.SecondProxyServer = ""
    voice_profile.SecondProxyPort = ""
    voice_profile.UserAgentPort = "Local port"
    voice_profile.OutboundEnable = false
    voice_profile.UseSecondServer = false
    table.insert(profiles, voice_profile)
end

local err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.", {"Name"});

if values ~= nil then
    for k,v in pairs(values) do
        local voice_profile = {}
        voice_profile.ID = k
        voice_profile.ProviderName = v["Name"]
        
        if stc == 1 then
            voice_profile.Head = false
        end
        local errcode,each_sip = dm.GetParameterValues(k.."SIP.", {"ProxyServer", "RegistrarServer", "X_SIPDomain", "OutboundProxy", "ProxyServerPort", "RegistrarServerPort", "OutboundProxyPort", "X_SecondProxyServer", "X_SecondProxyServerPort", "X_SecondRegistrarServer", "X_SecondRegistrarServerPort", "UserAgentPort"});
        local each_sip_obj = each_sip[k.."SIP."]
        voice_profile.RegistrarServer = each_sip_obj["RegistrarServer"]
        voice_profile.ProxyServer = each_sip_obj["ProxyServer"]
        voice_profile.SipDomain = each_sip_obj["X_SIPDomain"]
        voice_profile.OutboundServer = each_sip_obj["OutboundProxy"]
        voice_profile.OutboundServerPort = each_sip_obj["OutboundProxyPort"]
        voice_profile.MainRegisterPort = each_sip_obj["RegistrarServerPort"]
        voice_profile.MainProxyPort = each_sip_obj["ProxyServerPort"]
        voice_profile.SecondRegistrarServer = each_sip_obj["X_SecondRegistrarServer"]
        voice_profile.SecondRegistrarPort = each_sip_obj["X_SecondRegistrarServerPort"]
        voice_profile.SecondProxyServer = each_sip_obj["X_SecondProxyServer"]
        voice_profile.SecondProxyPort = each_sip_obj["X_SecondProxyServerPort"]
        voice_profile.UserAgentPort = each_sip_obj["UserAgentPort"]
        if "" == each_sip_obj["OutboundProxy"] then
            voice_profile.OutboundEnable = false
        else
            voice_profile.OutboundEnable = true
        end
		
        if "" ~= each_sip_obj["X_SecondRegistrarServer"] or "" ~= each_sip_obj["X_SecondProxyServer"] then
            voice_profile.UseSecondServer = true
        else
            voice_profile.UseSecondServer = false
        end
        table.insert(profiles, voice_profile)
    end
    utils.multiObjSortByID(profiles)
end
web.print(json.encode(profiles))
