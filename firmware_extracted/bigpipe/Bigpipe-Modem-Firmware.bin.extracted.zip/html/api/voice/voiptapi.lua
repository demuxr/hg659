require('web')
require('dm')
local utils = require('utils')

local voip_common_maps = {
	TransGain="TransmitGain",
	RecepGain="ReceiveGain",
	FlashMinTime="MinHookFlash",
	FlashMaxTime="MaxHookFlash"
}

local voip_numplan_maps = {
	Shorttimeout="InterDigitTimerShort",
	Longtimeout="InterDigitTimerLong",
	DialingDuration="StartDigitTimerStd"
}

local paras = utils.GenSetObjParamInputs("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", data, voip_common_maps)
local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
utils.responseErrorcode(err, paramerr, voip_common_maps)
if errcode ~= 0 then
	utils.appenderror("errcode", 9003)
	return ;
end
local setting = utils.GenSetObjParamInputs("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.", data, voip_numplan_maps)
local err,needreboot, paramerror = dm.SetParameterValues(setting)
utils.responseErrorcode(err, paramerror, voip_numplan_maps)
if errcode ~= 0 then
	utils.appenderror("errcode", 9003)
	return ;
end
