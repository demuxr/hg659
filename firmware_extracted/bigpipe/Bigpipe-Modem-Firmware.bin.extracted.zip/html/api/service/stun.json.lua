require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.ManagementServer.",
    {
        "STUNEnable",
        "STUNServerAddress",
        "STUNServerPort",
        "STUNUsername",
        "STUNPassword",
        "STUNMaximumKeepAlivePeriod",
        "STUNMinimumKeepAlivePeriod",
        "X_StunConnectionRequestUsername",
        "X_StunConnectionRequestPassword",
    }
);

local obj = values["InternetGatewayDevice.ManagementServer."]

local stunCfg = {}

stunCfg.enable = utils.toboolean(obj["STUNEnable"])
stunCfg.url = obj["STUNServerAddress"]
stunCfg.min = obj["STUNMinimumKeepAlivePeriod"]
stunCfg.max = obj["STUNMaximumKeepAlivePeriod"]
stunCfg.name = obj["STUNUsername"]
stunCfg.pwd = utils.getdefaultPasswd(obj['STUNPassword'])
stunCfg.conname = obj["X_StunConnectionRequestUsername"]
stunCfg.conpwd = utils.getdefaultPasswd(obj['X_StunConnectionRequestPassword'])
stunCfg.port = obj["STUNServerPort"]

web.print(json.encode(stunCfg))