require('dm')
require('web')
require('json')
require('utils')

web.setpkgheadercontenttype("application/octect-stream")
web.setpkgheaderdesposition("attachment; filename=diagnostics_report.txt")
web.setpkgheadercachecontrol("must-revalidate")

local file  = "null"
local f = io.open("/var/diagnose_report", "r")
if f == nil then
    io.close()
else
    file = f:read("*a")
    f:close()
end

web.print(file)
