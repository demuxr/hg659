require('web')

web.print('{"interval":"5000"}'); 