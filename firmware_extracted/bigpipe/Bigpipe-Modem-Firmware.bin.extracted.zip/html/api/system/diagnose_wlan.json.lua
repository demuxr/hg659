require('dm')
require('utils')
require('web')
require('json')

local maps = {
	MACAddress = "MACAddress",
	PhyMode = "PhyMode",
	CodeType = "CodeType",
	BW = "BW",
	Rate = "Rate",
	RSSI = "RSSI",
	SNR = "SNR",
	CHT = "CHT",
	TxSuccPkt = "TxSuccPkt",
	ReTxPkt = "ReTxPkt",
	TxFailPkt = "TxFailPkt",
	RxSuccPkt = "RxSuccPkt",
	RxFailPkt = "RxFailPkt"
}

local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.WLANConfiguration.{i}.X_WLANDiagnostic.STAList.{i}.",
    maps)

utils.responseMultiObjects(lanVals, maps)

