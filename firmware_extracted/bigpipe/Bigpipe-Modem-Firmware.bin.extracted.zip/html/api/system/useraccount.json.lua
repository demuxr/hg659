require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.UserInterface.X_Web.UserInfo.{i}.",
    {
        "Username",
        "Userlevel",
        "EnablePasswdPrompt",
        "UserpasswdPrompt"
    }
);

local login_user, login_level = web.getuserinfo()
local allusers = {}

if login_level == 1 then		
	for k, v in pairs(values) do
		if login_user == v["Username"] then
		    local user = {}
		    user.username = v["Username"]
		    user.userlevel = v["Userlevel"]
		    user.enableprompt =  utils.toboolean(v["EnablePasswdPrompt"])
		    user.promptinfo = v["UserpasswdPrompt"]
		    user.ID = k
		    table.insert(allusers, user)
		    break
		end
	end
else
	for k, v in pairs(values) do
		-- Not display web user name only used in wan side
		    local user = {}
		    user.username = v["Username"]
		    user.userlevel = v["Userlevel"]
		    user.enableprompt =  utils.toboolean(v["EnablePasswdPrompt"])
		    user.promptinfo = v["UserpasswdPrompt"]
		    user.ID = k
		    table.insert(allusers, user)
	end
end

utils.multiObjSortByID(allusers)
web.print(json.encode(allusers))