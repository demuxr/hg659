require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,values= dm.GetParameterValues("InternetGatewayDevice.Time.",
    {"Enable", "Status", "NTPServer1", "NTPServer2", "CurrentLocalTime", "LocalTimeZoneName", "X_Label"})
obj = values["InternetGatewayDevice.Time."];

local sntp = {}
sntp.Enable = utils.toboolean(obj["Enable"])
sntp.Status = obj["Status"]
if obj["NTPServer1"] == "" then
    sntp.NTPServer1 = "None"
else
    sntp.NTPServer1 = obj["NTPServer1"]
end
if obj["NTPServer2"] == "" then
    sntp.NTPServer2 = "None"
else
    sntp.NTPServer2 = obj["NTPServer2"]
end

sntp.CurrentLocalTime = obj["CurrentLocalTime"]
sntp.LocalTimeZoneName = obj["LocalTimeZoneName"]
sntp.TimeZoneIdx = obj["X_Label"]

web.print(json.encode(sntp))