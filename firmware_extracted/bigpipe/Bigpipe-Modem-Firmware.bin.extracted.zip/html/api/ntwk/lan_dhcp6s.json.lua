    require('dm')
    require('web')
    require('json')
    require('utils')
    local tostring = tostring

    local errcode,dhcp6s = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.", 
        {"DHCPServerEnable", "UseAllocatedWAN", "Prefix", "PrefixLength", 
          "Preferredlifetime", "Validlifetime", "DNSServer", "DomainName"});

    function get_DNS_Server_Address(DNSServer)
        
        if DNSServer == nil then
            return "",""
        end

        local start = string.find(DNSServer,",")
        local secondDnsServer = ""
        local firstDnsServer  = ""

        if start == nil  then
            return DNSServer, ""
        else
            firstDnsServer = string.sub(DNSServer, 1, start - 1)
            secondDnsServer = string.sub(DNSServer, start + 1,string.len(DNSServer))
            return firstDnsServer,secondDnsServer   
        end
    end    

    local Dhcp6s = {}
    for k,v in pairs(dhcp6s) do 
        Dhcp6s.ID = k
        Dhcp6s.DHCPServerEnable = utils.toboolean(v["DHCPServerEnable"])
        Dhcp6s.UseAllocatedWAN = v["UseAllocatedWAN"]
        Dhcp6s.Prefix = v["Prefix"]
        Dhcp6s.PrefixLength = v["PrefixLength"]
        Dhcp6s.Preferredlifetime = v["Preferredlifetime"]
        Dhcp6s.Validlifetime = v["Validlifetime"]
        Dhcp6s.Dhcp6sDNSServerone, Dhcp6s.Dhcp6sDNSServertwo = get_DNS_Server_Address(v["DNSServer"])
        Dhcp6s.DomainName = v["DomainName"]        
    end
 web.print(json.encode(Dhcp6s))