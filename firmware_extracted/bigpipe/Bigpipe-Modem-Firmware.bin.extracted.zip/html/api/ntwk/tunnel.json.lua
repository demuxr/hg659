require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local searchWanOnly = false
local res = {}

-- Init Tunnel result
res.Enable = false
res.LowerLayer = ""
res.TunnelType = "6rd"
res.ConnStatus = "Disconnected"
-- For all
res.AutoMode = true
res.PeerAddr = ""
-- For 6rd only
res.IPv4MaskLen = 0
res.PrefixLen = 16
res.Prefix = ""
-- For 6to4 only
res.DnsServers = ""
-- For GRE only
res.IPv4Enable = true
res.IPv6Enable = false

-- Check if it is DSLite tunnel
local errcode,v4in6Tunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.V4in6Tunnel.{i}.",
            {"Activated", "AssociatedWanIfName",
             "Mechanism", "Dynamic", "RemoteIpv6Address", "ConnStatus"})
if v4in6Tunnels then
    for k,v in pairs(v4in6Tunnels) do
        res.Enable = utils.toboolean(v["Activated"])
        res.LowerLayer = v["AssociatedWanIfName"]
        res.TunnelType = v["Mechanism"]
        res.AutoMode = utils.toboolean(v["Dynamic"])
        res.PeerAddr = v["RemoteIpv6Address"]
        res.ConnStatus = v["ConnStatus"]
        web.print(json.encode(res))
        return
    end
end

-- Check if it is 6to4 or 6rd tunnel
local errcode,v6in4Tunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.V6in4Tunnel.{i}.",
            {"Activated", "AssociatedWanIfName", "Mechanism", "Dynamic",
             "IPv4MaskLen", "Prefix", "6rdPrefixLength",
             "BorderRelayAddress", "IPv6DnsServers", "ConnStatus"})
if v6in4Tunnels then
    for k,v in pairs(v6in4Tunnels) do
        res.Enable = utils.toboolean(v["Activated"])
        res.LowerLayer = v["AssociatedWanIfName"]
        res.TunnelType = v["Mechanism"]
        res.AutoMode = utils.toboolean(v["Dynamic"])
        res.PeerAddr = v["BorderRelayAddress"]
        res.IPv4MaskLen = v["IPv4MaskLen"]
        res.PrefixLen = v["6rdPrefixLength"]
        res.Prefix = v["Prefix"]
        res.DnsServers = v["IPv6DnsServers"]
        res.ConnStatus = v["ConnStatus"]
        web.print(json.encode(res))
        return
    end
end

local errcode,GRETunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.GRE.{i}.",
            {"Activated", "AssociatedWanIfName", "IPv4Enable",
             "IPv6Enable", "TunnelEndpoint", "ConnStatus"})
if GRETunnels then
    for k,v in pairs(GRETunnels) do
        res.Enable = utils.toboolean(v["Activated"])
        res.LowerLayer = v["AssociatedWanIfName"]
        res.TunnelType = "GRE"
        res.PeerAddr = v["TunnelEndpoint"]
        res.IPv4Enable = utils.toboolean(v["IPv4Enable"])
        res.IPv6Enable = utils.toboolean(v["IPv6Enable"])
        res.ConnStatus = v["ConnStatus"]
    end
end

web.print(json.encode(res))
