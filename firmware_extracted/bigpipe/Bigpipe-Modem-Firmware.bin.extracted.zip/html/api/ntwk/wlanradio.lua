require('dm')
require('web')
require('json')
require('utils')

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "OperatingFrequencyBand"
    }
);

local domain2G = ''
local domain5G = ''

for k, v in pairs(wifiConf) do
    if "2.4GHz" == v["OperatingFrequencyBand"] then
        domain2G = k
    end
    if "5GHz" == v["OperatingFrequencyBand"] then
        domain5G = k
    end
end

local paras = {{domain2G..'Enable', data["Enable2G"]}, 
                {domain5G..'Enable', data["Enable5G"]}
            }

local maps = {
    Enable2G = domain2G..'Enable',
    Enable5G = domain5G..'Enable',
}

local errcode , NeedReboot, paramerr = dm.SetParameterValues(paras)
utils.responseErrorcode(errcode, paramerr, maps)

