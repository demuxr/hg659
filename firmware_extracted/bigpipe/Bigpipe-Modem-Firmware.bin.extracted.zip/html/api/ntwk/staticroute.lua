require('web')
require('dm')
local utils = require('utils')

local staticroute_maps = {
    destip="DestIPAddress",
    destsnmask = "DestSubnetMask",
    srcip = "SourceIPAddress",
    srcsnmask = "SourceSubnetMask",
    gatewayip = "GatewayIPAddress",
    interface = "Interface",
    metric = "ForwardingMetric",
    mtu = "MTU",
}

local errcode,all_staticroute = dm.GetParameterValues("InternetGatewayDevice.Layer3Forwarding.Forwarding.{i}.", {"Enable"})

-- Return domainname of first ddns entry
function get_first_entry(all_sr)
    if not all_sr then
        return ""
    end

    for k,v in pairs(all_sr) do
        return k
    end
    return ""
end

function add_one_staticroute_parameter(paras, name, value, domain)
    local newName = domain..name
    table.insert(paras, {newName, value})
end

function build_staticroute_parameters(data, domain)
    local paras = {}

    add_one_staticroute_parameter(paras, "DestIPAddress", data["destip"], domain)
    add_one_staticroute_parameter(paras, "DestSubnetMask", data["destsnmask"], domain)
    add_one_staticroute_parameter(paras, "SourceIPAddress", data["srcip"], domain)
    add_one_staticroute_parameter(paras, "SourceSubnetMask", data["srcsnmask"], domain)
    add_one_staticroute_parameter(paras, "Interface", data["interface"], domain)
    add_one_staticroute_parameter(paras, "ForwardingMetric", data["metric"], domain)
    add_one_staticroute_parameter(paras, "MTU", data["mtu"], domain)
    if "" ~= data["gatewayip"] then
        add_one_staticroute_parameter(paras, "GatewayIPAddress", data["gatewayip"], domain)
    end
    return paras
end

if action == 'create' then
    local srdomain = get_first_entry(all_staticroute)
    local paras = build_staticroute_parameters(data, srdomain)
    errcode,instId,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Layer3Forwarding.Forwarding.", paras)
    if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, staticroute_maps)
        return errcode
    end
    utils.appenderror("errcode", 0)
end

if action == "update" then
    local srdomain = data["ID"]
    local param = utils.GenSetObjParamInputs(srdomain, data, staticroute_maps)
    local err,needreboot, paramerror = dm.SetParameterValues(param);
    utils.responseErrorcode(err, paramerror, staticroute_maps)
end

if action == 'delete' then
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 10)
    end
end
