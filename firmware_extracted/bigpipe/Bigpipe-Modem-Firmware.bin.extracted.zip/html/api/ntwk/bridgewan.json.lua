require('dm')
require('utils')

local tostring = tostring
local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    });
local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    });

local connections = {}

for k,v in pairs(pppCon) do
    local con = {}
    local flag = 1
    con.ID = string.sub(k, 1, string.len(k)-1)
    con.Name = v["Name"]
    if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
        con.Name = v["X_WanAlias"]
    end
    if "IPTV WAN Connection" == v["X_WanAlias"] then
        flag = 0
    end
    if 1 == flag then
        table.insert(connections, con)
    end
end

for k,v in pairs(ipCon) do
    local con = {}
    local flag = 1
    con.ID = string.sub(k, 1, string.len(k)-1)
    con.Name = v["Name"]
    if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
        con.Name = v["X_WanAlias"]
    end
    if "IPTV WAN Connection" == v["X_WanAlias"] then
        flag = 0
    end
    if 1 == flag then
        table.insert(connections, con)
    end
end

function getwanname(id, interfaceAlias)
    for k, v in pairs(connections) do
        if id == v["ID"] then
            return v["Name"]
        end
    end

    return interfaceAlias
end

local errcode, interfaces = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias", "InterfaceType", "AvailableInterfaceKey"})

local intfs = {}
for k, v in pairs(interfaces) do
    if "LANInterface" ~= v["InterfaceType"] then
        local interface = {}
        interface.ID = k
        interface.InterfaceID = v["InterfaceReference"]
        interface.InterfaceName = getwanname(v["InterfaceReference"], v["X_InterfaceAlias"])
        interface.InterfaceType = v["InterfaceType"]
        
        table.insert(intfs, interface)
        end
end

utils.multiObjSortByID(intfs)
web.print(json.encode(intfs))

