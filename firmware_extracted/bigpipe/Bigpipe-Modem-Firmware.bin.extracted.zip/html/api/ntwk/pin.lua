local utils = require('utils')
local tostring = tostring
local web = require('web')

local action = data["action"]

local errcode = 0

if "puk" == action then
	errcode = web.operatePUK(data["PUKCode"], data["newPIN"]);
	if 0 ~= errcode then
		utils.appenderror("pin.PUKCode", "pin.puk_err")
	end
else
	errcode = web.operatePIN(action, data["PINCode"], data["newPIN"])
	if 0 ~= errcode then
		utils.appenderror("pin.PUKCode", "pin.pin_err")
	end
end

utils.appenderror("errcode", errcode)
