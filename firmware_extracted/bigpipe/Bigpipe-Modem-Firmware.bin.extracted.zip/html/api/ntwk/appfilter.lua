local utils = require('utils')
require('dm')
local string = string

local maps = {
	RuleName="Name",
	Enable = "Enable",
	Devices = "DevMac",
	Applications = "ApplicationIDs",
}

function GetMacAddress()
	local mac = ''
	for k,v in pairs(data["Devices"]) do
		for k1, value in pairs(v) do
			mac = mac..value..'|'
		end
	end
	return string.sub(mac, 1, string.len(mac)-1)
end

function GetApplications()
	local mac = ''
	for k,v in pairs(data["Applications"]) do
		for k1, value in pairs(v) do
			mac = mac..value..'|'
		end
	end
	return string.sub(mac, 1, string.len(mac)-1)
end

function create()
	-- add 
	data["Devices"] = GetMacAddress()
	data["Applications"] = GetApplications()
	data["Enable"] = utils.booleantoint(data["Enable"])

	local paras = utils.GenAddObjParamInputs(data, maps)
	local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.X_FireWall.DevRule.", paras);
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]

	data["Devices"] = GetMacAddress()
	data["Applications"] = GetApplications()
	data["Enable"] = utils.booleantoint(data["Enable"])

	local paras = utils.GenSetObjParamInputs(domain, data, maps)

	local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)