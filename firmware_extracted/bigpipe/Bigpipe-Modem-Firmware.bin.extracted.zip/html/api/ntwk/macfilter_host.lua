local utils = require('utils')
require('dm')
local string = string
local print = print

function delete_mac_from_str(str, mac)
	ip,fp = string.find(str, mac)
	if ip == nil then
		return str
	end

	if ip == 1 then
		return string.sub(str, fp+2)
	end

	return string.sub(str, 1, ip-2) .. string.sub(str, fp+1)
end

function add_mac_to_str(str, mac)
	if string.len(str) == 0 then
		return mac
	end

	return str ..'|'..mac
end

function delete_device_from_all_rules(mac)
	local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.TimeRule.{i}.", {"DevMac"});
	for k, v in pairs(objs) do
		newDevMac = delete_mac_from_str(v["DevMac"], mac)
		dm.SetParameterValues({{k.."DevMac", newDevMac}})
	end
end

function add_to_rule(id, mac)
	local errcode, objs = dm.GetParameterValues(id, {"DevMac"});
	if objs ~= nil then
		value = objs[id]
		errcode = dm.SetParameterValues({{id.."DevMac", add_mac_to_str(value["DevMac"], mac)}, {id.."Enable", true}})
	end

	return errcode
end

local err = delete_device_from_all_rules(data["MACAddress"])

if data["ParentControlEnable"] then
	err = add_to_rule(data["MacFilterID"], data["MACAddress"])
end

utils.appenderror("errcode", err)
