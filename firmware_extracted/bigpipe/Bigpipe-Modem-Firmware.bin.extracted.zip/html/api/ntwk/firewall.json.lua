require('dm')
require('web')
require('json')
require('utils')

local firewall = {}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.", {"CurrentLevel"});
local obj = values["InternetGatewayDevice.X_FireWall."]
firewall.CurrentLevel = obj["CurrentLevel"]
firewall.SetLevel = obj["CurrentLevel"]

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.DosAttack.", 
    {"SynFlooding", "IcmpFlooding", "ArpAttack"});

local obj = values["InternetGatewayDevice.DosAttack."]

firewall.IcmpFlooding = utils.toboolean(obj["IcmpFlooding"])
firewall.SynFlooding = utils.toboolean(obj["SynFlooding"])
firewall.ArpAttack = utils.toboolean(obj["ArpAttack"])


web.print(json.encode(firewall))

