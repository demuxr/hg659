local utils = require('utils')

local domain = "InternetGatewayDevice.X_VPN.L2TP_LAC."

local maps = {
	LACEnable="Enable",
	LNSAddress = "LNSAddress",
	HostName = "HostName",
	KeepAliveTime = "KeepAliveTime",
	PPPUsername = "PppUser",
	ConnectionMode = "ConnectionTrigger",
}

if data["TunnelPassword"] ~= _G["defaultPasswd"] then
	maps["TunnelPassword"] = "PassWord"
end

if data["PPPPassword"] ~= _G["defaultPasswd"] then
	maps["PPPPassword"] = "PppPass"
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
