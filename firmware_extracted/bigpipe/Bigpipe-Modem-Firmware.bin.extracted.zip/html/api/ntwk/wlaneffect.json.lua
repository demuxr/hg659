require('dm')
require('web')
require('json')
local _G = _G

local tostring = tostring
local wlaneffective = {}
wlaneffective.haseffective = true

	if  _G["wlantimes"] > 10 then
		_G["wlantimes"] = 0
		wlaneffective.haseffective = true
	else
		wlaneffective.haseffective = false
		_G["wlantimes"] = _G["wlantimes"] + 1
	end


web.print(json.encode(wlaneffective))
