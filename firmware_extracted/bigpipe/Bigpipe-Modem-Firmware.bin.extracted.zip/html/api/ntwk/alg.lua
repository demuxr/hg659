local utils = require('utils')
local print = print
--local data = utils.getRequestFormData()
local domain = "InternetGatewayDevice.Services.X_ALGAbility."

err,needreboot = dm.SetParameterValues({{domain.."PPTPEnable", data["PPTPEnable"]},
	{domain.."RTSPEnable", data["RTSPEnable"]},
	  	{domain.."H323Enable", data["H323Enable"]},
	  	{domain.."SIPPort", data["SIPPort"]},
	  	{domain.."SIPEnable", data["SIPEnable"]}
	    });

utils.appenderror("errcode", err);