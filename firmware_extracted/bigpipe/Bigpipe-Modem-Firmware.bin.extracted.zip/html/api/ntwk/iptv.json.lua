
require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType"})

local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    {"Name",
    "ConnectionType", "X_ServiceList", "NATEnabled", "ConnectionTrigger", 
     "X_IPv6Enable", "X_IPv4Enable", "Username"
    });
local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    {"Name",
    "ConnectionType", "X_ServiceList", "NATEnabled"
    , "X_IPv6Enable", "X_IPv4Enable"
    });

local errcode,bridges = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", 
    {"BridgeKey", "X_Type", "BridgeName"});
local errcode,filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.", 
    {"FilterBridgeReference", "FilterInterface"});
local errcode,intfs = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", 
    {"AvailableInterfaceKey", "InterfaceReference", "X_InterfaceAlias", "InterfaceType"});

local iptv = {}
iptv.LANAlias = ""
iptv.AccessType = "Ethernet"
iptv.AccessType = "VDSL"
iptv.AccessType = "DSL"
iptv.ConnectionType = "Bridged"
iptv.Username = ""
iptv.Password = _G["defaultPasswd"]
iptv.SnoopingEnable = true
iptv.ProxyEnable = false
iptv.ProxyWan = ""
iptv.PVC = "PVC:8/35"
iptv.VLANEnable = false
iptv.VLANId = 0
iptv.VLAN1p = 0
iptv.WANPath = ""

local br_key, br_path = utils.get_iptv_bridge(bridges)
if -1 == br_key then
	iptv.Enable = false
	web.print(json.encode(iptv))
	return
end

local wan_intf = ""

iptv.Enable = true
for k,v in pairs(filters) do
	if tostring(v["FilterBridgeReference"]) == tostring(br_key) then
		local binded_intf = utils.get_intf_by_key(intfs, v["FilterInterface"])
		if binded_intf then
			if "LANInterface" == binded_intf["InterfaceType"] then
				if "" ~= iptv.LANAlias then
					iptv.LANAlias = iptv.LANAlias..","
				end
				iptv.LANAlias = iptv.LANAlias..binded_intf["X_InterfaceAlias"]
			else
				wan_intf = binded_intf["InterfaceReference"]
			end
		end
	end
end

iptv.WANPath = wan_intf.."."

if "" ~= wan_intf then
	for k,v in pairs(pppCon) do
		if utils.strip_end_dot(k) == wan_intf then
			iptv.Username = v["Username"]
			utils.fill_access_info_by_ID(k, iptv, accessdevs);
			iptv.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
		end
	end

	for k,v in pairs(ipCon) do
		if utils.strip_end_dot(k) == wan_intf then
			utils.fill_access_info_by_ID(k, iptv, accessdevs);
			iptv.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
		end
	end

	local wanconndev = utils.get_wan_conn_dev_of_wan(wan_intf)
	local lowerlayer = utils.get_lowerlayer_by_wan(wan_intf)
	-- First update link data
	local newLink = lowerlayer
	if "" ~= lowerlayer and string.find(lowerlayer, "VLANTermination.") then
		iptv.VLANEnable = true
		lowerlayer = string.gsub(lowerlayer, "X_".."ATP".."_VLANTermination", "X_VLANTermination")
		print("Get vlan parameters for "..lowerlayer)
		local errcode,vlans = dm.GetParameterValues(lowerlayer, 
                {"LowerLayers", "VLANID", "802-1pMark"});
		iptv.VLANId = vlans[lowerlayer]["VLANID"]
		iptv.VLAN1p = vlans[lowerlayer]["802-1pMark"]
		wanconndev = vlans[lowerlayer]["LowerLayers"].."."
	end

	if "DSL" == iptv.AccessType then
		local errcode,pvcs = dm.GetParameterValues(wanconndev.."WANDSLLinkConfig.", 
                {"DestinationAddress"});
		iptv.PVC = pvcs[wanconndev.."WANDSLLinkConfig."]["DestinationAddress"]
	end
else
	iptv.Enable = false
end

web.print(json.encode(iptv))
