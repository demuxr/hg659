local utils = require('utils')

local maps = {
	SetLevel="CurrentLevel"
}
local param = utils.GenSetObjParamInputs("InternetGatewayDevice.X_FireWall.", data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param)
utils.responseErrorcode(err, paramerror, maps)

maps = {
	IcmpFlooding="IcmpFlooding",
	SynFlooding = "SynFlooding",
	ArpAttack = "ArpAttack"
}

data["IcmpFlooding"] = utils.booleantoint(data["IcmpFlooding"])
data["SynFlooding"] = utils.booleantoint(data["SynFlooding"])
data["ArpAttack"] = utils.booleantoint(data["ArpAttack"])

local param = utils.GenSetObjParamInputs("InternetGatewayDevice.DosAttack.", data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
