local utils = require('utils')

local profile_maps = {
        RemoteEndpoints     = 'RemoteEndpoints',
        RemoteDnsAddr       = 'X_RemoteDnsAddr',
        Protocol            = 'Protocol',
        PublicCert          = 'X_PublicCert',
        PrivateCert         = 'X_PrivateCert',
        RPublicCert         = 'X_RPublicCert',
        PHOneEncAlg         = 'IKEv2AllowedEncryptionAlgorithms',
        PHTwoEncAlg         = 'ESPAllowedEncryptionAlgorithms',
        PHOneAuthAlg        = 'IKEv2AllowedIntegrityAlgorithms',
        PHTwoAuthAlgAH      = 'AHAllowedIntegrityAlgorithms',
        PHTwoAuthAlgESP     = 'ESPAllowedIntegrityAlgorithms',
        PHOneDHGroup        = 'IKEv2AllowedDiffieHellmanGroupTransforms'
}

local filter_maps = {    
    FilterEnable        = 'Enable',
    Order               = 'Order',
    Alias               = 'Alias',
    Interface           = 'Interface',
    DestIP              = 'DestIP',
    DestMask            = 'DestMask',
    Srcmode             = 'X_SRCMODE',
    HostLists           = 'X_DEVMAC',
    SourceIP            = 'SourceIP',
    SourceMask          = 'SourceMask',
    Protocol            = 'Protocol',
    DestPort            = 'DestPort',
    SourcePort          = 'SourcePort',
    ProcessingChoice    = 'ProcessingChoice',
    Profile             = 'Profile'
}

for k,v in pairs(data['filters']) do
    print(k,v)
end

for k,v in pairs(data['profiles']) do
    print(k,v)
end

local profile_domain = ""
local profile_err = 0

data['profiles']['PublicCert']  = '/var/vpn/cert/pub.cert'
data['profiles']['PrivateCert'] = '/var/vpn/cert/priv.cert'
data['profiles']['RPublicCert'] = '/var/vpn/cert/rpub.cert'

if data['profiles']['ID'] == '' then
    local param = utils.GenAddObjParamInputs(data['profiles'], profile_maps)
    local errcode, instnum, NeedReboot, paraerrs = dm.AddObjectWithValues(
            "InternetGatewayDevice.X_VPN.IPsec.Profile.", param);
    --print('Add Profile+++++++++++++++++++++++Profile')
    print('responseErrorcode is', errcode)    
    utils.responseErrorcode(errcode, paraerrs, profile_maps)
    if errcode == 0 then
        profile_domain = "InternetGatewayDevice.X_VPN.IPsec.Profile."..instnum
    else
        profile_err = errcode
    end
else
    local param = utils.GenSetObjParamInputs(data['profiles']['ID'], data['profiles'], profile_maps)    
    local err,needreboot, paramerror = dm.SetParameterValues(param);
    --print('New set Profile+++++++++++++++++++++++Profile')
    print('Set responseErrorcode is', err)
    utils.responseErrorcode(err, paramerror, profile_maps)    
    profile_domain = string.sub(data['profiles']['ID'], 0, string.len(data['profiles']['ID']) - 1)
    profile_err = err
    --profile_domain = string.gsub(profile_domain, 'X_VPN', 'X_ATP_VPN')
end

if profile_err ~= 0 then
    return
end

--change mac address
function GetMacAddress(MacLists)
    if false == MacLists then
        return ""
    end
    local mac = ''
    for k,v in pairs(MacLists) do
        for k1, value in pairs(v) do
            mac = mac..value..'|'
        end
    end
    return string.sub(mac, 1, string.len(mac)-1)
end

data['filters']['Order']            = 1
data['filters']['Profile']          = profile_domain
data['filters']['HostLists']        = GetMacAddress(data['filters']['HostLists'])
data['filters']['Alias']            = "web_filter"
data['filters']['Interface']        = ""
data['filters']['DestIP']           = "0.0.0.0"
data['filters']['DestMask']         = "0.0.0.0"
data['filters']['Srcmode']          = false
data['filters']['Protocol']         = -1
data['filters']['DestPort']         = -1
data['filters']['SourcePort']       = -1
data['filters']['ProcessingChoice'] = "Protect"

if data['filters']['ID'] == '' then
    local param = utils.GenAddObjParamInputs(data['filters'], filter_maps)
    local errcode, new_profile, NeedReboot, errparams = dm.AddObjectWithValues(
            "InternetGatewayDevice.X_VPN.IPsec.Filter.", param);
    --print('Add filters+++++++++++++++++++++++filters')
    print('Add responseErrorcode is', errcode)
    utils.responseErrorcode(errcode, errparams, filter_maps)
else
    local param = utils.GenSetObjParamInputs(data['filters']['ID'], data['filters'], filter_maps)
    local err,needreboot, paramerror = dm.SetParameterValues(param);
    --print('Set filters+++++++++++++++++++++++filters')
    print('Set responseErrorcode is', err)
    utils.responseErrorcode(err, paramerror, filter_maps)
end