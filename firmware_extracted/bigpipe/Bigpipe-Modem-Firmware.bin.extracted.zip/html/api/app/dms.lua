require('web')
local utils = require('utils')

function add_one_para(paras, name, value)
    table.insert(paras, {name, value})
end

function check_dir_legal(dir)
    local pos = string.find(dir, '^/')
    if pos == nil then
        print("dir check error1 ")
        return false
    end

    pos = string.find(dir, '/%.$')
    if pos ~= nil then
        print("dir check error2 ")
        return false
    end

    pos = string.find(dir, '/%.%.$')
    if pos ~= nil then
        print("dir check error3 ")
        return false
    end

    pos = string.find(dir, '/%./')
    if pos ~= nil then
        print("dir check error4 ")
        return false
    end

    pos = string.find(dir, '/%.%./')
    if pos ~= nil then
        print("dir check error5 ")
        return false
    end

    pos = string.find(dir, "%.%.")
    if pos ~= nil then
        print("dir check error6 ")
        return false
    end
    return true
end

local paras = {}
local dmsdirs = data["dirs"]

add_one_para(paras, "InternetGatewayDevice.Services.X_DmsService.Enable", data["enable"])
add_one_para(paras, "InternetGatewayDevice.Services.X_DmsService.ShareAllPath", data["diropt"])
for i=1,10,1 do
    local cfgstr = "InternetGatewayDevice.Services.X_DmsService.Directory."..i.."."
    if i <= table.getn(dmsdirs) then
        add_one_para(paras, cfgstr.."Active", dmsdirs[i].active)
        add_one_para(paras, cfgstr.."ContentDirectory", dmsdirs[i].dir)
        add_one_para(paras, cfgstr.."ContentDirectoryUTF", dmsdirs[i].dirutf)
        local checkdir = check_dir_legal(dmsdirs[i].dirutf)
        if checkdir ~= true then
            utils.appenderror("errcode", 10)
            utils.appenderror("errdir", "dms.invaliddir")
            return
        end
    else
        add_one_para(paras, cfgstr.."Active", false)
        add_one_para(paras, cfgstr.."ContentDirectory", "")
        add_one_para(paras, cfgstr.."ContentDirectoryUTF", "")
    end
end
dm.SetParameterValues(paras)

if data["autodetect"] then
    web.setautodetectutf8("1", data["diropt"])
else
    web.setautodetectutf8("0", data["diropt"])
end

utils.responseErrorcode(0, nil, nil)
