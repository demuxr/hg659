require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber
local app = {}
local ID = nil

if FormData["ID"] ~= nil then
    ID = FormData["ID"]
end

if ID == nil then
    web.print(json.encode(app))
    return 
end

local domain = ID.."Content.{i}."

local maps = {
    Protocol = "Protocol",
    ExternalPort = "ExternalPort",
    ExternalPortEnd = "ExternalPortEnd",
    InternalPort = "InternalPort",
    InternalPortEnd = "InternalPortEnd"
}

local errcode, appVals = dm.GetParameterValues(domain, maps)

utils.responseMultiObjects(appVals, maps)

