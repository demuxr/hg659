
require('dm')
require('web')
require('json')
require('utils')
local qosclasses = {}
    local errcode, classVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Classification.{i}.", {"ClassificationName"});
if nil ~= classVals then
    for k,v in pairs(classVals) do
        local newClass = {}
        newClass["Name"] = v["ClassificationName"]
        table.insert(qosclasses, newClass)
    end
end
web.print(json.encode(qosclasses))