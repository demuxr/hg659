local utils = require('utils')

local print = print

local maps = {
	Enable="Enable",
	UpBandWidth = "X_BandWidth",
	DownBandWidth = "DownBandWidth",
	WmmEnable = "X_WmmEnable"
}

local params = utils.GenSetObjParamInputs("InternetGatewayDevice.QueueManagement.", data, maps)

local errcode,needreboot, paramerr = dm.SetParameterValues(params);
utils.responseErrorcode(errcode, paramerr, maps)

