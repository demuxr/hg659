local utils = require('utils')

if nil ~= data["SmbEnable"] then
	err,needreboot, paramerror = dm.SetParameterValues({
	    {"InternetGatewayDevice.Services.StorageService.1.NetworkServer.SMBEnable", data["SmbEnable"]}
	});
	utils.appenderror("errcode", err)
end

if nil ~= data["FtpEnable"] then
	err,needreboot, paramerror = dm.SetParameterValues({
	    {"InternetGatewayDevice.Services.StorageService.1.FTPServer.Enable", data["FtpEnable"]}
	});

	utils.appenderror("errcode", err)
end
