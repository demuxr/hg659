require('web')
require('dm')
local utils = require('utils')

local ID = data["ID"]
local username = data["Username"]
local pwd
local isallpath = data["AllPath"]
local iswrite = data["ReadOnly"]
local utf8dir = data["Path"]
local nativedir = data["Base64Path"]
local accountid = string.sub(ID, -2, -2)
if data["Password"] ~= _G["defaultPasswd"] then
    pwd = data["Password"]
else
    local errcode, values = dm.GetParameterValues(ID, {"Password"})
    pwd = values[ID]["Password"]
end

local enable
if data["Enable"] then
    enable = 1
else
    enable = 0
end

if utf8dir == "" then
    utf8dir = "/mnt"
end
if nativedir == "" then
    nativedir = "/mnt"
end
if isallpath == "1" then
    utf8dir = "/mnt"
    nativedir = "/mnt"
end

function get_oldfolder(domain)
    local start = string.find(domain, "UserAccess")
    local folder_domain = string.sub(domain, 1, start - 1)
    if folder_domain == nil then
        return "",""
    end

    local errcode, values = dm.GetParameterValues(folder_domain, { "Name" });
    local obj = values[folder_domain]

    return folder_domain, obj["Name"]
end

function get_username(id)
    local errcode, user_value = dm.GetParameterValues(id,{"Username"})
    local obj = user_value[id]
    return obj["Username"]
end

function check_dir_legal(dir)
    local pos = string.find(dir, '^/')
    if pos == nil then
        print("dir check error1 ")
        return false
    end

    pos = string.find(dir, '/%.$')
    if pos ~= nil then
        print("dir check error2 ")
        return false
    end

    pos = string.find(dir, '/%.%.$')
    if pos ~= nil then
        print("dir check error3 ")
        return false
    end

    pos = string.find(dir, '/%./')
    if pos ~= nil then
        print("dir check error4 ")
        return false
    end

    pos = string.find(dir, '/%.%./')
    if pos ~= nil then
        print("dir check error5 ")
        return false
    end

    pos = string.find(dir, "%.%.")
    if pos ~= nil then
        print("dir check error6 ")
        return false
    end
    return true
end



-- add usb user account
if ID == '' then
    local checkdir = check_dir_legal(utf8dir)
    if checkdir ~= true then
		utils.appenderror("Menu.tr140path", "Menu.ErrorTitle")
		utils.appenderror("errcode", 140)
        return
    end
    err,errstr = web.addusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, "0")
    if err ~= 0 then
        utils.appenderror("fs.storage.pwd", "Menu.ErrorTitle")
    end
    utils.appenderror("errcode", err)
    return
end

-- del and edit user account
local errcode, account_values = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.LogicalVolume.{i}.Folder.{i}.UserAccess.{i}.",
    {"UserReference"}
)
local errcode, oldaccounts = dm.GetParameterValues( ID, { "X_AllPath" } )
local oldaccount = oldaccounts[ID]
local oldallpath = oldaccount["X_AllPath"]
if action == 'delete' then
    local username = get_username(ID)
    if oldallpath == 1 then
        err, errstr = web.delusbuseraccess(accountid, "", "/mnt", username)
    else
        for k,v in pairs(account_values) do
            if ID == (v["UserReference"]..".") then
                local folderdomain, foldername = get_oldfolder(k)
                err, errstr = web.delusbuseraccess(accountid, folderdomain, foldername, username)
            end
        end
    end
    err = dm.DeleteObject(ID)
    utils.appenderror("errcode", err)
    return
end

if action ~= 'update' then
    utils.appenderror("errcode", 12)
    return
end

if string.len(utf8dir) > 64 then
    utils.appenderror("Menu.tr140path", "Menu.tr140path_err")
    utils.appenderror("errcode", 140)
    return
end

-- set user account
local checkdir = check_dir_legal(utf8dir)
    if checkdir ~= true then
    utils.appenderror("Menu.tr140path", "Menu.ErrorTitle")
    utils.appenderror("errcode", 140)
    return
end

if oldallpath == 1 then
	err, errstr = web.setusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, accountid, "", "/mnt")
	if err ~= 0 then
	   utils.appenderror("fs.storage.pwd", errstr)
	end
	utils.appenderror("errcode", err)
	return
else
	for k,v in pairs(account_values) do
		if ID == (v["UserReference"]..".") then
			local folderdomain, foldername = get_oldfolder(k)
			err, errstr = web.setusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, accountid, folderdomain, foldername)
			if err ~= 0 then
			   utils.appenderror("fs.storage.pwd", errstr)
			end
			utils.appenderror("errcode", err)
			return
		end
	end
	err, errstr = web.addusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, accountid)
	if err ~= 0 then
	   utils.appenderror("fs.storage.pwd", "Menu.ErrorTitle")
	end
	utils.appenderror("errcode", err)
	return
end

local accountstr = data["ID"]
err,needreboot, paramerror = dm.SetParameterValues ({
    {accountstr.."Enable", enable},
    {accountstr.."Username", username},
    {accountstr.."Password", pwd},
    {accountstr.."X_AllPath", isallpath},
    {accountstr.."X_Permissions", iswrite}
});

if paramerror ~= nil then
    for k,v in pairs(paramerror) do
        if k == ID..".Enable" then
            utils.appenderror("Enable", v)
        elseif k == ID..".Username" then
            utils.appenderror("Username", v)
        elseif k == ID..".Password" then
            utils.appenderror("Password", v)
        elseif k == ID..".X_AllPath" then
            utils.appenderror("AllPath", v)
        elseif k == ID..".X_Permissions" then
            utils.appenderror("ReadOnly", v)
        end
    end
end
utils.appenderror("errcode", err)
