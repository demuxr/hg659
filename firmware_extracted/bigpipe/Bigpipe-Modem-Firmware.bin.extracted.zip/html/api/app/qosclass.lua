local utils = require('utils')
require('dm')

local print = print

local policerMaps = {
	MeterType = "MeterType",
	Enable = "PolicerEnable",
	UpCommittedRate = "CommittedRate",
	UpPeakRate = "PeakRate",
	DownCommittedRate = "X_DownCommittedRate",
	DownPeakRate = "X_DownPeakRate"
}

local classMaps = {
	Enable = "ClassificationEnable",
	Name = "ClassificationName",
	SourceIP = "SourceIP",
	SourceIPEnd = "SourceIPEnd",
	Type = "X_Type",
	DSCPMark = "DSCPMark",
	ClassQueue = "ClassQueue",
	SourceMACAddress = "SourceMACAddress",
	LANInterface = "ClassInterface",
	ApplicationID = "APPName"
}

function calc_index(instanceId)
	local errcode,policerVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Policer.{i}.", 
		{"MeterType"});
	local array = {}
	i = 1
	if policerVals ~= nil then
		for k,v in pairs(policerVals) do
	    	local p,e = utils.findLastPoint(k)
	    	array[i] = tonumber(p)
	    	i = i+1
		end
	end
	table.sort(array)

	for j=1, i-1 do
		if array[j] == instanceId then
			return j
		end
	end
	return -1
end

-- new class
function create_class()
	-- add policer
	local paras = utils.GenAddObjParamInputs(data, policerMaps) 

	local errcode, newPolicer, NeedReboot, errparams = dm.AddObjectWithValues("InternetGatewayDevice.QueueManagement.Policer.", paras);
	utils.responseErrorcode(errcode, errparams, policerMaps)

	if 0 ~= errcode then
		return errcode
	end

	local policerIdex = calc_index(newPolicer)

	local paras = nil

	-- ip class
	if 	1 == data["Type"] then
		paras = {{"ClassificationEnable", data["Enable"]}, 	
			 {"ClassificationName", data["Name"]},	
			 {"X_QosLinkType", 3},
			 {"X_ShowFlag", 1},
			 {"SourceIP", data["SourceIP"]},
			 {"SourceIPEnd", data["SourceIPEnd"]}, 
			 {"SourceMask", data["SourceMask"]},
			 {"X_Type", data["Type"]}, 
			 {"ClassPolicer", policerIdex}, 
			 {"DSCPMark", data["DSCPMark"]},
			 {"ClassQueue", data["ClassQueue"]}}

	elseif 2 == data["Type"] then
		-- mac class
		paras = {{"ClassificationEnable", data["Enable"]}, 
		     {"ClassificationName", data["Name"]},	
			 {"X_QosLinkType", 3},
			 {"X_ShowFlag", 1},
			 {"SourceMACAddress", data["SourceMACAddress"]}, 
			 {"X_Type", data["Type"]}, 
			 {"ClassPolicer", policerIdex}, 
			 {"DSCPMark", data["DSCPMark"]},
			 {"ClassQueue", data["ClassQueue"]}}
	elseif 3 == data["Type"] then
		-- LAN class
		paras = {{"ClassificationEnable", data["Enable"]},
		     {"ClassificationName", data["Name"]},	 
		     {"X_QosLinkType", 3},
		     {"X_ShowFlag", 1},
			 {"ClassInterface", data["LANInterface"]}, 
			 {"X_Type", data["Type"]}, 
			 {"ClassPolicer", policerIdex}, 
			 {"DSCPMark", data["DSCPMark"]},
			 {"ClassQueue", data["ClassQueue"]}};
	elseif 4 == data["Type"] then
		-- APP class
		paras = {{"ClassificationEnable", data["Enable"]}, 
		     {"ClassificationName", data["Name"]},	
		     {"X_QosLinkType", 3},
		     {"X_ShowFlag", 1},
			 {"X_Type", data["Type"]}, 
			 {"ClassPolicer", policerIdex}, 
			 {"APPName", data["ApplicationID"]},
			 {"DSCPMark", data["DSCPMark"]},
			 {"ClassQueue", data["ClassQueue"]}}
	end

	local errcode, newClass, NeedReboot,paramerr = dm.AddObjectWithValues("InternetGatewayDevice.QueueManagement.Classification.", paras);
	utils.responseErrorcode(errcode, paramerr, classMaps)
	if errcode ~= 0 then
		dm.DeleteObject("InternetGatewayDevice.QueueManagement.Policer."..newPolicer)
	end

	return errcode
end

function update_class()
	-- body
	local domain = data["PolicerID"]

	local paras = {{domain.."MeterType", data["MeterType"]}, 
		{domain.."PolicerEnable", data["Enable"]}, 
		{domain.."CommittedRate", data["UpCommittedRate"]}, 
	 	{domain.."PeakRate", data["UpPeakRate"]}, 
	 	{domain.."X_DownCommittedRate", data["DownCommittedRate"]}, 
	 	{domain.."X_DownPeakRate", data["DownPeakRate"]}}

	local errcode , NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, policerMaps)
	if 0 ~= errcode then
		return errcode
	end
	
	domain = data["ID"]

	-- ip class
	if 	1 == data["Type"] then
		paras = {{domain.."ClassificationEnable", data["Enable"]}, 
			 {domain.."ClassificationName", data["Name"]},
			 {domain.."SourceIP", data["SourceIP"]},
			 {domain.."SourceIPEnd", data["SourceIPEnd"]}, 
			 {domain.."SourceMask", data["SourceMask"]},
			 {domain.."X_Type", data["Type"]}, 
			 {domain.."DSCPMark", data["DSCPMark"]},
			 {domain.."ClassInterface", ''}, 
			 {domain.."SourceMACAddress", ''},
			 {domain.."APPName", ''},
			 {domain.."ClassQueue", data["ClassQueue"]}};
	elseif 2 == data["Type"] then
		-- mac class
		paras = {{domain.."ClassificationEnable", data["Enable"]}, 
			 {domain.."ClassificationName", data["Name"]},
			 {domain.."SourceMACAddress", data["SourceMACAddress"]}, 
			 {domain.."X_Type", data["Type"]}, 
			 {domain.."DSCPMark", data["DSCPMark"]},			 
			 {domain.."SourceIP", ''},
			 {domain.."SourceIPEnd", ''}, 
			 {domain.."SourceMask", ''},
			 {domain.."ClassInterface", ''},
			 {domain.."APPName", ''},
			 {domain.."ClassQueue", data["ClassQueue"]}};
	elseif 3 == data["Type"] then
		-- LAN class
		paras = {{domain.."ClassificationEnable", data["Enable"]}, 
			 {domain.."ClassificationName", data["Name"]},
			 {domain.."ClassInterface", data["LANInterface"]},
			 {domain.."SourceIP", ''},
			 {domain.."SourceIPEnd", ''},
			 {domain.."SourceMask", ''}, 
			 {domain.."SourceMACAddress", ''},
			 {domain.."APPName", ''},
			 {domain.."X_Type", data["Type"]}, 
			 {domain.."DSCPMark", data["DSCPMark"]},
			 {domain.."ClassQueue", data["ClassQueue"]}};
	elseif 4 == data["Type"] then
		-- APP class
		paras = {{domain.."ClassificationEnable", data["Enable"]}, 
			 {domain.."ClassificationName", data["Name"]},
			 {domain.."X_Type", data["Type"]}, 
			 {domain.."APPName", data["ApplicationID"]},	 
			 {domain.."SourceIP", ''},
			 {domain.."SourceIPEnd", ''},
			 {domain.."SourceMask", ''}, 
			 {domain.."SourceMACAddress", ''},
			 {domain.."ClassInterface", ''}, 
			 {domain.."DSCPMark", data["DSCPMark"]},
			 {domain.."ClassQueue", data["ClassQueue"]}};
	end

	errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, classMaps)
	
	return errcode
end

function delete_class()
	local errcode = dm.DeleteObject(data["ID"])
	if 0 ~= errcode then
		return errcode
	end
	errcode = dm.DeleteObject(data["PolicerID"])
	return errcode
end

if action == 'create' then
	err = create_class()
elseif action == 'update' then
	err = update_class()
elseif action == 'delete' then
	err = delete_class()
else
	return
end
utils.appenderror("errcode", err)