local web = require('web')

web.setLang(data["Language"])
