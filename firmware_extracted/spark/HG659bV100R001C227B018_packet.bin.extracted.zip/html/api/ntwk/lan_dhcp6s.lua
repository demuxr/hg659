local utils = require('utils')

--local data = utils.getRequestFormData()

local maps = {
	DHCPServerEnable ="DHCPServerEnable",
	UseAllocatedWAN = "UseAllocatedWAN",
	Prefix = "Prefix",
	PrefixLength = "PrefixLength",
	Preferredlifetime = "Preferredlifetime",
	Validlifetime = "Validlifetime",
	Dhcp6sDNSServerone = "DNSServer",
	Dhcp6sDNSServertwo = "DNSServer"
}

function add_one_dhcp6s_parameter(paras, name, value)
	table.insert(paras, {name, value})
end

function build_dhcp6s_parameters()
	local paras = {}
	Dnsstr = ""
	add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.DHCPServerEnable", data["DHCPServerEnable"])
	if true == data["DHCPServerEnable"] then
		add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.UseAllocatedWAN", data["UseAllocatedWAN"])
	end	

	if true == data["DHCPServerEnable"] and "Normal" == data["UseAllocatedWAN"] then
		add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.Prefix", data["Prefix"])
		if "" == data["PrefixLength"] then
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.PrefixLength", "0")
		else
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.PrefixLength", data["PrefixLength"])
		end
		if "" == data["Preferredlifetime"] then
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.Preferredlifetime", "0")
		else
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.Preferredlifetime", data["Preferredlifetime"])
		end
		if "" == data["Validlifetime"] then
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.Validlifetime", "0")
		else
			add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.Validlifetime", data["Validlifetime"])
		end
		if "" ~= data["Dhcp6sDNSServerone"] then 
			Dnsstr = data["Dhcp6sDNSServerone"]
			if "" ~= data["Dhcp6sDNSServertwo"] then
				Dnsstr = Dnsstr..","..data["Dhcp6sDNSServertwo"]
			end		
		end		
		add_one_dhcp6s_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_DHCPv6.DNSServer", Dnsstr)
	end		
	return paras	
 end

local bridge = {}

if "Normal" == data["UseAllocatedWAN"] then
    add_one_dhcp6s_parameter(bridge, "InternetGatewayDevice.Layer2Bridging.Bridge.1.X_DNS6Mode", 2)
else   
    add_one_dhcp6s_parameter(bridge, "InternetGatewayDevice.Layer2Bridging.Bridge.1.X_DNS6Mode", 0)
end

errcode1, NeedReboot1, paramerr1 = dm.SetParameterValues(bridge)

local paras = build_dhcp6s_parameters()

utils.print_paras(paras)

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
