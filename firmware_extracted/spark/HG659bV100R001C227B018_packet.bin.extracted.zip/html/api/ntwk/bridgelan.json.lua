require('dm')
require('utils')

local errcode, bridges = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", {"BridgeName", "BridgeKey", "X_Type"})


local errcode, interfaces = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias", "InterfaceType", "AvailableInterfaceKey"})


local errcode, filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.",
		{"FilterBridgeReference", "FilterInterface"})

local intfs = {}
for k, v in pairs(interfaces) do
	if "LANInterface" == v["InterfaceType"] then
		local interface = {}
		interface.ID = k
		interface.InterfaceID = v["InterfaceReference"]
		interface.InterfaceName = v["X_InterfaceAlias"]
		interface.InterfaceType = v["InterfaceType"]
		local infilter = false

		for k1, v1 in pairs(filters) do
			if v1["FilterInterface"] == tostring(v["AvailableInterfaceKey"]) then
				interface.BridgeKey = v1["FilterBridgeReference"]
				infilter = true
				break;
			end
		end

		if infilter then
			-- 2.4G main ssid and 5G ssid bind to br0, read only
			if interface.InterfaceName == "SSID1" or interface.InterfaceName == "SSID5" then
				interface.ReadOnly = true
			else
				interface.ReadOnly = false
			end

			-- fon and guest network bridges read only
			for k2, v2 in pairs(bridges) do
				if v2["BridgeKey"] == interface.BridgeKey then
					if v2["X_Type"] == 1 or v2["X_Type"] == 2 then
						interface.ReadOnly = true
						break
					end
				end
			end

			table.insert(intfs, interface)
		end
	end
end

function comp(a, b)
	if a.InterfaceName < b.InterfaceName then
		return true
	end
	return false
end

table.sort(intfs, comp)

web.print(json.encode(intfs))