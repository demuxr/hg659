require('dm')
require('utils')

local maps = {
	LACEnable="Enable",
	LNSAddress = "LNSAddress",
	HostName = "HostName",
	TunnelPassword = "PassWord",
	KeepAliveTime = "KeepAliveTime",
	PPPUsername = "PppUser",
	PPPPassword = "PppPass",
	ConnectionMode = "ConnectionTrigger",
	ConnectionStatus = "ConnectionStatus"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_VPN.L2TP_LAC.", maps)

local obj
if values ~= nil then
	obj = values["InternetGatewayDevice.X_VPN.L2TP_LAC."]
	obj["Enable"] = utils.toboolean(obj["Enable"])
	obj["PassWord"] = utils.getdefaultPasswd(obj['PassWord'])
	obj["PppPass"] = utils.getdefaultPasswd(obj['PppPass'])
end
utils.responseSingleObject(obj, maps)
