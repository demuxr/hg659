require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_PVCSearch.",
    {
        "Enable",
        "PVCSearchList"
    }
);

local obj = values["InternetGatewayDevice.Services.X_PVCSearch."]

local cfg = {}

cfg.Enable = utils.toboolean(obj["Enable"])
cfg.List = obj["PVCSearchList"]

web.print(json.encode(cfg))
