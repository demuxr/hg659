require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local type = 'all'

if FormData["frequency"] ~= nil then
    type = FormData["frequency"]
end

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand"
    }
);

function get_WifiEnable(frequency)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return utils.toboolean(v["Enable"])
        end
    end

    return false
end

local errcode,wlanBasic = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.",
    {
    	"Enable",
        "WPAEncryptionModes",
        "IEEE11iEncryptionModes",
        "X_MixedEncryptionModes",
        "SSIDAdvertisementEnabled",
        "BeaconType",
        "BasicEncryptionModes",
        "BasicAuthenticationMode",
        "X_OperatingFrequencyBand"
    }
);

function calc_min(frequency)
    local array = {}
    i = 1
    if wlanBasic ~= nil then 
        for k,v in pairs(wlanBasic) do
            if frequency == v["X_OperatingFrequencyBand"] then
                wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end    
        end
        table.sort(array)
        if 1 == i  then
            return -1    
        else
            return array[1]
        end    
    end    
    return -1
end

wlan_index = calc_min("2.4GHz")
find_index = false

wlan_5gindex = calc_min("5GHz")
find_5gindex = false
local wpscanenable = {}
local wpswifiEnable = {}

for k,v in pairs(wlanBasic) do
	wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
	local canenable = true
    if wlan_index == tonumber(wlan_instance_id)  or wlan_5gindex == tonumber(wlan_instance_id)  then
        if v["BeaconType"] == "Basic" then
			canenable = false
		end	
		if v["BeaconType"] == "WPA-EAP" or v["BeaconType"] == "WPAWPA2-EAP" or v["BeaconType"] == "WPA2-EAP" or v["BeaconType"] == "8021X" then
			canenable = false
		end	
		if v["BeaconType"] == "WPA" then
			canenable = false
		end	
		if v["BeaconType"] == "11i" then
			if v["IEEE11iEncryptionModes"] == "TKIPEncryption" then
				canenable = false
			end
		end
		if v["BeaconType"] == "WPAand11i" then
			if v["X_MixedEncryptionModes"] == "TKIPEncryption" then
				canenable = false
			end
		end	
		if utils.toboolean(v["SSIDAdvertisementEnabled"]) == false then
			canenable = false
		end	
		local WifiEnable = get_WifiEnable(v["X_OperatingFrequencyBand"]) 
		local SsidEnable = utils.toboolean(v["Enable"])
		if true == WifiEnable and true == SsidEnable then
			enable = true
		else
			enable = false
		end	
		if wlan_index == tonumber(wlan_instance_id) then
            find_index = true
            wpscanenable["2g"] = canenable
            wpswifiEnable["2g"] = enable
        end
        
        if wlan_5gindex == tonumber(wlan_instance_id) then
            find_5gindex = true
            wpscanenable["5g"] = canenable
            wpswifiEnable["5g"] = enable
        end
	end    
end	

local wlanwps = {}

function make_wps_data(frequency, wpscanenable)
	if frequency == "2.4GHz" then
		if true ~= find_index then
			return
		end	
		wps_instance = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_index)..".WPS."
	else
		if true ~= find_5gindex then 
			return 
		end	
		wps_instance = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_5gindex)..".WPS."	
	end	
	local errcode,wps = dm.GetParameterValues(wps_instance,
    {
        "Enable",
        "X_WPSMode",
        "X_PinPhrase",
        "DevicePassword"
    }
	);
	local wps_obj = wps[wps_instance]
	wlanwps.ID = wps_instance
	wlanwps.WpsEnable = utils.toboolean(wps_obj["Enable"])
	wlanwps.WpsMode = wps_obj["X_WPSMode"]
	wlanwps.WifiWpsPinCode = wps_obj["X_PinPhrase"]
	wlanwps.WifiWpsApPinCode = wps_obj["DevicePassword"]
	if frequency == "2.4GHz" then
		wlanwps.WpsCanEnable = wpscanenable["2g"]
		wlanwps.FrequencyBand = "2.4GHz"
		wlanwps.wpswifiEnable = wpswifiEnable["2g"] 
	else
		wlanwps.WpsCanEnable = wpscanenable["5g"]
		wlanwps.FrequencyBand = "5GHz"
		wlanwps.wpswifiEnable = wpswifiEnable["5g"] 
	end	
end

if "2.4GHz" == type then
	make_wps_data("2.4GHz", wpscanenable)
	web.print(json.encode(wlanwps))
end
if "5GHz" == type then
	make_wps_data("5GHz", wpscanenable)
	web.print(json.encode(wlanwps))
end	
if "all" == type then
	local wpsdata = {}
	make_wps_data("2.4GHz", wpscanenable)
	table.insert(wpsdata, wlanwps)
	wlanwps = {}
	make_wps_data("5GHz", wpscanenable)
	table.insert(wpsdata, wlanwps)
	web.print(json.encode(wpsdata))
end	