require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local tonumber = tonumber

local errcode,wlanBasic = dm.GetParameterValues("InternetGatewayDevice.LANDevice.2.WLANConfiguration.{i}.",
    {
        "X_OperatingFrequencyBand",
        "TotalBytesSent",
        "TotalPacketsSent",
        "TotalBytesReceived",
        "TotalPacketsReceived",
        "SSID"
    }
);

function calc_min(frequency)
    local array = {}
    i = 1
    if wlanBasic ~= nil then 
        for k,v in pairs(wlanBasic) do
            if frequency == v["X_OperatingFrequencyBand"] then
                wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end    
        end
        table.sort(array)
        if 1 == i  then
            return -1    
        else
            return array[1]
        end    
    end    
    return -1
end

wlan_index = calc_min("2.4GHz")
find_index = false

wlan_5gindex = calc_min("5GHz")
find_5gindex = false
local wlan_5ginfo_str = "InternetGatewayDevice.LANDevice.2.WLANConfiguration."..wlan_5gindex..".Stats."

local wlan_info_str = "InternetGatewayDevice.LANDevice.2.WLANConfiguration."..wlan_index..".Stats."

local errcode,wlaninfo = dm.GetParameterValues(wlan_info_str,
    {
        "ErrorsSent",
        "DiscardPacketsSent",
        "ErrorsReceived",
        "DiscardPacketsReceived",
    }
);
local errcode,wlan5ginfo = dm.GetParameterValues(wlan_5ginfo_str,
    {
        "ErrorsSent",
        "DiscardPacketsSent",
        "ErrorsReceived",
        "DiscardPacketsReceived",
    }
);
local wlan5g = {}

local wlancfg = {}
local wlan = {}


for k,v in pairs(wlanBasic) do

    wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
    if wlan_index == tonumber(wlan_instance_id) then
        find_index = true
        wlan.ID = v["SSID"]
    	wlan.sendbytes = v["TotalBytesSent"]
    	wlan.sendpacket = v["TotalPacketsSent"]
    	wlan.receivebytes = v["TotalBytesReceived"]
    	wlan.receivepacket = v["TotalPacketsReceived"]
    end	
    if wlan_5gindex == tonumber(wlan_instance_id) then
        find_5gindex = true
        wlan5g.ID = v["SSID"]
        wlan5g.sendbytes = v["TotalBytesSent"]
        wlan5g.sendpacket = v["TotalPacketsSent"]
        wlan5g.receivebytes = v["TotalBytesReceived"]
        wlan5g.receivepacket = v["TotalPacketsReceived"]
    end
end 

for k,v in pairs(wlaninfo) do
    wlan.senderror = v["ErrorsSent"]
    wlan.senddiscard = v["DiscardPacketsSent"]
    wlan.receiveerror = v["ErrorsReceived"]
    wlan.receivediscard = v["DiscardPacketsReceived"]
end   

if nil ~= wlan5ginfo then 
    for k,v in pairs(wlan5ginfo) do
        wlan5g.senderror = v["ErrorsSent"]
        wlan5g.senddiscard = v["DiscardPacketsSent"]
        wlan5g.receiveerror = v["ErrorsReceived"]
        wlan5g.receivediscard = v["DiscardPacketsReceived"]
    end
end     

if false == find_index  and false == find_5gindex  then
    wlan.name = "Huawei-default(2.4GHz)"
    wlan.sendbytes = 0
    wlan.sendpacket = 0
    wlan.receivebytes = 0
    wlan.receivepacket = 0
    wlan5g.name = "Huawei-default(5GHz)"
    wlan5g.sendbytes = 0
    wlan5g.sendpacket = 0
    wlan5g.receivebytes = 0
    wlan5g.receivepacket = 0    
    wlan5g.senderror = 0
    wlan5g.senddiscard = 0
    wlan5g.receiveerror = 0
    wlan5g.receivediscard = 0
    wlan.senderror = 0
    wlan.senddiscard = 0
    wlan.receiveerror = 0
    wlan.receivediscard = 0

end

if true == find_index and false == find_5gindex then
    wlan5g.name = "Huawei-default(5GHz)"
    wlan5g.sendbytes = 0
    wlan5g.sendpacket = 0
    wlan5g.receivebytes= 0
    wlan5g.receivepacket = 0
    wlan5g.senderror = 0
    wlan5g.senddiscard = 0
    wlan5g.receiveerror = 0
    wlan5g.receivediscard = 0
end

if false == find_index  and true == find_5gindex  then
    wlan.name = "Huawei-default(2.4GHz)"
    wlan.sendbytes = 0
    wlan.sendpacket = 0
    wlan.receivebytes = 0
    wlan.receivepacket = 0
    wlan.senderror = 0
    wlan.senddiscard = 0
    wlan.receiveerror = 0
    wlan.receivediscard = 0
end

table.insert(wlancfg, wlan)
table.insert(wlancfg, wlan5g)
web.print(json.encode(wlancfg))