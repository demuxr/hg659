local utils = require('utils')
require('dm')
local string = string
local print = print

local maps = {
	URL="Url",
	Status = "Status",
	Devices = "DevMac"
}

function GetMacAddress()
	if false == data["DevManual"] then
		return ""
	end
	local mac = ''
	for k,v in pairs(data["Devices"]) do
		for k1, value in pairs(v) do
			mac = mac..value..'|'
		end
	end
	return string.sub(mac, 1, string.len(mac)-1)
end

function create()
	-- add 
	data["Devices"] = GetMacAddress()
	local paras = utils.GenAddObjParamInputs(data, maps)
	local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.X_FireWall.UrlFilter.", paras);
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]

	data["Devices"] = GetMacAddress()
	local paras = utils.GenSetObjParamInputs(domain, data, maps)

	local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)