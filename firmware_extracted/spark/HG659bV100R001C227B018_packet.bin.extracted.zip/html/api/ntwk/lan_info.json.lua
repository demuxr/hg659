require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local tonumber = tonumber
local lan = {}

local errcode,lanstatus = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.LANEthernetInterfaceConfig.{i}.",
    {
        "Status",  
        "Name",         
    }
);

for k,v in pairs(lanstatus) do

	local lanitem = {}

    if v["Name"] == "eth0.2" then
        lanitem.ID = "LAN1"
    end
    if v["Name"] == "eth0.3" then
        lanitem.ID = "LAN2"
    end  
    if v["Name"] == "eth0.4" then
        lanitem.ID = "LAN3"
    end
    if v["Name"] == "eth0.5" then
        lanitem.ID = "LAN4"
    end  

	laninfo = k.."Stats."
	local errcode,laninfo = dm.GetParameterValues(laninfo,
    	{
        	"BytesReceived",  
        	"PacketsReceived",
        	"X_PacketsReceivedError",
        	"X_PacketsReceivedDrops",
        	"BytesSent",
        	"PacketsSent",
        	"X_PacketsSentError",
        	"X_PacketsSentDrops"           
    	}
	);
	if nil ~= laninfo then
		for k1,v1 in pairs(laninfo) do
			lanitem.sendbytes = v1["BytesSent"]
    		lanitem.sendpacket = v1["PacketsSent"]
    		lanitem.receivebytes = v1["BytesReceived"]
    		lanitem.receivepacket = v1["PacketsReceived"]
    		lanitem.senderror = v1["X_PacketsSentError"]
    		lanitem.senddiscard = v1["X_PacketsSentDrops"]
    		lanitem.receiveerror = v1["X_PacketsReceivedError"]
    		lanitem.receivediscard = v1["X_PacketsReceivedDrops"]
    	end	
	else
		lanitem.sendbytes = 0
    	lanitem.sendpacket = 0
    	lanitem.receivebytes = 0
    	lanitem.receivepacket = 0
    	lanitem.senderror = 0
    	lanitem.senddiscard = 0
    	lanitem.receiveerror = 0
    	lanitem.receivediscard = 0
	end	
	table.insert(lan, lanitem)
end

utils.multiObjSortByID(lan)

web.print(json.encode(lan))