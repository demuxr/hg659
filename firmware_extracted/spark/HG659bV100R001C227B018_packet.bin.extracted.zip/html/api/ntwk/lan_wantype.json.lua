
    require('dm')
    require('web')
    require('json')
    require('utils')
    local tostring = tostring

    local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
        {"Name", "Enable", "ConnectionType", "X_ServiceList"});

    local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
        {"Name", "Enable", "ConnectionType", "X_ServiceList"}); 

    local wancon = {}

    for k,v in pairs(pppCon) do
        local con = {}
        con.ID = k
        con.Enable = utils.toboolean(v["Enable"])
        con.Name = v["Name"]
        con.ConnectionType = v["ConnectionType"]
        con.ServiceList = v["X_ServiceList"]

        table.insert(wancon, con)
    end

    for k,v in pairs(ipCon) do
        local con = {}
        con.ID = k
        con.Enable = utils.toboolean(v["Enable"])
        con.Name = v["Name"]
        con.ConnectionType = v["ConnectionType"]
        con.ServiceList = v["X_ServiceList"]
        table.insert(wancon, con)
    end

utils.multiObjSortByID(wancon)
web.print(json.encode(wancon))