local utils = require('utils')
require('dm')
local string = string

local maps = {
             ServiceType="X_Service", 
             AccessDirection="X_Direction",
             StartIpAddr="X_StartIpAddr",
             ManualDevMac="X_MacAddr",
             EndIpAddr = "X_EndIpAddr"}

function get_MacAddress()
    local joinmac = ""
    for k,v in pairs(data['MacAddrinHost']) do
        if joinmac == "" then
            joinmac = v["MACAddress"]
        else
            joinmac = joinmac.."|"..v["MACAddress"]
        end
    end
    return joinmac
end

function Generate_ACL_Submit_content(domain)
    local paras 
    if utils.toboolean(data["isMenualSetMac"]) then
        paras = {
                    {domain.."X_MacAddr", get_MacAddress()},
                    {domain.."X_Service", data["ServiceType"]}, 
                    {domain.."X_Direction",data["AccessDirection"]},
                    {domain.."X_StartIpAddr",""}, 
                    {domain.."X_EndIpAddr",""},
                  }
    else
        paras = {
                    {domain.."X_Service", data["ServiceType"]}, 
                    {domain.."X_Direction",data["AccessDirection"]},
                    {domain.."X_StartIpAddr",data["StartIpAddr"]}, 
                    {domain.."X_EndIpAddr",data["EndIpAddr"]},
                    {domain.."X_MacAddr", ""},
                  }
    end
    return paras
end

function create()
    -- add
    local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.ACL.", Generate_ACL_Submit_content(""));
    utils.responseErrorcode(errcode, paramerr, maps)
    return errcode
end

function delete()
    return dm.DeleteObject(data["ID"])
end

function update()
    if "null" == data["StartIpAddr"] then
        data["StartIpAddr"] = ""
    end

    if "null" == data["EndIpAddr"] then
        data["EndIpAddr"] = ""
    end

    local errcode, NeedReboot, paramerr =  dm.SetParameterValues(Generate_ACL_Submit_content(data["ID"]))
    utils.responseErrorcode(errcode, paramerr, maps)
    return errcode
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    err = update()
elseif action == 'delete' then
    err = delete()
else
    return
end
utils.appenderror("errcode", err)