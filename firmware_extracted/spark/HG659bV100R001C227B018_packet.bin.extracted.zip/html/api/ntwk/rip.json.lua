require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

--bridge list
local bridgelist = {}
local err, values = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", {"BridgeKey"})
if nil ~= values then
    for k,v in pairs(values) do
        local bridge = {}
        bridge.domain = k
        bridge.bridgekey = v["BridgeKey"]
        table.insert(bridgelist, bridge)
    end
end

function get_bridgekey_by_lan_instance_id(instance_id)
    local path = "InternetGatewayDevice.Layer2Bridging.Bridge."..instance_id.."."
    for k,v in pairs(bridgelist) do
        if path == v.domain then
            return v.bridgekey
        end
    end

    return -1
end

local wanrips = {}
local lanrips = {}

function get_wan_rip_by_domain(domain)
    local err, values = dm.GetParameterValues(domain, 
        {
            "Name",
            "X_WanAlias",
            "RouteProtocolRx",
            "ConnectionType",
            "X_ServiceList",
            "NATEnabled"
        })
    if nil ~= values then
        for k,v in pairs(values) do
            local rip = {}
            rip.domain = k
            rip.operation = "Passive"
            rip.name = v["Name"]
            if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
                rip.name = v["X_WanAlias"]
            end
            rip.protocol = v["RouteProtocolRx"]
            rip.contype = v["ConnectionType"]
            rip.servicelist = v["X_ServiceList"]
            rip.natenabled = utils.toboolean(v["NATEnabled"])

            table.insert(wanrips, rip)
        end
    end
end

-- get wan rip info
get_wan_rip_by_domain("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.")
get_wan_rip_by_domain("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.")

function get_lan_instance_id(domain)
    local start = string.find(domain, "LANHostConfigManagement")
    local lan_domain = string.sub(domain, 1, start - 1)
    if lan_domain ~= nil then
        idstr, suffix = utils.findLastPoint(lan_domain)
        return tonumber(idstr)
    end

    return 0
end

-- get lan rip info
local err, values = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.LANHostConfigManagement.IPInterface.{i}.", { "Enable" })
if nil ~= values then
    for k,v in pairs(values) do
        local rip = {}
        rip.domain = k
        rip.inst = get_lan_instance_id(k)
        rip.lanbridgekey = get_bridgekey_by_lan_instance_id(rip.inst)
        rip.enable = utils.toboolean(v["Enable"])
        table.insert(lanrips, rip)
    end
end

function get_lan_if_name(rip_interface)
    for k,v in pairs(lanrips) do
        if rip_interface == v.domain then
            return "br"..v.lanbridgekey
        end
    end

    return ""
end

function get_wan_if_name(rip_interface)
    for k,v in pairs(wanrips) do
        if rip_interface == v.domain then
            if "IP_Routed" == v.contype then
                local internetstr = string.find(v.servicelist, "INTERNET")
                local otherstr = string.find(v.servicelist, "Other")
                if nil ~= internetstr or nil ~= otherstr then
                    return v.name
                end
            end
        end
    end

    return ""
end

function get_rip_ifname_by_ifside(interface, ifside, enable)
    local wanstr = string.find(ifside, "WAN")
    local lanstr = string.find(ifside, "LAN")

    if not enable then
        return ""
    end
    if nil ~= wanstr then
        return get_wan_if_name(interface)
    end

    if nil ~= lanstr then
        return get_lan_if_name(interface)
    end

    return ""
end

local rips = {}
local err, values = dm.GetParameterValues("InternetGatewayDevice.Layer3Forwarding.RIP.InterfaceSetting.{i}.",
    {
        "Enable",
        "Interface",
        "X_InterfaceSide",
        "X_RouteProtocolRx",
        "X_RIPOperation"
    }
)
if nil ~= values then
    for k,v in pairs(values) do
        local rip = {}
        rip.domain = k
        rip.ID = k
        local enable = utils.toboolean(v["Enable"])
        local interface = v["Interface"].."."
        rip.protocol = v["X_RouteProtocolRx"]
        rip.operation = v["X_RIPOperation"]
        rip.ifname = get_rip_ifname_by_ifside(interface, v["X_InterfaceSide"], enable)

        if "" ~= rip.ifname then
            table.insert(rips, rip)
        end
    end
end

utils.multiObjSortByID(rips)
web.print(json.encode(rips))
