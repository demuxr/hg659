require('dm')
require('utils')

local lay2bridge = {}

local errcode, bridges = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", {"BridgeName", "BridgeKey", "X_Type"})


local errcode, interfaces = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias", "InterfaceType", "AvailableInterfaceKey"
	})


local errcode, filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.",
		{"FilterBridgeReference", "FilterInterface"})

local intfs = {}
for k, v in pairs(filters) do
	local interface = {}
	interface.ID = k
	interface.BridgeKey = v["FilterBridgeReference"]

	for k1, v1 in pairs(interfaces) do
		if tostring(v1["AvailableInterfaceKey"]) == v["FilterInterface"] then
			interface.InterfaceID = v1["InterfaceReference"]
			interface.InterfaceName = v1["X_InterfaceAlias"]
			interface.InterfaceType = v1["InterfaceType"]
			interface.AvailableID = k1
			break;
		end
	end
	table.insert(intfs, interface)
end

function getBridgeWanInf(bridgeKey)
	local wan = {}
	for k, v in pairs(intfs) do
		if v["BridgeKey"] == bridgeKey then
			if v["InterfaceType"] ~= "LANInterface" then
				table.insert(wan, v)
			end
		end
	end

	return wan
end

function getBridgeLanInf(bridgeKey)
	local lan = {}
	for k, v in pairs(intfs) do
		if v["BridgeKey"] == bridgeKey then
			if v["InterfaceType"] == "LANInterface" then
				table.insert(lan, v)
			end
		end
	end
	return lan
end

for k, v in pairs(bridges) do
	local b = {}
	b.ID = k
	b.BridgeNameReadOnly = false
	b.BridgeName = v["BridgeName"]
	b.BridgeKey  = v["BridgeKey"]
	b.Type       = v["X_Type"]

	if 0 == b.BridgeKey then
		b.BridgeNameReadOnly = true
	end

	if v["X_Type"] == 1 or v["X_Type"] == 2 then
		b.ReadOnly = true
		b.BridgeNameReadOnly = true
	else
		b.ReadOnly = false
	end
	if 4 ~= v["X_Type"] then
		b.WANInterface = getBridgeWanInf(v["BridgeKey"])
		b.LANInterface = getBridgeLanInf(v["BridgeKey"])
		table.insert(lay2bridge, b)
	end
end

utils.multiObjSortByID(lay2bridge)
web.print(json.encode(lay2bridge))