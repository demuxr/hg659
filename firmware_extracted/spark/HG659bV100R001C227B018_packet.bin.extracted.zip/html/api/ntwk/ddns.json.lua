require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,values= dm.GetParameterValues("InternetGatewayDevice.Services.X_DDNSConfiguration.{i}.",
        {"Enable", "Provider", "Username", "Password", "DomainName", "HostName", "WanPath", "Status"})

local ddns = {}

ddns.Enable = false;
ddns.Provider = "";
ddns.HostName = "";
ddns.DomainName = "";
ddns.Username = "";
ddns.Password = "";
ddns.Status = ""
local bFound = false;
if 0 == errcode and values then
    for k,v in pairs(values) do
        if not bFound then
            ddns.Enable = utils.toboolean(v["Enable"])
            ddns.Provider = v["Provider"]
            ddns.HostName = v["HostName"]
            ddns.DomainName = v["DomainName"]
            ddns.Username = v["Username"]
            ddns.Password = utils.getdefaultPasswd(v['Password'])
            ddns.Status = v["Status"]
        end
    end
end
web.print(json.encode(ddns))
