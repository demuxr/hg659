require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local type = 'all'

if FormData["frequency"] ~= nil then
    type = FormData["frequency"]
end

print('type'..type)

local errcode,wlanBasic = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.",
    {
        "MACAddressControlEnabled",
        "X_WlanMacFilterpolicy",
        "X_OperatingFrequencyBand"
    }
);


function calc_min(frequency)
    local array = {}
    i = 1
    if wlanBasic ~= nil then 
        for k,v in pairs(wlanBasic) do
            if frequency == v["X_OperatingFrequencyBand"] then
                wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end    
        end
        table.sort(array)
        if 1 == i  then
            return -1    
        else
            return array[1]
        end    
    end    
    return -1
end

wlan_index = calc_min("2.4GHz")
find_index = false

wlan_5gindex = calc_min("5GHz")
find_5gindex = false

local filters = {}
local wlandata = {}

for k,v in pairs(wlanBasic) do
    wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
    if wlan_index == tonumber(wlan_instance_id)  or wlan_5gindex == tonumber(wlan_instance_id)  then
        if wlan_index == tonumber(wlan_instance_id) then
            find_index = true
            wlandata["2genable"] = utils.toboolean(v["MACAddressControlEnabled"])
            wlandata["2gmode"] = v["X_WlanMacFilterpolicy"]
        end
        
        if wlan_5gindex == tonumber(wlan_instance_id) then
            find_5gindex = true
            wlandata["5genable"] = utils.toboolean(v["MACAddressControlEnabled"])
            wlandata["5gmode"] = v["X_WlanMacFilterpolicy"]
        end
    end    
end    

function make_macfilter_data(frequency)
    if frequency == "2.4GHz" then
        if true ~= find_index then
            return
        end 
        macfilter_instance = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_index)..".X_WlanMacFilter.{i}."
    else
        if true ~= find_5gindex then 
            return 
        end 
        macfilter_instance = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_5gindex)..".X_WlanMacFilter.{i}."  
    end 
    local errcode,mac = dm.GetParameterValues(macfilter_instance,
    {
        "X_WlanSrcMacAddress"
    }
    );
    local macaddrs = {}
    if mac ~= nil then
        for k,v in pairs(mac) do
            local macaddr = {}
            macaddr.MACAddress = v["X_WlanSrcMacAddress"]
            table.insert(macaddrs, macaddr)
        end
    end   
    if frequency == "2.4GHz" then
        filters.MACAddressControlEnabled = wlandata["2genable"]
        filters.MacFilterPolicy = wlandata["2gmode"]
        filters.ID = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_index).."."
        filters.FrequencyBand = "2.4GHz" 
    else
        filters.MACAddressControlEnabled = wlandata["5genable"]
        filters.MacFilterPolicy = wlandata["5gmode"] 
        filters.ID = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..tostring(wlan_5gindex).."."   
        filters.FrequencyBand = "5GHz"
    end       
    filters.MACAddresses = macaddrs      
end

if "2.4GHz" == type then
    print('2.4g come in')
    make_macfilter_data("2.4GHz")
    web.print(json.encode(filters))
end
if "5GHz" == type then
    print('5g come in')
    make_macfilter_data("5GHz")
    web.print(json.encode(filters))
end

if "all" == type then
    local macdata = {}
    make_macfilter_data("2.4GHz")
    table.insert(macdata, filters)
    filters = {}
    make_macfilter_data("5GHz")
    table.insert(macdata, filters)
    web.print(json.encode(macdata))
end 

