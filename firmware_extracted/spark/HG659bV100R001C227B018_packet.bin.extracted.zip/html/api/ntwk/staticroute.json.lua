require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring


local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Layer3Forwarding.Forwarding.{i}.",
    {
        "Status",
        "DestIPAddress",
        "DestSubnetMask",
        "SourceIPAddress",
        "SourceSubnetMask",
        "GatewayIPAddress",
        "Interface",
        "ForwardingMetric",
        "MTU"
    }
)

local routes = {}
if values ~= nil then
    for k,v in pairs(values) do
        local route = {}
        route.ID = k
        route.status = v["Status"]
        route.destip = v["DestIPAddress"]
        route.destsnmask = v["DestSubnetMask"]
        route.gatewayip = v["GatewayIPAddress"]
        route.srcip = v["SourceIPAddress"]
        route.srcsnmask = v["SourceSubnetMask"]
        route.mtu = tonumber(v["MTU"])
        route.metric = tonumber(v["ForwardingMetric"])
        route.interface = v["Interface"]

            table.insert(routes, route)
        
    end
end
utils.multiObjSortByID(routes)
web.print(json.encode(routes))