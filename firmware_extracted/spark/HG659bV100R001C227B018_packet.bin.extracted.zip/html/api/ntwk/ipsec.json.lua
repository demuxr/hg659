require('dm')
require('utils')

local filters = {}
local profiles = {}
local filters_errcode,filters_values = dm.GetParameterValues("InternetGatewayDevice.X_VPN.IPsec.Filter.{i}.", {
    "Enable",
    "Order",
    "Alias",
    "Interface",
    "DestIP",
    "DestMask",
    "X_SRCMODE",
    "X_DEVMAC",    
    "SourceIP",
    "SourceMask",
    "Protocol",   
    "DestPort",
    "SourcePort",
    "ProcessingChoice",
    "Profile"
});

function parsemacs(key, srcmac)
    local start = 1
    local devices = {}
    while true do
        ip, fp = string.find(srcmac, "|", start)
        if not ip then
            local mac = {}
            mac[key] = string.sub(srcmac, start)
            table.insert(devices, mac)
            break
        end
        local mac = {}
        mac[key] = string.sub(srcmac, start, ip-1)
        table.insert(devices, mac)
        start = fp +1
    end

    return devices
end

local flag = 0
if nil ~= filters_values then
    -- instances exist
    for k,v in pairs(filters_values) do
        flag = flag + 1
        --print(k, v)
        local one_filter = {}
        one_filter.ID               = k
        one_filter.FilterEnable     = utils.toboolean(v['Enable'])
        one_filter.Order            = v["Order"]
        one_filter.Alias            = v["Alias"]
        one_filter.Interface        = v["Interface"]
        one_filter.DestIP           = v["DestIP"]
        one_filter.DestMask         = v["DestMask"]
        one_filter.Srcmode          = utils.toboolean(v['X_SRCMODE'])
        one_filter.HostLists        = parsemacs('MACAddress', v['X_DEVMAC'])
        one_filter.SourceIP         = v["SourceIP"]
        one_filter.SourceMask       = v["SourceMask"]
        one_filter.Protocol         = v["Protocol"]
        one_filter.DestPort         = v["DestPort"]
        one_filter.SourcePort       = v["SourcePort"]
        one_filter.ProcessingChoice = v["ProcessingChoice"]
        one_filter.Profile          = v["Profile"]
        table.insert(filters, one_filter)
    end
end

if flag == 0 then
    -- instances not exist, we set a default instances
    local one_filter = {}
    one_filter.ID = ""
    one_filter.FilterEnable = true
    one_filter.HostLists = {}
    one_filter.ID               = ""
    one_filter.FilterEnable     = false
    one_filter.Order            = "1"
    one_filter.Alias            = "cpe_filter1"
    one_filter.Interface        = ""
    one_filter.DestIP           = ""
    one_filter.DestMask         = ""
    one_filter.Srcmode          = false
    one_filter.HostLists        = {}
    one_filter.SourceIP         = ""
    one_filter.SourceMask       = ""
    one_filter.Protocol         = -1
    one_filter.DestPort         = -1
    one_filter.SourcePort       = -1
    one_filter.ProcessingChoice = "Bypass"
    one_filter.Profile          = ""
    table.insert(filters, one_filter)
end

local profiles_errcode,profiles_values = dm.GetParameterValues("InternetGatewayDevice.X_VPN.IPsec.Profile.{i}.", {
    "RemoteEndpoints",
    "X_RemoteDnsAddr",
    "Protocol",
    "X_PublicCert",
    "X_PrivateCert",
    "X_RPublicCert",
    "IKEv2AllowedEncryptionAlgorithms",
    "ESPAllowedEncryptionAlgorithms",
    "IKEv2AllowedIntegrityAlgorithms",
    "AHAllowedIntegrityAlgorithms",
    "ESPAllowedIntegrityAlgorithms",
    "IKEv2AllowedDiffieHellmanGroupTransforms"
});

flag = 0
if nil ~= profiles_values then
    -- instances exist
    for k, v in pairs(profiles_values) do
        flag = flag + 1
        local one_profile = {}
        one_profile.ID = k
        one_profile.RemoteEndpoints     = v["RemoteEndpoints"]
        one_profile.RemoteDnsAddr       = v["X_RemoteDnsAddr"]
        one_profile.Protocol            = v["Protocol"]
        one_profile.PublicCert         = v["X_PublicCert"]
        one_profile.PrivateCert         = v["X_PrivateCert"]
        one_profile.RPublicCert         = v["X_RPublicCert"]
        one_profile.PHOneEncAlg         = v["IKEv2AllowedEncryptionAlgorithms"]
        one_profile.PHTwoEncAlg         = v["ESPAllowedEncryptionAlgorithms"]
        one_profile.PHOneAuthAlg        = v["IKEv2AllowedIntegrityAlgorithms"]
        one_profile.PHTwoAuthAlgAH      = v["AHAllowedIntegrityAlgorithms"]
        one_profile.PHTwoAuthAlgESP     = v["ESPAllowedIntegrityAlgorithms"]
        one_profile.PHOneDHGroup        = v["IKEv2AllowedDiffieHellmanGroupTransforms"]
        table.insert(profiles, one_profile)
    end
end

if flag == 0 then
    -- instances not exist, we set a default instances
    --print('inst none exist')
    local one_profile = {}
    one_profile.ID              = ""
    one_profile.RemoteEndpoints = ""       
    one_profile.RemoteDnsAddr   = ""
    one_profile.Protocol        = "ESP"
    one_profile.PublicCert      = '/var/vpn/cert/pub.cert'
    one_profile.PrivateCert     = '/var/vpn/cert/priv.cert'
    one_profile.RPublicCert     = '/var/vpn/cert/rpub.cert'
    one_profile.PHOneEncAlg     = "3des"
    one_profile.PHTwoEncAlg     = "3des"
    one_profile.PHOneAuthAlg    = "md5"
    one_profile.PHTwoAuthAlgAH  = "hmac_md5"
    one_profile.PHTwoAuthAlgESP = "hmac_md5"
    one_profile.PHOneDHGroup    = "768bit"
    table.insert(profiles, one_profile)
end

utils.multiObjSortByID(filters)
utils.multiObjSortByID(profiles)

local ipsec = {}
for i=1,table.getn(filters) do
    if i== 1 then
        local filter_obj = filters[i]
        ipsec.filters = filter_obj
    end
end

for i=1,table.getn(profiles) do
    if i== 1 then
        local profile_obj = profiles[i]
        ipsec.profiles = profile_obj
    end
end

web.print(json.encode(ipsec))