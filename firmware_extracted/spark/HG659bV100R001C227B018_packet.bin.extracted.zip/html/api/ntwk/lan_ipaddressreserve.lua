local utils = require('utils')
require('dm')
local string = string
local print = print

local maps = {
	Enable = "Enable",
	Chaddr="Chaddr",
	Yiaddr = "Yiaddr",
}

function create()
	local paras = utils.GenAddObjParamInputs(data, maps)
	local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPStaticAddress.", paras);
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]
	local paras = utils.GenSetObjParamInputs(domain, data, maps)

	local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)