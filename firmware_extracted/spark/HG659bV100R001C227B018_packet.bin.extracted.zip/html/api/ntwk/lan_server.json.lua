require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode,dhcpst = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.", 
    {"DHCPServerEnable", "MinAddress", "MaxAddress", "DNSServers", "DHCPLeaseTime", "UseAllocatedWAN", "AssociatedConnection",
     "PassthroughMACAddress", "PassthroughLease"});

local errcode,dnsmode = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.1.", 
    {"X_DNSMode"});

function get_DNS_Server_Address(DNSServers)
    if DNSServers == nil then
        return "",""
    end

    local start = string.find(DNSServers,',')
    local secondDnsServer = ""
    local firstDnsServer  = ""
    if start == nil  then
        return DNSServers, ""
    else
        local firstDnsServer = string.sub(DNSServers, 1, start - 1)
        local secondDnsServer = string.sub(DNSServers, start + 1,string.len(DNSServers))
        return firstDnsServer,secondDnsServer
    end    
end

    local dhcpserver = {}
for k,v in pairs(dhcpst) do 
    dhcpserver.ID = k
    dhcpserver.ServerEnable = utils.toboolean(v["DHCPServerEnable"])
    dhcpserver.MinIP = v["MinAddress"]
    dhcpserver.MaxIP = v["MaxAddress"]
    dhcpserver.DNSServerone, dhcpserver.DNSServertwo = get_DNS_Server_Address(v["DNSServers"])
    dhcpserver.DHCPLeaseTime = v["DHCPLeaseTime"]
    dhcpserver.UseAllocatedWAN = v["UseAllocatedWAN"] 
    dhcpserver.AssociatedConnection = v["AssociatedConnection"]
    dhcpserver.PassthroughMACAddress = v["PassthroughMACAddress"]
    dhcpserver.PassthroughLease = v["PassthroughLease"] 
end

if nil ~= dnsmode then
    for k,v in pairs(dnsmode) do
        local mode = v["X_DNSMode"]
        if 0 == mode or 1 == mode then 
            dhcpserver.dnsmode = "true"
        else
            dhcpserver.dnsmode = "false"
        end    
    end    
end
web.print(json.encode(dhcpserver))  