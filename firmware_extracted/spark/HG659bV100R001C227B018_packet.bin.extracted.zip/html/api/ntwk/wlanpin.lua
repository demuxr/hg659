local utils = require('utils')
local web = require('web')
local tostring = tostring

dm.log(csrf)
dm.log(data)

if data["key"] == "GenerateAPPIN" then
	newpin = web.genappin()
	utils.appenderror('type', "GenerateAPPIN")
	utils.appenderror('pinvalue', newpin)
end	

if data["key"] == "ResetAPPIN" then
	defaultpin = web.defaultappin()
	utils.appenderror('type', "ResetAPPIN")
	utils.appenderror('pinvalue', defaultpin)
end	
