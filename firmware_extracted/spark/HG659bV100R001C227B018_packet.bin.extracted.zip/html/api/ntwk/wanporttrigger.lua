local utils = require('utils')
require('dm')
local print = print

local pt_maps = {
    PortTriggerEnable="PortTriggerEnable",
    TriggerPort="TriggerPort",
    TriggerPortEnd="TriggerPortEnd",
    TriggerProtocol="TriggerProtocol",
    OpenPort="OpenPort",
    OpenPortEnd="OpenPortEnd",
    PortTriggerDescription="PortTriggerDescription",
}

function create()
	-- add 
	local paras = utils.GenAddObjParamInputs(data, pt_maps)

	local errcode, instnum, NeedReboot, errs = dm.AddObjectWithValues(data["WanID"].."X_PortTrigger.", paras);

	if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, pt_maps)
        return errcode
    end

    utils.appenderror("errcode", 0)
    return errcode

end

function delete()

	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]

	local paras = utils.GenSetObjParamInputs(domain, data, pt_maps)
	local err,needreboot, paramerror = dm.SetParameterValues(paras);

	if err ~= 0 then
	    utils.responseErrorcode(err, paramerror, pm_maps)
    end
    return err
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()

elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)
