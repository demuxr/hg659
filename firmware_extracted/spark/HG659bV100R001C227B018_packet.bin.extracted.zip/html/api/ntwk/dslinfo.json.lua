require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local info = {}
local dslWan = utils.get_dsl_wan_id()
if dslWan == nil then
    web.print(json.encode(info))
    return
end

local errcode,objs= dm.GetParameterValues(dslWan,
        {"ModulationType", "Status", "UpstreamCurrRate",
         "DownstreamCurrRate", "UpstreamNoiseMargin",
         "DownstreamNoiseMargin", "X_UpInterleaveDepth",
         "InterleaveDepth", "UpstreamAttenuation",
         "DownstreamAttenuation", "UpstreamPower","DownstreamPower",
         "DataPath", "ShowtimeStart","UpstreamMaxRate","DownstreamMaxRate"})

local obj=objs[dslWan]
info.Modulation = obj["ModulationType"]
info.Status = obj["Status"]
info.UpCurrRate = obj["UpstreamCurrRate"]
info.DownCurrRate = obj["DownstreamCurrRate"]
info.UpMargin = obj["UpstreamNoiseMargin"]/10
info.DownMargin = obj["DownstreamNoiseMargin"]/10
info.UpDepth = obj["X_UpInterleaveDepth"]
info.DownDepth = obj["InterleaveDepth"]
info.UpAttenuation = obj["UpstreamAttenuation"]/10
info.DownAttenuation = obj["DownstreamAttenuation"]/10
info.UpPower = obj["UpstreamPower"]/10
info.DownPower = obj["DownstreamPower"]/10
info.DataPath = obj["DataPath"]
info.ShowtimeStart = obj["ShowtimeStart"]
info.UpstreamMaxBitRate = obj["UpstreamMaxRate"]
info.DownstreamMaxBitRate = obj["DownstreamMaxRate"]


web.print(json.encode(info))
