local utils = require('utils')
local tostring = tostring

local errcode,bridges = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", 
    {"BridgeKey", "X_Type", "BridgeName"});
local errcode,filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.", 
    {"FilterBridgeReference", "FilterInterface"});
local errcode,intfs = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", 
    {"AvailableInterfaceKey", "InterfaceReference", "X_InterfaceAlias", "InterfaceType"});
local err, wandevs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig", 
    {"WANAccessType"});
local errcode,vlans = dm.GetParameterValues("InternetGatewayDevice.X_VLANTermination.{i}.", 
                {"LowerLayers", "VLANID", "802-1pMark"});

function get_br0_key(bridges)
	for k,v in pairs(bridges) do
		if "br0" == tostring(v["BridgeName"]) then
			return v["BridgeKey"]
		end
	end
	return -1
end

function add_iptv_bridge()
	local paras = {}
	table.insert(paras, {"BridgeName", "iptv"})
	table.insert(paras, {"X_Type", "4"})

	local errcode,instId = dm.AddObjectWithValues("InternetGatewayDevice.Layer2Bridging.Bridge.", paras)
	if 0 ~= errcode then
		utils.appenderror("ConnectionType", "iptv.wan_err")
		return -1,""
	end

	local br_path = "InternetGatewayDevice.Layer2Bridging.Bridge."..tostring(instId).."."
	local errcode,br_key = dm.GetParameterValues(br_path, {"BridgeKey"});
	return br_key[br_path]["BridgeKey"], "InternetGatewayDevice.Layer2Bridging.Bridge."..instId.."."
end

function is_lan_port_need_to_move_to_br0(new_lan_intf)
	for k,v in pairs(intfs) do
		if "LANInterface" == v["InterfaceType"] then
			print(v["AvailableInterfaceKey"].." -> "..v["X_InterfaceAlias"].. " -> "..v["InterfaceType"])
			if not string.find(tostring(new_lan_intf), v["X_InterfaceAlias"]) then
				return true
			end
		end
	end
	return false
end

function restore_lan_intf_to_br0(filters, br_key, new_lan_intf)
	local br0_key = get_br0_key(bridges)

	local current_lan = ""
	for k,v in pairs(filters) do
		if tostring(v["FilterBridgeReference"]) == tostring(br_key) then
			local intf = utils.get_intf_by_key(intfs, v["FilterInterface"])
			if intf and "LANInterface" == intf["InterfaceType"] then
				print("Check interface ["..v["FilterInterface"].."] with name ["..intf["X_InterfaceAlias"].."] for filter ["..k.."] ...")
				if not string.find(new_lan_intf, intf["X_InterfaceAlias"]) then
					print("Put ["..k.."] back to br0 now ...")
					dm.SetParameterValues(k.."FilterBridgeReference", br0_key)
				end
			end
		end
	end
end

function get_wan_interface(filters, intfs, br_key)
	for k,v in pairs(filters) do
		print(v["FilterBridgeReference"].." -> "..v["FilterInterface"])
		if tostring(v["FilterBridgeReference"]) == tostring(br_key) then
			local binded_intf = utils.get_intf_by_key(intfs, v["FilterInterface"])
			print(binded_intf)
			if binded_intf and "LANInterface" ~= binded_intf["InterfaceType"] then
				return binded_intf["InterfaceReference"].."."
			end
		end
	end
	return ""
end

function iptv_wan_update(br_key)
	local errcode = 0
	local wan_intf = get_wan_interface(filters, intfs, br_key)
	data["Enable"] = true
	data["Alias"] = "IPTV WAN Connection"
	if "Bridged" == data["ConnectionType"] then
		data["NATType"] = 0
	else
		data["NATType"] = 1
	end
	data["LinkType"] = "EoA"
	data["EncapMode"] = "LLC"
	data["AtmQoS"] = "UBR"
	if "" == wan_intf then
		-- Create new link
		print("Create new link now ...")
		local newLink = utils.create_new_link(data, wandevs)
		print("Create new link return ["..newLink.."]")
		if "" == newLink then
			return ""
		end
		data["LowerLayer"] = newLink
		print(wandevs)

		-- Create new wan
		local wanconndev = utils.get_wanconn_by_wanid(newLink)
		print("WAN connection device is "..wanconndev)
		local newId = utils.add_new_wan_to_wan_conn_dev(data, wanconndev, wandevs)
		print("New wan id is "..newId)
		if "" == newId then
			return ""
		end

		-- New WAN is created, so update interfaces
		errcode,intfs = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", 
    		{"AvailableInterfaceKey", "InterfaceReference", "X_InterfaceAlias", "InterfaceType"});

		-- Add filter
		local new_wan_intf = utils.get_intf_by_ref(intfs, newId)
		local paras = {}
		table.insert(paras, {"FilterBridgeReference", br_key})
		table.insert(paras, {"FilterInterface", new_wan_intf["AvailableInterfaceKey"]})
		utils.print_paras(paras)
		errcode = dm.AddObjectWithValues("InternetGatewayDevice.Layer2Bridging.Filter.", paras)
		print("Add filter return "..tostring(errcode))

		return newId
	end

	local wanconndev = utils.get_wan_conn_dev_of_wan(wan_intf)

	local lowerlayer = utils.get_lowerlayer_by_wan(wan_intf)

	-- First update link data
	local newLink = lowerlayer
	if "" == newLink and not string.find(lowerlayer, "VLANTermination.") then
		newLink = wanconndev
	end
	if "" ~= lowerlayer then
		data["ID"] = string.gsub(lowerlayer, "X_".."ATP".."_VLANTermination", "X_VLANTermination")
	else
		data["ID"] = wanconndev
	end
	--Back up previous lower layer
	newLink = utils.update_single_link(wanconndev, data, wandevs, vlans, false)
	if nil == newLink then
		return ""
	end
	utils.luadbg("Previous conndev is ["..wanconndev.."], new link is ["..newLink.."]")

	data["ID"] = wan_intf
	if string.find(newLink, "VLANTermination.") then
		wanconndev = utils.get_wanconn_by_wanid(newLink)
	else
		wanconndev = newLink
	end

	data["LowerLayer"] = newLink
	local newWan = utils.update_single_wan(data, wanconndev, false, wandevs)
	utils.luadbg("Update wan return id ["..newWan.."]")
	utils.check_vlan_need_to_be_deleted(lowerlayer, nil, 0)
	if "" == newWan then
		return ""
	end

	-- Connection type changed, update FilterBridgeReference
	if newWan ~= data["ID"] then
		-- Refresh filters and intfs
		errcode,filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.", 
    		{"FilterBridgeReference", "FilterInterface"});
		errcode,intfs = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", 
    		{"AvailableInterfaceKey", "InterfaceReference", "X_InterfaceAlias", "InterfaceType"});
		local newIntf = utils.get_intf_by_ref(intfs, newWan)
		local filter = utils.get_filter_by_intf_key(filters, newIntf["AvailableInterfaceKey"])
		dm.SetParameterValues(filter.."FilterBridgeReference", br_key)
	end
	return newWan
end

function update_routed_iptv_lan_ip(landev)
	--landev.."IPInterface."
	local iptvIP = ""
	errcode,lanIPs = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.LANHostConfigManagement.IPInterface.{i}.", {"IPInterfaceIPAddress"});
	for k,v in pairs(lanIPs) do
		if string.find(k, landev.."IPInterface.") then
			iptvIP = v["IPInterfaceIPAddress"]
		end
	end
	if "" == iptvIP then
		local paras = {}
		iptvIP = "192.168.250.1"
		table.insert(paras, {"IPInterfaceIPAddress", iptvIP})
		table.insert(paras, {"Enable", true})
		local errcode,instId = dm.AddObjectWithValues(landev.."IPInterface.", paras)
	end
	return iptvIP
end

function enable_iptv(br_key, br_path)
	local lanIntfs = utils.split(data["LANAlias"], ",")
	local old_br_key = br_key
	--1. Add IPTV bridge if not exists
	if -1 == br_key then
		br_key,br_path = add_iptv_bridge()
	end
	if -1 == br_key then
		return 9003
	end

	--2. Change WAN interface parameters
	local iptv_wan = iptv_wan_update(br_key)
	if "" == iptv_wan then
		-- Remove the newly created IPTV bridge to restore state
		if -1 == old_br_key then
			print("Delete newly created bridge ["..br_path.."] now ...")
			dm.DeleteObject(br_path)
		end
		utils.appenderror("ConnectionType", "iptv.wan_err")
		return 9003
	end

	--3. Change lan interface filter
	if -1 ~= br_key then
		-- Move old binded LAN interface back to br0
		restore_lan_intf_to_br0(filters, br_key, data["LANAlias"])
	end
	for k, lan in pairs(lanIntfs) do
		local lan_intf_key = utils.get_intf_key_by_lan_alias(intfs, lan)
		print("lan intf key is "..tostring(lan_intf_key))
		local lan_filter_path = utils.get_filter_by_intf_key(filters, lan_intf_key)
		print("lan filter path is "..lan_filter_path)
		dm.SetParameterValues(lan_filter_path.."FilterBridgeReference", br_key)
	end

	-- 4. Change dhcps enable status according to ConnectionType
	local paras = {}
	inst = utils.strip_end_dot(br_path)
	inst = string.sub(inst, string.find(br_path, "Bridge.") + string.len("Bridge."))
	local landev = "InternetGatewayDevice.LANDevice."..tostring(inst)..".LANHostConfigManagement."
	local dhcpsEnable = false
	if "Bridged" ~= data["ConnectionType"] then
		dhcpsEnable = true
		update_routed_iptv_lan_ip(landev)
		--table.insert(paras, {landev.."MinAddress", "192.168.250.2"})
		--table.insert(paras, {landev.."MaxAddress", "192.168.250.254"})
	end
	table.insert(paras, {landev.."DHCPServerEnable", dhcpsEnable})

	-- 5. Update IGMPSnooping and IGMPProxy
	table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.IGMPSnoopingEnable", true})
	if "Bridged" ~= data["ConnectionType"] then
		table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.IGMPProxyEnable", true})
		table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.WanList", utils.strip_end_dot(iptv_wan)})
	end
	utils.print_paras(paras)
	dm.SetParameterValues(paras)

	return 0
end

function disable_iptv(br_key, br_path)
	print("Disable iptv ["..br_path.."] now ...")
	if -1 == br_key then
		-- Already disabled
		return 0
	end

	-- Find currently binded WAN interface
	wan_intf = get_wan_interface(filters, intfs, br_key)
	print("Got wan interface is ["..wan_intf.."]")
	if "" ~= wan_intf then
		-- Delete the WAN safely
		utils.safe_delete_wan(wan_intf)
	end

	dm.DeleteObject(br_path)
	return 0
end

local errcode = 0
local br_key, br_path = utils.get_iptv_bridge(bridges)
print("IPTV bridge key is "..tostring(br_key))

if utils.toboolean(data["Enable"]) then
	errcode = enable_iptv(br_key, br_path)
else
	errcode = disable_iptv(br_key, br_path)
end

print("Setup IPTV service return "..tostring(errcode).."====================\n\n")
utils.appenderror("errcode", errcode)
