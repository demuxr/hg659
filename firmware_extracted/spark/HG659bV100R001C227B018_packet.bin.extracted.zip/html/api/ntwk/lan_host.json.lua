require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode,host = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.",
    {"Enable", "IPInterfaceIPAddress", "IPInterfaceSubnetMask"});

local lan = {}
for k,v in pairs(host) do 
    lan.ID = k
    lan.FirstEnable = utils.toboolean(v["Enable"])
    lan.FristIP = v["IPInterfaceIPAddress"]
    lan.FirstMac = v["IPInterfaceSubnetMask"]
    local endPos = string.find(k, "IPInterface.1.")
    local lanCfg = string.sub(k, 0, endPos-1)
    print(lanCfg)
    local errcode, res = dm.GetParameterValues(lanCfg, {"MACAddress"})
    lan.MACAddress = res[lanCfg]["MACAddress"]
end

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.",
    {
        "DeviceName",
        "DomainName"
    }
);

local obj = values["InternetGatewayDevice.LANDevice.1.LANHostConfigManagement."]
lan.DevName = obj["DeviceName"]
lan.DomainName = obj["DomainName"]

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_LanDomainManage.",
    {"Enable"});

lan.ShowLanDomainEnable = false
if errcode == 0 then
    local obj = values["InternetGatewayDevice.Services.X_LanDomainManage."]
    lan.LanDomainEnable = utils.toboolean(obj["Enable"])
    lan.ShowLanDomainEnable = true
end

web.print(json.encode(lan))
