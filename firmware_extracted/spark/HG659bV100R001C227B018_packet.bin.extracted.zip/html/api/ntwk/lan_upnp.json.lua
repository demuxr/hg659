
    require('dm')
    require('web')
    require('json')
    require('utils')
    local tostring = tostring

    local errcode,upnp = dm.GetParameterValues("InternetGatewayDevice.Services.X_UPnP.", 
        {"Enable"});

    

    local upnpconf = {}
	for k,v in pairs(upnp) do 
        upnpconf.enable = utils.toboolean(v["Enable"])
    end
 web.print(json.encode(upnpconf))