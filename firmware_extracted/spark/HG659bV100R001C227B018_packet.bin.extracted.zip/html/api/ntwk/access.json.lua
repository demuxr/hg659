require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType", "PhysicalLinkStatus"})

local accesses = {}
for k,v in pairs(accessdevs) do
    local acc = {}
    acc.ID = k
    acc.AccessType = v["WANAccessType"]
    acc.Status = v["PhysicalLinkStatus"]
    table.insert(accesses, acc)
end

web.print(json.encode(accesses))
