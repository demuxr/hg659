require('web')
require('utils')

local tostring = tostring


web.downloadcfgfile()