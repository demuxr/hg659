require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode,timeout = dm.GetParameterValues("InternetGatewayDevice.UserInterface.X_Web.", {"Timeout"});

local resp = {}
for k,v in pairs(timeout) do 
    resp.idletime = v["Timeout"]
end

web.print(json.encode(resp))