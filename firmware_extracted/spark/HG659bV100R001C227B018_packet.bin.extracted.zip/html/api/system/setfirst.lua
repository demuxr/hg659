local dm = require('dm')

local err = dm.SetParameterValues("InternetGatewayDevice.DeviceInfo.X_IsFirst", "1")
