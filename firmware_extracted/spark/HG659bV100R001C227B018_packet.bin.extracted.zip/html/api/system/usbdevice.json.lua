require('dm')
require('utils')

--datakard--
local usbdevice = {}

--datacard
web.exec("atcmd ati display >/var/datacard")
fh = io.open("/var/datacard", "r")
line = fh:read("*a")
fh:close()
web.exec("rm /var/datacard")
ip = string.find(line, "Model:")
if ip ~= nil then
    ep = string.find(line, "Revision:")
    local datacard = {}
    datacard.Name = string.sub(line, ip+string.len("Model:"), ep-1)
    datacard.Capacity ="0"
    datacard.UsedSpace ="0"
    datacard.DeviceType = "datacard"
    table.insert(usbdevice, datacard)
end
--usb--
local errcode,usbPhysicalStorage = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.{i}.PhysicalMedium.{i}.", {"Name","Capacity"})

if usbPhysicalStorage ~= nil then
    local errcode,usbStorage = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.{i}.LogicalVolume.{i}.", {"PhysicalReference","UsedSpace","Capacity"})
    if usbStorage ~= nil then    
        for pk,pv in pairs(usbPhysicalStorage) do
            local usb = {}    
            usb.Name = pv["Name"]
            local used = 0
            local capa = 0
            for k,v in pairs(usbStorage) do
                if v["PhysicalReference"].."." == pk then
                    capa = capa + v["Capacity"]
                    used = used + v["UsedSpace"]
                end
            end
            usb.Capacity = capa
            usb.UsedSpace = used
            usb.DeviceType = "storage"
            table.insert(usbdevice, usb)
        end
    end
end

--printer--
local errcode,printervalues = dm.GetParameterValues("InternetGatewayDevice.Services.X_Printer.", {"Name"})

if printervalues ~= nil then
    local obj = printervalues["InternetGatewayDevice.Services.X_Printer."]
    local printer = {}
    if obj["Name"] ~= 'Unknown' then
        printer.Name = obj["Name"] 
        printer.Capacity = "0"
        printer.UsedSpace = "0"
        printer.DeviceType = "printer"        
        table.insert(usbdevice, printer)
    end
end

web.print(json.encode(usbdevice))
