require('dm')
require('web')
require('json')
require('utils')

local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.X_Power.AutoPowerSave.", 
    {"CPUEnable", "DSLEnable"});
print(errcode, values)

local obj = values["InternetGatewayDevice.Services.X_Power.AutoPowerSave."]

obj.Enable = utils.toboolean(obj["Enable"])

local autopowersave = {}
autopowersave.CPUEnable = utils.toboolean(obj["CPUEnable"])
autopowersave.DSLEnable = utils.toboolean(obj["DSLEnable"])

web.print(json.encode(autopowersave))