require('dm')
require('utils')
require('web')
require('json')
local tonumber = tonumber
local  print = print

local ApNums = 0
local ApNums_30 = 0
local ApNums_50 = 0

local instance = 1

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand"
    }
);

function get_WifiEnable(frequency, ssidEnble)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return utils.toboolean(v["Enable"]) and ssidEnble
        end
    end

    return false
end

if FormData["type"] ~= nil then
    instance = tonumber(FormData["type"])
end

local maps = {
	Channel = "Channel",
	AutoChannelEnable = "AutoChannelEnable",
	Enable = "Enable",
	X_OperatingFrequencyBand = "X_OperatingFrequencyBand",
	SSID = "SSID",
    BSSID = "BSSID",
	TransmitPower = "TransmitPower",
	BeaconType = "BeaconType",
	BasicEncryptionModes = "BasicEncryptionModes",
    BasicAuthenticationMode = "BasicAuthenticationMode",
    WEPEncryptionLevel = "WEPEncryptionLevel",
    WEPKeyIndex = "WEPKeyIndex",
    WPAEncryptionModes = "WPAEncryptionModes",
    IEEE11iEncryptionModes = "IEEE11iEncryptionModes",
    X_MixedEncryptionModes = "X_MixedEncryptionModes",
    X_Wlan11NBWControl = 'X_Wlan11NBWControl',
    X_WlanStandard = 'X_WlanStandard',
    MaxBitRate = "MaxBitRate",
    RegulatoryDomain = "RegulatoryDomain"
}

local domain = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..instance.."."
local errcode, wlanVals = dm.GetParameterValues(domain, maps)
	
wlanObj = wlanVals[domain]

if "Basic" == wlanObj["BeaconType"] and "None" == wlanObj["BasicEncryptionModes"] then
    wlanObj.BeaconType = "None"
end
if wlanObj["X_WlanStandard"] == "b/g/n" or wlanObj["X_WlanStandard"] == "a/n/ac" then
	wlanObj["Bandwidth"] = wlanObj["X_Wlan11NBWControl"]
else
	wlanObj["Bandwidth"] = wlanObj["MaxBitRate"]
end

wlanObj.Enable = get_WifiEnable(wlanObj.X_OperatingFrequencyBand, wlanObj.Enable)
wlanObj.AutoChannelEnable = utils.toboolean(wlanObj.AutoChannelEnable)

local errcode, lanVals = dm.GetParameterValues(domain.."X_WLANDiagnostic.APList.{i}.",
    {"Signal"})
if lanVals ~= nil then
    for k, v in pairs(lanVals) do
    	ApNums = ApNums + 1
    	if v["Signal"] <= 30 then
    		ApNums_30 = ApNums_30 + 1
    	elseif v["Signal"] <= 50 then
    		ApNums_50 = ApNums_50 + 1
    	end
    end
end

wlanObj['ApNums'] = ApNums

if ApNums_30 >= 5 then
	wlanObj["Signal"] = 0
elseif ApNums_30 + ApNums_50 >= 5 then
	wlanObj["Signal"] = 1
else
	wlanObj["Signal"] = 2
end

web.print(json.encode(wlanObj))
