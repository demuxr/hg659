require('web')
require('utils')

local tostring = tostring

web.setpkgheadercontenttype("application/octet-stream; charset=utf-8")
web.setpkgheaderdesposition("attachment; filename=syslog.txt")
web.setpkgheadercachecontrol("must-revalidate")

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_SyslogConfig.", { "DisplayType", "DisplayLevel" });
local obj = values["InternetGatewayDevice.X_SyslogConfig."]

local ret = web.getlogcontent(obj["DisplayLevel"], obj["DisplayType"], 1024)

local err_dev, dev_values = dm.GetParameterValues("InternetGatewayDevice.DeviceInfo.",
    {
        "ProductClass",
        "SerialNumber",
        "HardwareVersion",
        "SoftwareVersion"
    }
);
local dev_obj = dev_values["InternetGatewayDevice.DeviceInfo."]
local logcontent = "Manufacturer:Huawei Technologies Co., Ltd."
logcontent = logcontent.."\nProduct Style:"..dev_obj["ProductClass"]
logcontent = logcontent.."\nSerial Number:"..dev_obj["SerialNumber"]
logcontent = logcontent.."\nHardware Version:"..dev_obj["HardwareVersion"]
logcontent = logcontent.."\nSoftware Version:"..dev_obj["SoftwareVersion"].."\n\n"

f = io.open("/var/logtemp", "r")
if f == nil then
    io.close()
else
    file = f:read("*a")
    local logstr = string.gsub(file, "|", " ")
    logcontent = string.char(239,187,191)..logcontent..logstr
    f:close()
end

web.print(logcontent)
