require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_SyslogConfig.",
    {
        "Enable",
        "Level",
        "LogServerEnable",
        "MainServer",
        "MainServerPort",
        "MinorServer",
        "MinorServerPort"
    }
);

local obj = values["InternetGatewayDevice.X_SyslogConfig."]

local logcfg = {}

logcfg.LogEnable = utils.toboolean(obj["Enable"])
logcfg.LogLevel = obj["Level"]
logcfg.LogServerStatus = utils.toboolean(obj["LogServerEnable"])
logcfg.PrimaryServerAddress = obj["MainServer"]
logcfg.PrimaryServerPort = obj["MainServerPort"]
logcfg.SecondServerAddress = obj["MinorServer"]
logcfg.SecondServerPort = obj["MinorServerPort"]

web.print(json.encode(logcfg))
