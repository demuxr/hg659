local utils = require('utils')
require('web')

local log_type = 0
if data ~= nil then
    err,needreboot, paramerror = dm.SetParameterValues({
        {"InternetGatewayDevice.X_SyslogConfig.DisplayType", data["DisplayType"]},
        {"InternetGatewayDevice.X_SyslogConfig.DisplayLevel", data["DisplayLevel"]}
    });

    utils.appenderror("errcode", err);
else
    local login_user, login_level = web.getuserinfo()
    err = web.clearlog(log_type, login_user)
    utils.appenderror("errcode", err);
end
