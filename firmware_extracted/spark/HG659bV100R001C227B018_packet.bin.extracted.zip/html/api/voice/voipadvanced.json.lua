local dm  = require('dm')
local web = require('web')
local json = require('json')

local  SipNums = {}	
local err, Profilevalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.", {"Name"});
for id, ProfileInfo in pairs(Profilevalues) do
	local err, Numbervalues = dm.GetParameterValues(id.."Line.{i}.", {"DirectoryNumber", "X_ClipEnable", "X_DTMFMethod", "X_FaxOption", });
	if nil ~= Numbervalues then
		for lineid, NumberInfo in pairs(Numbervalues) do
			local SipNum_obj = {}
			SipNum_obj.ID = lineid
			SipNum_obj.Number = NumberInfo["DirectoryNumber"]
			SipNum_obj.CLIP = utils.toboolean(NumberInfo["X_ClipEnable"])
			SipNum_obj.DTMFMode = NumberInfo["X_DTMFMethod"]
			SipNum_obj.FaxOption = NumberInfo["X_FaxOption"]		
			local err, Codecvalues = dm.GetParameterValues(lineid.."Codec.List.{i}.", {"Codec", "Priority", "Enable"});
			local Codec = {}
			for codecid, CodecInfo in pairs(Codecvalues) do
				local Codec_obj = {}
				Codec_obj.ID = codecid
				if  CodecInfo["Enable"] == 0 then
					Codec_obj.Codec = "NULL"
				else
					Codec_obj.Codec = CodecInfo["Codec"]
				end
				Codec_obj.Priority = CodecInfo["Priority"]
				table.insert(Codec, Codec_obj)
			end
			table.sort(Codec, function (a, b) return a.Priority < b.Priority end)
			local codeclist = ""
			for k,v in pairs(Codec) do
				if codeclist == "" then
					codeclist = v["Codec"]
			    else
					codeclist = codeclist..","..v["Codec"]
			    end
			end
			SipNum_obj.CoDecList = codeclist
			SipNum_obj.Codec = Codec
			table.insert(SipNums, SipNum_obj)
		end
	end
end

web.print(json.encode(SipNums))
