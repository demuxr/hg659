local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues

local errcode,digitmap = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.",{"DigitMap"});

local map = {}
local obj = digitmap["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig."]

map.DigitMap = obj["DigitMap"]

web.print(json.encode(map))