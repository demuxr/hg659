require('web')
require('dm')
local utils = require('utils')

local voip_advanced_maps = {
	Support100REL="X_PrackSupport"
}
local paras = {}
utils.GenSetObjParamInputsEx("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", data, voip_advanced_maps, paras)
local err,needreboot, paramerror = dm.SetParameterValues(paras)
 utils.responseErrorcode(err, paramerror, voip_advanced_maps)
	 