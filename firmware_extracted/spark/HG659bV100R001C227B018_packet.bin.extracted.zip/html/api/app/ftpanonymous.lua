require('web')
local utils = require('utils')

if data["AllPath"] == nil or data["Enable"] == nil or data["ReadOnly"] == nil or data["Path"] == nil or data["Base64Path"] == nil then
    utils.appenderror("errcode", 9003)
    return
end

local enablevalue
if data["Enable"] then
    enablevalue = "1"
else
    enablevalue = "0"
end

function check_dir_legal(dir)
    local pos = string.find(dir, '^/')
    if pos == nil then
        print("dir check error1 ")
        return false
    end

    pos = string.find(dir, '/%.$')
    if pos ~= nil then
        print("dir check error2 ")
        return false
    end

    pos = string.find(dir, '/%.%.$')
    if pos ~= nil then
        print("dir check error3 ")
        return false
    end

    pos = string.find(dir, '/%./')
    if pos ~= nil then
        print("dir check error4 ")
        return false
    end

    pos = string.find(dir, '/%.%./')
    if pos ~= nil then
        print("dir check error5 ")
        return false
    end

    pos = string.find(dir, "%.%.")
    if pos ~= nil then
        print("dir check error6 ")
        return false
    end
    return true
end

if data["AllPath"] ~= '1' and data["AllPath"] ~= 1 then
    local checkdir = check_dir_legal(data["Path"])
    if checkdir ~= true then
        utils.appenderror("Menu.tr140path", "Menu.ErrorTitle")
        utils.appenderror("errcode", 140)
        return
    end
end

ret = web.setanonymous(enablevalue, data["AllPath"], data["ReadOnly"], data["Path"], data["Base64Path"])
if ret ~= 0 then
   utils.appenderror("fs.storage.pwd", "Menu.ErrorTitle")
end
utils.appenderror("errcode", ret)
