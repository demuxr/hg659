require('dm')
require('web')
require('json')
require('utils')
local print = print
local tonumber = tonumber

local qosclasses = {}

local errcode,policerVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Policer.{i}.", 
    {"MeterType", "CommittedRate", "PeakRate", "X_DownCommittedRate", "X_DownPeakRate"});

local array = {}
i = 1
for k,v in pairs(policerVals) do
    local p,e = utils.findLastPoint(k)
    array[i] = tonumber(p)
    i = i+1
end
table.sort(array)

function apendPolicerData(classval, policerIndex)
    if array[policerIndex] == nil then
        return
    end
    local domain = 'InternetGatewayDevice.QueueManagement.Policer.'..array[policerIndex]..'.'
    for k,v in pairs(policerVals) do
        if k == domain then
            classval["DownCommittedRate"] = v["X_DownCommittedRate"]
            classval["DownPeakRate"] = v["X_DownPeakRate"]
            classval["UpCommittedRate"] = v["CommittedRate"]
            classval["UpPeakRate"] = v["PeakRate"]
            classval["MeterType"] = v["MeterType"]
            classval["PolicerID"] = k
            return
        end
    end
end

local errcode, classVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Classification.{i}.", 
    {
        "ClassificationEnable", "SourceIP", "SourceIPEnd", "SourceMask", "SourceMACAddress", "ClassInterface",
        "SourcePort", "SourcePortRangeMax", "DestPort", "DestPortRangeMax", "ClassificationName",
        "ClassQueue", "ClassPolicer", "APPName", "X_Type", "Protocol", "DSCPMark",
        "X_ShowFlag"});

for k,v in pairs(classVals) do
    if v["X_ShowFlag"] == 1 then
        local newClass = {}
        newClass["ID"] = k
        newClass["Name"] = v["ClassificationName"]
        newClass["ClassQueue"] = v["ClassQueue"]
        newClass["SourceIP"] = v["SourceIP"]
        newClass["SourceIPEnd"] = v["SourceIPEnd"]
        newClass["SourceMACAddress"] = v["SourceMACAddress"]
        newClass["LANInterface"] = v["ClassInterface"]
        newClass["ApplicationID"] = v["APPName"]
        newClass["Type"] = v["X_Type"]
        newClass["DSCPMark"] = v["DSCPMark"]
        newClass["Enable"] = utils.toboolean(v["ClassificationEnable"])
        newClass["SourceMask"] = v["SourceMask"]
        apendPolicerData(newClass, v["ClassPolicer"])

        table.insert(qosclasses, newClass)
    end
end

utils.multiObjSortByID(qosclasses)
web.print(json.encode(qosclasses))

