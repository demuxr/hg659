local utils = require('utils')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="EnableCWMP",
    acsurl = "URL",
    acsname = "Username",
    inform = "PeriodicInformEnable",
    interval = "PeriodicInformInterval",
    conname = "ConnectionRequestUsername",
    conport = "X_ConnReqPort",
    cert = "X_SSLCertEnable"
}

if data["acspwd"] ~= _G["defaultPasswd"] then
    maps["acspwd"] = "Password";
end
if data["conpwd"] ~= _G["defaultPasswd"] then
    maps["conpwd"] = "ConnectionRequestPassword";
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
