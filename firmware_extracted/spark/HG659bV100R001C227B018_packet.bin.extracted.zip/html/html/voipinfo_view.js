Atp.LoadHelper.appendLangRes("voipinfo_res.js");
Atp.LoadHelper.appendJs("/js/voipinfo.js");

Atp.LoadHelper.loadAll();

Atp.VoipInfoContainer = Atp.PageContainerView.extend ({
    prefixName: 'Telephone',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.VoipInfoCollapseView }} \
            {{ view Atp.CsInfoCollapseView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.VoipInfoContainer, "voipinfo");