Atp.LoadHelper.appendLangRes("tr069_res.js");
Atp.LoadHelper.appendJs("/lib/jquery.form.min.js");
Atp.LoadHelper.appendJs("/js/tr069.js");

Atp.LoadHelper.loadAll();

Atp.CwmpContainerView = Atp.PageContainerView.extend ({
    prefixName:'page',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{#if Atp.UserLevelController.isAdminUser}} \
                {{ view Atp.RMcollapse }} \
            {{/if}} \
            {{ view Atp.Stuncollapse }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.CwmpContainerView, "tr069");