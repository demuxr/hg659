Atp.LoadHelper.appendLangRes("ddns_res.js");
Atp.LoadHelper.appendJs("/js/ddns.js");
Atp.LoadHelper.appendLangRes("sntp_res.js");
Atp.LoadHelper.appendJs("/js/sntp.js");
Atp.LoadHelper.appendLangRes("mcast_res.js");
Atp.LoadHelper.appendJs("/js/mcast.js");
Atp.LoadHelper.loadAll();


Atp.NetworkServiceContainerView = Atp.PageContainerView.extend ({
	prefixName: "network.service.page",
	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
            {{view Atp.DDNSView}} \
			{{#if Atp.UserLevelController.isAdminUser}} \
            {{view Atp.SntpView}} \
            {{view Atp.McastView}} \
            {{/if}} \
             ')
	})
});

Atp.MenuController.createSubmenuView(Atp.NetworkServiceContainerView,"Network_services");
