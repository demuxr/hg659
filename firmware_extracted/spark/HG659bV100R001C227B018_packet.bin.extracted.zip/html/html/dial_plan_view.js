Atp.LoadHelper.appendLangRes("dial_plan_res.js");
Atp.LoadHelper.appendJs("/js/dial_plan.js");

Atp.LoadHelper.loadAll();

Atp.DialPlanContainerView = Atp.PageContainerView.extend ({
    prefixName: 'dialplan',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
        	{{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.EmergencyDialCollapseView }} \
            {{/if}} \
            {{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.PrefixDialCollapseView}} \
            {{else}} \
            {{ view Atp.PrefixDialCollapseView bClosed=false}} \
            {{/if}} \
            {{ view Atp.QuickDialCollapseView }} \
            {{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.DigitMapCollapseView }} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.DialPlanContainerView, "dail_plan");