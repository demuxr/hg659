Atp.LoadHelper.appendLangRes("voip_advanced_res.js");
Atp.LoadHelper.appendJs("/js/voip_advanced.js");

Atp.LoadHelper.loadAll();

Atp.VoipAdvancedContainer = Atp.PageContainerView.extend ({
    prefixName: 'advance',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
        	{{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.VoIPCollapseView }} \
            {{ view Atp.TapiCollapseView }} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.VoipAdvancedContainer, "voice_advalced");