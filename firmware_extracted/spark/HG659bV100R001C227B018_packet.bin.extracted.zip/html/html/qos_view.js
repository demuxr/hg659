Atp.LoadHelper.appendLangRes("qos_res.js");
Atp.LoadHelper.appendLangRes("application_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/application.js");
Atp.LoadHelper.appendJs("/js/qos.js");
Atp.LoadHelper.appendJs("/js/qosclass.js");

Atp.LoadHelper.loadAll();

Atp.QosContainerView = Atp.PageContainerView.extend ({
    prefixName: "qos",

    dataView: Em.View.extend({
        template: Em.Handlebars.compile('\
        	{{#if Atp.UserLevelController.isAdminUser}} \
            {{view Atp.QosView}} \
            {{view Atp.QosClassView}} \
            {{view Atp.ApplicationWindowView type=3 elementId="Qos_application_id"}} \
            {{view Atp.LanDeviceWindowView id="qos_landevice_window"}} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.QosContainerView,"qos");
