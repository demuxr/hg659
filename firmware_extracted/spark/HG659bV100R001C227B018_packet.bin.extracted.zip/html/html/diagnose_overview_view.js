Atp.LoadHelper.appendLangRes("diagnose_overview_res.js");
Atp.LoadHelper.appendLangRes("wlan_res.js");
Atp.LoadHelper.appendLangRes("device_mngt_res.js");
Atp.LoadHelper.appendJs("/js/diagnose_internet.js");
Atp.LoadHelper.appendJs("/js/diagnose_button.js");
Atp.LoadHelper.appendJs("/js/diagnose_usb.js");
Atp.LoadHelper.appendJs("/js/diagnose_lan.js");
Atp.LoadHelper.appendJs("/js/device_mngt.js");
Atp.LoadHelper.appendJs("/js/diagnose_led.js");
Atp.LoadHelper.appendJs("/js/diagnose_wifi.js");
Atp.LoadHelper.appendJs("/js/diagnose_overview.js");

Atp.LoadHelper.loadAll();

Atp.DiagOverviewContainer = Atp.PageContainerView.extend ({
    titleId: "Menu.diagnose_overview",
    descriptionId: "diagnose_overview.description",
    
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            <div class="diagnosediv margintop_10 hiden_overpart"> \
                {{view Atp.InternetDiagnosticsView}} \
                {{view Atp.LanDiagnosticsView}} \
                {{view Atp.WlanDiagnosticsView}} \
                <div class="diagnosemoreback accordion-toggle clearboth paddingleft_15 paddingtop_5 paddingbottom_5 third_menu_font" onClick="Open_Close_Advance()"> \
                    <div id="Open_Close_Advance_Diagnose"><label class="pull-left width_10 accordion-toggle ic-close ie6image"></label></div><span>{{t diagnose_overview.advanced}}</span> \
                </div> \
                <div id="advanced" class="clearboth hide"> \
                    {{view Atp.WlanAdvanceDiagnosticsView}} \
                {{view Atp.UsbDiagnosticsView}} \
                    {{view Atp.LedDiagnosticsView}} \
                    {{view Atp.ButtonDiagnosticsView}} \
                    <div class="divtopborder clearboth"> \
                        <div class="paddingtop_5 paddingbottom_5 pull-right paddingright_20"> \
                            <a class="clearboth accordion-toggle text_underline linkcolor" id="diagnose_overview_restore_factory" {{action "restore_factory" target="Atp.DiagnoseRestoreController"}}>{{t diagnose_overview.Repair}}</a> \
                        </div> \
                    </div> \
                </div> \
            </div> \
            {{view Atp.OverviewDiagView}} \
            {{view Atp.OverviewDiagSaveView}} \
            {{view Atp.ModalView controllerBinding="Atp.DiagnoseModalController"}} \
        ')

    })
});

Atp.MenuController.createSubmenuView(Atp.DiagOverviewContainer, "diagnose_overview");