
--lua_content_for__ include begin
 web.print('\r\
');  html.link('/css/login.css')  web.print('\r\
');  html.lang('wizard_res.js')  web.print('\r\
');  html.lang('wan_res.js')  web.print('\r\
');  html.script('/js/pin.js')  web.print('\r\
');  html.script('/js/link.js')  web.print('\r\
');  html.script('/js/wizardwan.js')  web.print('\r\
');  html.script('/lib/customInput.jquery.js')  web.print('\r\
');  html.script('/js/pvcscan.js')  web.print('\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
'); 
--lua_content_for__ script_tag begin
 web.print('\r\
<script language="JavaScript" type="text/javascript">\r\
\r\
$(document).ready(function() {\r\
	pageload();\r\
	setTimeout("adjust_radio()","50");\r\
  	$("body").keydown(function(e){ \r\
	    var curKey = e.which; \r\
	    if(curKey == 13){\r\
	    if($("#index_username").val().length > 0)\r\
	    {\r\
	    	$("#loginbtn").click(); \r\
	    }\r\
	    return false; \r\
	    } \r\
	});	\r\
});\r\
\r\
function adjust_radio()\r\
{\r\
	$(\'input\').customInput();\r\
}\r\
</script>\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
<div class="container">	\r\
	<div class="row rounddiv wizard_config_div">\r\
	  	{{view Atp.InternetWizardHeader}}\r\
	  	<div id="contentPage">\r\
	  		{{#if Atp.SWanController.content.isDatacardMode}}\r\
	  		  {{view Atp.WizardUmtsView}}\r\
	  		{{else}}\r\
	  			{{#if Atp.SWanController.content.isPPPoA}}\r\
	  				{{view Atp.WizardAccountView}}\r\
	  			{{else}}\r\
	    	  		{{view Atp.WizardConnTypeView}}\r\
	    	  	{{/if}}\r\
	    	{{/if}}\r\
			<div class="clearboth ok_calcel_btn internet_ok_calcel margintop_15">\r\
				<button class="atp_button" id="wizard_cancel_ctrl" onClick="Goto_wizard_home();">{{t Menu.Cancel}}</button>\r\
				<button class="atp_button" id="wizard_next_ctrl" {{action "wizardPost" target="Atp.SWanController"}}>{{t Menu.Next}}</button>\r\
			</div>\r\
	  	</div>\r\
	</div>\r\
	<div id="loginblank" class="loginshadow hide"></div>\r\
</div>\r\
'); 