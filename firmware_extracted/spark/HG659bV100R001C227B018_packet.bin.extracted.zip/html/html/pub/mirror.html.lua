
--lua_content_for__ include begin
 web.print('\r\
');  html.lang('mirror_res.js')  web.print('\r\
');  html.script('/js/mirror.js')  web.print('\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
'); 
--lua_content_for__ script_tag begin
 web.print('\r\
<script language="JavaScript" type="text/javascript">\r\
</script>\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
<div class="container">	\r\
	<div class="row rounddiv wizard_config_div">    	\r\
	  {{view Atp.InternetWizardHeader operation="Menu.Empty" title="mirror.title"}}\r\
	  <div id="contentPage">\r\
	  	<div class="internet_config">\r\
	  		{{view Atp.MirrorView}}\r\
	  	</div>\r\
	  </div>\r\
	</div>\r\
</div>\r\
'); 