
Atp.LoadHelper.appendLangRes("parent_control_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/parent_control.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.loadAll();

Atp.ParentControlContainerView = Atp.PageContainerView.extend ({
	prefixName: "parent_control",
	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
            {{view Atp.MacFilterView}} \
            {{view Atp.UrlFilterView}} \
            {{view Atp.LanDeviceWindowView id="parent_control_landevice_window"}} \
        ')
	})
});

Atp.MenuController.createSubmenuView(Atp.ParentControlContainerView, "parent_control");