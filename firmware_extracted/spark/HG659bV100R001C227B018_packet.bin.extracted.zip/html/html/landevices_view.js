Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendLangRes("wan_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.loadAll();

Atp.LanDevicesContainerView = Atp.PageContainerView.extend({
	prefixName: "landev",
	dataView: Em.View.extend ({
    	template: Em.Handlebars.compile('\
			  {{view Atp.LanDeviceCollapseView}}')
	})
});

Atp.MenuController.createSubmenuView(Atp.LanDevicesContainerView, "landevices");