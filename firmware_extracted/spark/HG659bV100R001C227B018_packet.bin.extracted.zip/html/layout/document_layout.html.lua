 web.print('<!DOCTYPE html>\
<!--[if lt IE 7 ]><html lang="en" class="ie6"> <![endif]--> \
<!--[if IE 7 ]><html lang="en" class="ie7"> <![endif]--> \
<!--[if IE 8 ]><html lang="en" class="ie8"> <![endif]--> \
<!--[if IE 9 ]><html lang="en" class="ie9"> <![endif]-->\
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en"> <!--<![endif]-->\
<head>\
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\
<meta name="viewport" content="width=device-width, initial-scale=1.0">\
<meta name="description" content="">\
<meta name="author" content="">\
');  html.csrf_meta_tag()  web.print('\
<title>Business Gateway</title>\
\
');  html.link('/css/ar_cat_public.css')  html.link('/css/ar_login.css')  web.print('\
');  html.link('/css/ar_network.css')  web.print('\
');  html.link('/css/ar_zTreeStyle.css')  web.print('\
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->\
<!--[if lt IE 9]>\
');  html.script('/js/html5.js')  web.print('\
<![endif]-->\
</head>\
\
<body data-spy="scroll" data-target=".bs-docs-sidebar">\
<!-- Navbar======================top menu============================ -->\
<div class="navbar navbar-fixed-top">\
	<div class="container top_div">\
		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" style="margin-top:17px;">\
			<span class="icon-bar"></span>\
			<span class="icon-bar"></span>\
	       	<span class="icon-bar"></span>\
       	</a>\
       	<ul class="nav pull-left logo_png">\
			<li><div class="ic-logo"></div></li>\
			<li class="product_title text_center">Business Gateway</li>\
		</ul>\
		<script type="text/x-handlebars">\
		<div class="nav-collapse collapse paddingtop_10">\
            <ul class="nav pull-left">\
                <li class="divider-vertical-language" style="margin-top:10px;"></li>\
                <li class="product_name text_center paddingleft_10">HG659b</li>\
            </ul>\
            <ul class="nav pull-right">\
                <li class="text_center paddingleft_10"><a href="#">');  web.print(web.getuserinfo() ); web.print('</a></li> \
                <li class="text_center paddingleft_10">\
                <button class="signout margintop_8 fontsize_10" type="button" {{action "postData" target="Atp.LoginOutController"}}>{{t Menu.Signout}}</button></li>\
                <li class="divider-vertical-language"></li> \
					{{view Atp.LanguageBlock}}\
                <li class="divider-vertical-language"></li>\
                <li class="marginright_5 text_center paddingleft_10"><a target="_blank" href="/doc/help.html">{{t Menu.help}}</a></li>\
            </ul>\
        </div>\
	</script>\
	</div><!--/.container-->\
	<!--here for top menu-->\
	<div class="container shadow height_52 top_menu_back_img" id="menu_test">\
    </div>\
    <!--here for hide menu-->\
    <div class="hide min_height_52 width_100p top_menu_back_img" id="menu_for_hide">\
    </div>\
</div>\
<!--body-->\
<div class="main-container">\
	<div class="container">\
	<div class="row">\
			<div class="span3 bs-docs-sidebar" id="accordion">\
				<ul class="nav nav-list">\
				  <li class="nav-header">\
				    Controller Helpers\
				  </li>\
				  <li>\
				    <a href="#single_obj_controller">Atp.SingleObjController</a>\
				  </li>\
				  <li>\
				    <a href="#multi_obj_controller">Atp.MultiObjController</a>\
				  </li>\
				  <li class="nav-header">\
				    View Helpers\
				  </li>\
				  <li>\
				    <a href="#text_field_view">Atp.TextField</a>\
				  </li>\
				  <li>\
				    <a href="#checkbox_view">Atp.MultiObjController</a>\
				  </li>\
				  <li>\
				    <a href="#label_text_view">Atp.LabelView</a>\
				  </li>\
				  <li class="nav-header">\
				  	Lua Helpers\
				  </li>\
				  <li>\
				  	<a href="#lua_html_view">html.lua</a>\
				  </li>\
				  <li>\
				  	<a href="#lua_web_view">web.lua</a>\
				  </li>\
				  <li>\
				  	<a href="#lua_dm_view">dm.lua</a>\
				  </li>\
				  <li class="nav-header">\
				  	FreeMarker Helpers\
				  </li>\
				  <li>\
				  	<a href="#freemarker">freemarker</a>\
				  </li>\
				</ul>\
			</div>\
			<div id="content" class="span8">\
				');  html.yield()  web.print('\
			</div>\
    </div>\
</div>\
</div>\
\
<!-- Footer================================================= -->\
<div class="navbar navbar-fixed-bottom">\
	<footer>\
		<p align="center">Copyright ©Huawei Technologies Co., Ltd. 2014. All <a class="navbar" target="_blank" href="/html/copyright.html">rights</a> reserved. </p>\
		<script type="text/x-handlebars">\
		{{view Atp.HeartbeatView}}\
		</script>\
	</footer>\
</div>\
<!-- Le javascript================================================== -->\
<!-- Placed at the end of the document so the pages load faster -->\
');  html.gzrawscript('/lib/cat_liblayout.js')  web.print('\
');  html.rawlang('menu_res.js')  web.print('\
\
\
');  html.yield('script_tag')  web.print('\
</body>\
</html>\
'); 