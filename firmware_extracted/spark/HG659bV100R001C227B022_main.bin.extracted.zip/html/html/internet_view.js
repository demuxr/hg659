Atp.LoadHelper.appendLangRes("wan_res.js");
Atp.LoadHelper.appendLangRes("pin_res.js");
Atp.LoadHelper.appendLangRes("tunnel_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/pin.js");
Atp.LoadHelper.appendJs("/js/link.js");
Atp.LoadHelper.appendJs("/js/wan.js");
Atp.LoadHelper.appendJs("/js/tunnel.js");
Atp.LoadHelper.appendJs("/js/vpn.js");

Atp.LoadHelper.appendJs("/js/internet.js");
Atp.LoadHelper.appendJs("/js/pvcscan.js");
Atp.LoadHelper.loadAll();

Atp.InternetContainerView = Atp.PageContainerView.extend ({
    prefixName: "wan",
    dataView: Em.View.extend({
        template: Em.Handlebars.compile(' \
            {{view Atp.InternetStatusView}} \
            {{view Atp.InternetView}} \
        ')
    })

});

Atp.MenuController.createSubmenuView(Atp.InternetContainerView,"internet");
AtpValidator.registerCallback("MSS", callback_check_mss_value);
AtpValidator.registerCallback("Password", callback_check_ppp_password_value);
AtpValidator.registerCallback("DialNum", callback_is_dial_number);