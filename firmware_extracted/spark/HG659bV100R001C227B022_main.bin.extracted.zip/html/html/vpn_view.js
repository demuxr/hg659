Atp.LoadHelper.appendLangRes("vpn_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendLangRes("tunnel_res.js");
utilLoadJavascript("/lib/jquery.form.min.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/vpn_tunnel.js");
Atp.LoadHelper.appendJs("/js/link.js");
Atp.LoadHelper.appendJs("/js/wan.js");
Atp.LoadHelper.appendJs("/js/vpn.js");
Atp.LoadHelper.loadAll();

Atp.VpnContainerView = Atp.PageContainerView.extend ({
	prefixName: "vpn",
	dataView: Em.View.extend ({
		template: Em.Handlebars.compile(' \
            {{view Atp.VpnSingleView}} \
            {{view Atp.IpsecView}} \
            {{view Atp.TunnelExView}} \
            {{view Atp.LanDeviceWindowView id="vpn_landevice_window"}} \
        ')
	})
    
});

Atp.MenuController.createSubmenuView(Atp.VpnContainerView,"vpn");