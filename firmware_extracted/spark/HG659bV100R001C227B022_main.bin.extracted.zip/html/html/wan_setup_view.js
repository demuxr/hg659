
Atp.LoadHelper.appendLangRes("wan_res.js");
Atp.LoadHelper.appendLangRes("pin_res.js"); 
Atp.LoadHelper.appendJs("/js/pin.js");
Atp.LoadHelper.appendJs("/js/link.js");
Atp.LoadHelper.appendJs("/js/wan.js");

Atp.LoadHelper.loadAll();

Atp.WanSetupContainer = Atp.PageContainerView.extend ({
        prefixName: 'wan',
    pageload: function(){
        Em.Logger.log("wan setup pageload");
        AtpValidator.registerCallback("MSS", callback_check_mss_value);
        AtpValidator.registerCallback("Password", callback_check_ppp_password_value);
        AtpValidator.registerCallback("DialNum", callback_is_dial_number);
            Atp.PinController.load(function () {
                Atp.WanbackupController.load();
            });
        reloadWanData();
    },

    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{view Atp.ModalView controllerBinding="Atp.WanModalController"}} \
            {{view Atp.WanContainerView id="wan_container"}} \
            {{#if Atp.UserLevelController.isAdminUser}} \
                {{#if Atp.WanController.showpwdtip }} \
                    {{view Atp.AddWanCtrl }} \
                {{/if}} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.WanSetupContainer, "internet");
