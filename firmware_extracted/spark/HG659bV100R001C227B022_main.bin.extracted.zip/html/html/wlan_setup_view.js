Atp.LoadHelper.appendLangRes("wlan_res.js");
Atp.LoadHelper.appendLangRes("wizard_res.js");
Atp.LoadHelper.appendJs("/js/wlanradio.js");
Atp.LoadHelper.appendJs("/js/wlan.js");
Atp.LoadHelper.loadAll();

Atp.WlanSetupContainerView = Atp.PageContainerView.extend ({
    prefixName: "wlan",

    pageload: function(){
        Atp.WlanObjs.load();
        Atp.WlanRadioController.load();
    },

    dataView: Em.View.extend({
        template: Em.Handlebars.compile('\
                    {{view Atp.WlanBasicSettingViewCollapse}} \
            {{view Atp.WlanSsidsViewCollapse isVisibleBinding="Atp.WlanRadioController.content.Enable"}} \
            {{view Atp.WlanSendSettingViewCollapse isVisibleBinding="Atp.WlanRadioController.content.Enable"}} \
                    {{ view Atp.ModalView controllerBinding="Atp.WlanRebootModalController"}} \
        ')
    })
    
});

Atp.MenuController.createSubmenuView(Atp.WlanSetupContainerView, "wlan");

