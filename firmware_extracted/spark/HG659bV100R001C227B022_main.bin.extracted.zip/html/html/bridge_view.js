Atp.LoadHelper.appendLangRes("bridge_res.js");
Atp.LoadHelper.appendJs("/js/bridge.js");

Atp.LoadHelper.loadAll();

Atp.BridgeContainerView = Atp.PageContainerView.extend ({
    prefixName:'bridge',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
        	{{view Atp.BridgeView}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.BridgeContainerView, "bridge");