Atp.LoadHelper.appendLangRes("voip_provider_res.js");
Atp.LoadHelper.appendJs("/lib/base64.js");
Atp.LoadHelper.appendJs("/js/voip_provider.js");

Atp.LoadHelper.loadAll();

Atp.VoipProviderContainer = Atp.PageContainerView.extend ({
    prefixName: 'voip',

   	pageload: function(){
		Atp.VoIPProvidersController.load();
		Atp.VoipProviderSelectController.load();
	},

    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.VoipProviderCollapseView id="voip_providercollapse" }} \
            {{ view Atp.VoipNumbersCollapseView }} \
            {{/if}} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.VoipProviderContainer, "voip_provider");