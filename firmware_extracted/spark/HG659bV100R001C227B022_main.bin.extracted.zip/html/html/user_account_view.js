Atp.LoadHelper.appendLangRes('user_account_res.js', true);

Atp.LoadHelper.appendJs('/lib/base64.js', true);
Atp.LoadHelper.appendJs('/js/user_account.js', true);

Atp.LoadHelper.loadAll();

Atp.AccountContainerView = Atp.PageContainerView.extend ({
	prefixName: "useraccount",
	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
            {{view Atp.AccountCollapse}} \
        ')
	})
    
});

Atp.MenuController.createSubmenuView(Atp.AccountContainerView, "user_account");