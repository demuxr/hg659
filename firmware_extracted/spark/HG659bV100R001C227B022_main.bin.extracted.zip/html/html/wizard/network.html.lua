
--lua_content_for__ include begin
 web.print('\
');  html.link('/css/network.css')  web.print('\
');  html.lang('host_info_res.js')  web.print('\
');  html.lang('user_login_res.js')  web.print('\
');  html.lang('device_info_res.js')  web.print('\
');  html.lang('wizard_res.js')  web.print('\
');  html.lang('wan_res.js')  web.print('\
');  html.lang('qos_res.js')  web.print('\
');  html.script('/js/diagnose_internet.js')  web.print('\
');  html.script('/js/host_info.js')  web.print('\
');  html.script('/js/topu.js')  web.print('\
'); 
--lua_content_end__
 web.print('\
\
'); 
--lua_content_for__ script_tag begin
 web.print('\
<script language="JavaScript" type="text/javascript">\
function pageload(controller) {\
    if (controller) {\
        if (controller == Atp.DefaultWanController){\
            controller.load(function(){\
                resizeLines();\
            });\
            return false;\
        }\
        else if (controller == Atp.HostsController){\
            controller.load(function(){\
                Atp.ParentControlSelectController.load();\
            })\
        }\
        else if(controller == Atp.DeviceInfoController){\
            controller.load(function(){\
                Atp.HostInternetController.load();\
                Atp.LanHostController.load();\
            })\
        }\
        else{\
            controller.load();\
        }\
        return false;\
    }\
}\
function pageReLoad(){\
    if(hasActiveItem == 0)\
    {\
        pageload(Atp.HostsController);\
        pageload(Atp.HostsQosController);\
        pageload(Atp.WizardUsbController);\
        pageload(Atp.DefaultWanController);\
        pageload(Atp.WizardWifiController);\
        pageload(Atp.TopVoiceController);\
        pageload(Atp.DeviceInfoController);\
    }\
}\
function modal_hidden(obj_id){\
    $(\'#\'+ obj_id).on(\'hidden\', function () {\
        hasActiveItem = 0;\
    });\
}\
\
$(document).ready(function() {\
    modal_hidden("ethdeviceappend");\
    modal_hidden("wifideviceappend");\
    modal_hidden("gateway_info");\
    modal_hidden("usbdeviceappend");\
    modal_hidden("usb_storage");\
    modal_hidden("voicedeviceappend");\
    modal_hidden("voice_detail");\
    Em.View.create({\
        templateName: \'gateway_info\'\
    }).appendTo(\'#gateway_info\');\
    Em.View.create({\
        templateName: \'top_title\'\
    }).appendTo(\'#top_title\');\
    Em.View.create({\
        templateName: \'topu_wifi_title\'\
    }).appendTo(\'#topu_wifi_title\');\
    Em.View.create({\
        templateName: \'topu_internet_title\'\
    }).appendTo(\'#topu_internet_title\');\
    Em.View.create({\
        templateName: \'top_device_title\'\
    }).appendTo(\'#top_device_title\');\
\
    Em.View.create({\
        templateName: \'top_eth_title\'\
    }).appendTo(\'#top_eth_title\');\
    Em.View.create({\
        templateName: \'more_eth_title\'\
    }).appendTo(\'#more_eth_title\');\
    Em.View.create({\
        templateName: \'eth_fold_button\'\
    }).appendTo(\'#eth_fold_button\');\
    Em.View.create({\
        templateName: \'eth_all_device\'\
    }).appendTo(\'#eth_all_device\');\
    Em.View.create({\
        templateName: \'more_wifi_title\'\
    }).appendTo(\'#more_wifi_title\');\
    Em.View.create({\
        templateName: \'more_wifi_button\'\
    }).appendTo(\'#more_wifi_button\');\
    Em.View.create({\
        templateName: \'wifi_all_device\'\
    }).appendTo(\'#wifi_all_device\');\
    Em.View.create({\
        templateName: \'wifi_fold_button\'\
    }).appendTo(\'#wifi_fold_button\');\
    Em.View.create({\
        templateName: \'more_eth_button\'\
    }).appendTo(\'#more_eth_button\');\
    Em.View.create({\
        templateName: \'topu_wifi\'\
    }).appendTo(\'#topu_wifi\');\
    Em.View.create({\
        templateName: \'topu_eth\'\
    }).appendTo(\'#topu_eth\');    \
    Em.View.create({\
        templateName: \'popupContact\'\
    }).appendTo(\'#popupContact\');\
    Em.View.create({\
        templateName: \'topu_usb_title\'\
    }).appendTo(\'#topu_usb_title\');\
    Em.View.create({\
        templateName: \'topu_usb\'\
    }).appendTo(\'#topu_usb\');\
    Em.View.create({\
        templateName: \'usb_storage\'\
    }).appendTo(\'#usb_storage\');\
    Em.View.create({\
        templateName: \'more_usb_button\'\
    }).appendTo(\'#more_usb_button\');\
    Em.View.create({\
        templateName: \'more_usb_title\'\
    }).appendTo(\'#more_usb_title\');\
    Em.View.create({\
        templateName: \'usb_fold_button\'\
    }).appendTo(\'#usb_fold_button\');\
    Em.View.create({\
        templateName: \'usb_all_device\'\
    }).appendTo(\'#usb_all_device\');\
    Em.View.create({\
        templateName: \'topu_voice_title\'\
    }).appendTo(\'#topu_voice_title\');\
    Em.View.create({\
        templateName: \'topu_voice\'\
    }).appendTo(\'#topu_voice\');\
    Em.View.create({\
        templateName: \'voice_detail\'\
    }).appendTo(\'#voice_detail\');\
    Em.View.create({\
        templateName: \'more_voice_button\'\
    }).appendTo(\'#more_voice_button\');\
    Em.View.create({\
        templateName: \'more_voice_title\'\
    }).appendTo(\'#more_voice_title\');\
    Em.View.create({\
        templateName: \'voice_fold_button\'\
    }).appendTo(\'#voice_fold_button\');\
    Em.View.create({\
        templateName: \'voice_all_device\'\
    }).appendTo(\'#voice_all_device\');\
    pageReLoad();\
    setInterval("pageReLoad()",10000);\
});\
</script>\
'); 
--lua_content_end__
 web.print('\
</script>\
<div class="container">\
    <div class="rounddiv wizard_config_div top_network">\
        <div class="rounddiv background_color_white">\
            <div class="height_10">&nbsp;</div>\
            <div class="header rounddiv network_title marginleft_10 marginright_10">&nbsp;</div>\
            <div id="top_title" class="bodydiv top_network_title paddingleft_20 paddingtop_10 marginleft_10 marginright_10 topu_title">\
                <script type="text/x-handlebars" data-template-name="top_title">\
                {{t home.network.mynetwork}}\
                </script>\
            </div>\
        </div>\
        <br />\
        <br />\
        <!--first line-->\
        <div class="row-fluid show-network-grid show-network-grid1 rounddiv">\
            <div class="span1" id="adjust_1" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_2" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_3" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_4" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_5" style="background-color:transparent;">&nbsp;</div>\
            <div class="span4 rounddiv height_145" id="wifidiv">\
                <div class="form-inline rounddiv_top width_100p">\
                    <div class="header rounddiv_top top_background width_100p">\
                        <div id="topu_wifi_title" class="pull-left marginleft_10 topu_ip_mac_title width_100p">\
                            <script type="text/x-handlebars" data-template-name="topu_wifi_title">\
                            <div style="_margin-top:10px;">{{t home.network.wifidevice}}</div>\
                            </script>\
                            <div id="more_wifi_button_div" class="pull-right ie6topufoldbotttom hide">\
                                <button id="more_wifi_button" class="btn">\
                                    <script type="text/x-handlebars" data-template-name="more_wifi_button">\
                                        {{t home.network.more}}\
                                    </script>\
                                </button>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
                <div id="topu_wifi" class="rounddiv ie6topmargin_10 height_100">\
                    <script type="text/x-handlebars" data-template-name="topu_wifi">\
                        {{view Atp.WifiHostsView class="width_100p"}}\
                    </script>\
                </div>\
            </div>\
        </div>\
        <!--second line-->\
        <div class="row-fluid show-network-grid show-network-grid1 rounddiv pull-left">\
            <div class="span1" id="adjust_6" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2 rounddiv" id="internetdiv">\
                <div id="topu_internet_title" class="header rounddiv_top wizard_internet_top topu_ip_mac_title" align="center">\
                    <script type="text/x-handlebars" data-template-name="topu_internet_title">\
                        <div style="_margin-top:10px;">{{t home.network.internet}}</div>\
                    </script>\
                </div>\
                <div class="internet_back" id="internetpage" onclick="location.href=\'/html/advance.html#internet\'" align="center"></div>           \
            </div>\
            <div class="span1" id="linestatusdiv" style="background-color:transparent;_margin-top:30px;">\
            </div>\
            <div class="span2 rounddiv" id="huaweidiv">\
                <div id="top_device_title" class="header rounddiv_top top_background topu_ip_mac_title" align="center">\
                    <script type="text/x-handlebars" data-template-name="top_device_title">\
                        <div style="_margin-top:10px;">{{t home.network.atp}}</div>\
                    </script>\
                </div>\
                <div id="gatewayinfo" class="internet_back ic_gateway ie6image"></div>\
            </div>\
            <div class="span1" id="adjust_7" style="background-color:transparent;">&nbsp;</div>\
            <div class="span4 rounddiv height_145" id="ethdiv">\
                <div class="form-inline rounddiv width_100p">\
                    <div class="header rounddiv_top top_background width_100p">\
                        <div id="top_eth_title" class="pull-left marginleft_10 topu_ip_mac_title width_100p">\
                            <script type="text/x-handlebars" data-template-name="top_eth_title">\
                            <div style="_margin-top:10px;">{{t home.network.ethdevice}}</div>\
                            </script>\
                            <div id="more_eth_button_div" class="pull-right ie6topufoldbotttom hide">\
                                <button id="more_eth_button" class="btn">\
                                    <script type="text/x-handlebars" data-template-name="more_eth_button">\
                                        {{t home.network.more}}\
                                    </script>\
                                </button>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
                <div id="topu_eth" class="rounddiv height_100 ie6topmargin_10">\
                    <script type="text/x-handlebars" data-template-name="topu_eth">\
                        {{view Atp.HostsView}}\
                    </script>\
                </div>\
            </div>\
        </div>\
        <!--forth line voice-->\
        <div id="drawsign" class="clearboth margintop_8 row-fluid show-network-grid show-network-grid1 rounddiv">\
            <div class="span1" id="adjust_13" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_14" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_15" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_16" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_17" style="background-color:transparent;">&nbsp;</div>\
            <div class="span4 rounddiv height_145" id="voicediv">\
                <div class="header rounddiv_top top_background width_100p">\
                    <div id="topu_voice_title" class="pull-left marginleft_10 topu_ip_mac_title width_100p">\
                        <script type="text/x-handlebars" data-template-name="topu_voice_title">\
                            <div style="_margin-top:10px;">{{t home.network.voicedevice}}</div>\
                        </script>\
                        <div id="more_voice_button_div" class="pull-right ie6topufoldbotttom hide">\
                            <button id="more_voice_button" class="btn">\
                                <script type="text/x-handlebars" data-template-name="more_voice_button">\
                                    {{t home.network.more}}\
                                </script>\
                            </button>\
                        </div> \
                    </div>\
                </div>\
                <div id="topu_voice" class="rounddiv height_100 ie6topmargin_10">\
                    <script type="text/x-handlebars" data-template-name="topu_voice">\
                        {{view Atp.VoiceHostsView }}\
                    </script>\
                </div>\
            </div>\
        </div>\
        <!--third line usb-->\
        <div id="drawsign" class="clearboth margintop_8 row-fluid show-network-grid show-network-grid1 rounddiv">\
            <div class="span1" id="adjust_8" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_9" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_10" style="background-color:transparent;">&nbsp;</div>\
            <div class="span1" id="adjust_11" style="background-color:transparent;">&nbsp;</div>\
            <div class="span2" id="adjust_12" style="background-color:transparent;">&nbsp;</div>\
            <div class="span4 rounddiv height_145" id="usbdiv">\
                <div class="header rounddiv_top top_background width_100p">\
                    <div id="topu_usb_title" class="pull-left marginleft_10 topu_ip_mac_title width_100p">\
                        <script type="text/x-handlebars" data-template-name="topu_usb_title">\
                            <div style="_margin-top:10px;">{{t home.network.usbdevice}}</div>\
                        </script>\
                        <div id="more_usb_button_div" class="pull-right ie6topufoldbotttom hide">\
                            <a id="more_usb_button" data-toggle="modal" class="btn" href="#usbdeviceappend">\
                                <script type="text/x-handlebars" data-template-name="more_usb_button">\
                                    {{t home.network.more}}\
                                </script>\
                            </a>\
                        </div> \
                    </div>\
                </div>\
                <div id="topu_usb" class="rounddiv height_100 ie6topmargin_10">\
                    <script type="text/x-handlebars" data-template-name="topu_usb">\
                        {{view Atp.UsbView }}\
                    </script>\
                </div>\
            </div>\
        </div>\
\
        <br />\
    </div>\
    <div id="gate_wifi_div">&nbsp;</div>\
    <div id="gate_usb_div">&nbsp;</div>\
    <div id="gate_voice_div">&nbsp;</div>\
    <hr id="internet_gate_line" class="tophrborder" />\
    <hr id="gate_eth_line" class="tophrborder" />\
    <div id="footerdiv">&nbsp;</div>\
    <br>\
    <!--more eth div ethdeviceappend-->\
    <div id="ethdeviceappend" class="device_more hide">\
        <div class="header rounddiv_top top_background">\
            <div id="more_eth_title" class="pull-left marginleft_20 margintop_10 fontcolor_white">\
                <script type="text/x-handlebars" data-template-name="more_eth_title">\
                    {{t home.network.ethdevice}}\
                </script>\
            </div>\
            <div class="pull-right marginright_10 margintop_5">\
                <button id="eth_fold_button" class="btn">\
                    <script type="text/x-handlebars" data-template-name="eth_fold_button">\
                        {{t home.network.fold}}\
                    </script>\
                </button>\
            </div>\
        </div>\
        <div id="eth_all_device">\
            <script type="text/x-handlebars" data-template-name="eth_all_device">\
                {{view Atp.MoreEthHostsView}}\
            </script>\
        </div>\
    </div>\
    <!--more wifi device wifideviceappend-->\
    <div id="wifideviceappend" class="device_more hide">\
        <div class="header rounddiv_top top_background">\
            <div id="more_wifi_title" class="pull-left marginleft_20 margintop_10 fontcolor_white">\
                <script type="text/x-handlebars" data-template-name="more_wifi_title">\
                    {{t home.network.wifidevice}}\
                </script>\
            </div>\
            <div class="pull-right marginright_10 margintop_5">\
                <button id="wifi_fold_button" class="btn">\
                    <script type="text/x-handlebars" data-template-name="wifi_fold_button">\
                        {{t home.network.fold}}\
                    </script>\
                </button>\
            </div>\
        </div>\
        <div id="wifi_all_device">\
            <script type="text/x-handlebars" data-template-name="wifi_all_device">\
                {{view Atp.MoreWifiHostsView }}\
            </script>\
        </div>\
    </div>\
    <!--more usb device usbdeviceappend-->\
    <div id="usbdeviceappend" class="modal hide">\
        <div class="header rounddiv_top top_background">\
            <div id="more_usb_title" class="pull-left marginleft_20 margintop_10 fontcolor_white">\
                <script type="text/x-handlebars" data-template-name="more_usb_title">\
                    {{t home.network.usbdevice}}\
                </script>\
            </div>\
            <div class="pull-right marginright_10 margintop_5">\
                <button id="usb_fold_button" class="btn" data-dismiss="modal">\
                    <script type="text/x-handlebars" data-template-name="usb_fold_button">\
                        {{t home.network.fold}}\
                    </script>\
                </button>\
            </div>\
        </div>\
        <div id="usb_all_device">\
            <script type="text/x-handlebars" data-template-name="usb_all_device">\
                {{view Atp.MoreUsbView }}\
            </script>\
        </div>\
    </div>\
    <!--more voice device voicedeviceappend-->\
    <div id="voicedeviceappend" class="device_more hide">\
        <div class="header rounddiv_top top_background">\
            <div id="more_voice_title" class="pull-left marginleft_20 margintop_10 fontcolor_white">\
                <script type="text/x-handlebars" data-template-name="more_voice_title">\
                    {{t home.network.voicedevice}}\
                </script>\
            </div>\
            <div class="pull-right marginright_10 margintop_5">\
                <button id="voice_fold_button" class="btn" data-dismiss="modal">\
                    <script type="text/x-handlebars" data-template-name="voice_fold_button">\
                        {{t home.network.fold}}\
                    </script>\
                </button>\
            </div>\
        </div>\
        <div id="voice_all_device">\
            <script type="text/x-handlebars" data-template-name="voice_all_device">\
                {{view Atp.MoreVoiceHostsView }}\
            </script>\
        </div>\
    </div>\
    <!--detail div contain wifi eth-->\
    <div id="popupContact" class="rounddiv hide">\
        <script type="text/x-handlebars" data-template-name="popupContact">\
            <div class="header height_20 width_100p modaltitlebackcolor" align="right">\
                <button id="popupContactClose" type="button" class="close_detail">X</button>\
            </div>\
            <div class="width_100p">\
                <div style="background-color:#f5f5f5;">\
                    {{view Atp.HostDetailHeadView contentBinding="Atp.HostsController.activeItem" }}\
                </div>\
                <br>\
                <div class="scroll_y">\
                {{view Atp.HostDetailBodyView contentBinding="Atp.HostsController.activeItem" }}\
                </div><br>\
                <div class="clearboth pop-footer">\
                    {{view Atp.HostDetailBtns }}\
                </div>\
            </div>\
        </script>\
    </div>\
    <!--usb-->\
    <div id="usb_storage" class="modal hide">\
        <script type="text/x-handlebars" data-template-name="usb_storage">\
            <div class="header height_20 modaltitlebackcolor" align="right">\
                <button id="usb_window" type="button" class="close_detail marginright_5" data-dismiss="modal">X</button>\
            </div>\
            <div class="modal-header marginleft_10 lineheight_30">\
                <h4><div class="pull-left dev-usb"></div><span class="paddingleft_15">{{t home.network.usbdevice}}</span></h4>\
                <div class="third_menu_below_config_font">{{t network.usb.info}}</div>\
            </div>\
            <div class="modal-body">\
               {{view Atp.UsbDetailView }}\
            </div>\
        </script>\
    </div>\
    <!--voice-->\
    <div id="voice_detail" class="rounddiv hide">\
        <script type="text/x-handlebars" data-template-name="voice_detail">\
            <div class="header height_20 modaltitlebackcolor" align="right">\
                <button id="voice_window_x" type="button" class="close_detail">X</button>\
            </div>\
            {{view Atp.VoiceDetailView contentBinding="Atp.TopVoiceController.activeItem" }}\
        </script>\
    </div>\
</div>\
<!--gateway info-->\
<div id="gateway_info" class="rounddiv hide">\
    <script type="text/x-handlebars" data-template-name="gateway_info">\
        <div class="header height_20 modaltitlebackcolor" align="right">\
            <button id="device_window_x" type="button" class="close_detail marginright_5">X</button>\
        </div>\
        <div class="pull-left width_100p">{{view Atp.DeviceInfoView}}</div>\
    </script>\
</div>\
<script type="text/x-handlebars">\
'); 