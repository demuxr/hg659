Atp.LoadHelper.appendJs("/lib/base64.js", true);
Atp.LoadHelper.appendJs("/js/jquery.ztree.core-3.1.js", true);
Atp.LoadHelper.appendLangRes("file_services_res.js", true);
Atp.LoadHelper.appendJs("/js/usbtree.js", true);
Atp.LoadHelper.appendJs("/js/file_services.js", true);

Atp.LoadHelper.loadAll();

Atp.FileServiceContainerView = Atp.PageContainerView.extend ({
    prefixName: "fs",
    dataView: Em.View.extend({    
        closeModel:function(){
            $("#backgroundPopup").hide();
        },
        template: Em.Handlebars.compile('\
            {{ view Atp.StatusCollapse }}\
            {{ view Atp.StorageCollapse }}\
            {{ view Atp.AnonymCollapse }}\
            <div id="fs_usb_diag" class="modal hide" style="z-index:3000">\
                <div class="header height_25 modaltitlebackcolor">\
                    {{view Atp.WindowHeadView parentID="fs_usb_diag"}} \
                    <a class="pull-right fontweight_thick marginright_10 accordion-toggle close_detail" aria-hidden="true" data-dismiss="modal" {{action "closeModel" target="view"}}>X</a>\
                </div>\
                <div class="modal-header">\
                    <div class="pull-left dev-usb ie6image"></div><span class="paddingleft_15 paddingtop_5 fontweight_thick">{{t fs.modalhead }}</span>\
                    <div class="third_menu_below_config_font">{{t fs.modalhead.info}}</div>\
                </div>\
                <div class="modal-body">\
                    <div class="zTreeDemoBackground left"><ul id="fstree" class="ztree"></ul></div>\
                </div>\
                <div class="modal-footer">\
                    <button class="atp_button width_120" id="file_services_shareId" {{action "refresh" target="Atp.UsbTreeController"}}>{{t fs.modalbrowse }}</button>\
                    <button class="atp_button width_120" id="file_services_cancelId" data-dismiss="modal" {{action "closeModel" target="view"}}>{{t Menu.Cancel }}</button>\
                </div>\
            </div>\
        ')
    })
    
});

Atp.MenuController.createSubmenuView(Atp.FileServiceContainerView, "file_services");
