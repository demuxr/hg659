local web = require('web')

web.logout()


