local utils = require('utils')

local domain = "InternetGatewayDevice.X_SyslogConfig."
local maps = {
    LogEnable="Enable",
    LogServerStatus = "LogServerEnable",
    LogLevel = "Level",
    PrimaryServerAddress = "MainServer",
    PrimaryServerPort = "MainServerPort",
    SecondServerAddress = "MinorServer",
    SecondServerPort = "MinorServerPort"
}


local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)