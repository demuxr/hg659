require('dm')
require('utils')
local tonumber = tonumber

local maps = {
	DiagnosticsState="DiagnosticsState",
	Host = "Host",
	ResponseTime = "ResponseTime",
	RouteHopsNumberOfEntries = "RouteHopsNumberOfEntries",
	
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.TraceRouteDiagnostics.", maps)


local obj = values["InternetGatewayDevice.TraceRouteDiagnostics."]

local hopmaps = {
	HopHost="HopHost",
	HopHostAddress="HopHostAddress",
	HopErrorCode="HopErrorCode",
	HopRTTimes="HopRTTimes"	
}
local errcode, values = dm.GetParameterValues("InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.{i}.", hopmaps)
obj.RouteHops = {}

if values ~= nil then
	for k, v in pairs(values) do
		local newObj = {}
		inst = utils.findLastPoint(k)
		newObj["ID"] = inst
		for kr, vd in pairs(hopmaps) do
			newObj[kr] = v[vd]
		end 
		obj.RouteHops[tonumber(inst)] = newObj
	end
end

local maps = {
	DiagnosticsState="DiagnosticsState",
	Host = "Host",
	ResponseTime = "ResponseTime",
	RouteHopsNumberOfEntries = "RouteHopsNumberOfEntries",
	RouteHops = "RouteHops"
}
utils.responseSingleObject(obj, maps)