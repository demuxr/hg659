local dm = require('dm')
local web = require('web')
local json = require('json')
local utils = require('utils')

local tostring, GetParameterValues, toboolean = tostring, dm.GetParameterValues, utils.toboolean
local find, open, exec, encode, webprint = string.find, io.open, web.exec, json.encode, web.print

local activedevicenumbers = 0
local lanactivenumber = 0

local printernumbers = 0
local usbnumbers = 0
local datacardnumber = 0
local phonenumber = 0
local activephonenumber = 0
--datacard
exec("atcmd ati display >/var/datacard")
local fh = nil
local line = ''
fh = open("/var/datacard", "r")
if fh then
    line = fh:read("*a")
    fh:close()
end
exec("rm /var/datacard")
ip = find(line, "Model:")
if ip ~= nil then
    datacardnumber = 1
end

--wifi--
--eth--

local errcode, lanVals = GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias"})

local lanarray = {}

for k, v in pairs(lanVals) do
    lanarray[v["InterfaceReference"]] = v["X_InterfaceAlias"]
end

local errcode,device_count= GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.",{"Layer2Interface","Active", "X_IPv6Active",});

for k,v in pairs(device_count) do
    if utils.toboolean(v["Active"])  or utils.toboolean(v["X_IPv6Active"])  then
           activedevicenumbers = activedevicenumbers + 1
    end

    if nil ~= lanarray[v["Layer2Interface"]]  then
        local start = string.find(lanarray[v["Layer2Interface"]], "LAN")
        if nil ~= start then
            if utils.toboolean(v["Active"])  or utils.toboolean(v["X_IPv6Active"])  then
                lanactivenumber = lanactivenumber + 1
            end
        end
    end
end

--printer--
local errcode,printer_count= GetParameterValues("InternetGatewayDevice.Services.X_Printer.",{"Name"});
--usb storage--
local errcode,usb_count= GetParameterValues("InternetGatewayDevice.Services.StorageService.{i}.PhysicalMedium.{i}.",{"Name","Capacity"});

if printer_count ~= nil then
	local obj = printer_count["InternetGatewayDevice.Services.X_Printer."]
	if obj["Name"] ~= 'Unknown' then
		printernumbers = printernumbers + 1  
	end
end

for k,v in pairs(usb_count) do
    usbnumbers = usbnumbers + 1
end
--get usernumber, if just one account, we should show change password window in index page--
local userNumber = 0
local errcode,userinfo = dm.GetParameterValues("InternetGatewayDevice.UserInterface.X_Web.UserInfo.{i}.",{"Username"});
if userinfo ~= nil then
    for k,v in pairs(userinfo) do
        userNumber = userNumber+1;
    end
end

local errcode_line,line_values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.Line.{i}.", {"DirectoryNumber", "CallState"});
function IsNumberBusy(attachlist, linevalues)
    if nil ~= linevalues then
        if "all" == attachlist then
            for k,v in pairs(linevalues) do
                if v["CallState"] == "Busy" then
                    return "Busy"
                end
            end
        else
            local splitlist = utils.split(attachlist, ",")
            for k1, v1 in pairs(splitlist) do
                for k2,v2 in pairs(linevalues) do
                    if v1 == v2["DirectoryNumber"] then
                        if v2["CallState"] == "Busy" or v2["CallState"] == "Calling" or v2["CallState"] == "Ringing" then
                            return "Busy"
                        end
                   end
                end
            end
        end
    end
    return "Idle"
end
local phy_errcode,phy_values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.PhyInterface.{i}.", {"X_AttachedLineList"});
for k,v in pairs(phy_values) do
    phonenumber = phonenumber+1
    if "Busy" == IsNumberBusy(v['X_AttachedLineList'], line_values) then
        activephonenumber = activephonenumber + 1
    end
end
local Device = {}

activedevicenumbers = activedevicenumbers  + printernumbers + usbnumbers  + datacardnumber + activephonenumber

Device.ActiveDeviceNumbers = activedevicenumbers
Device.PrinterNumbers = printernumbers
Device.UsbNumbers = usbnumbers
Device.DatacardNumber = datacardnumber 
Device.LanActiveNumber = lanactivenumber
Device.UserNumber = userNumber 
Device.PhoneNumber = phonenumber
webprint(encode(Device))