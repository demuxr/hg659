require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_SyslogConfig.", { "DisplayType", "DisplayLevel" });
local obj = values["InternetGatewayDevice.X_SyslogConfig."]
local loginfo = {}
loginfo.DisplayType = obj["DisplayType"]
loginfo.DisplayLevel = obj["DisplayLevel"]

local ret = web.getlogcontent(obj["DisplayLevel"], obj["DisplayType"], 1024)

f = io.open("/var/logtemp", "r")
if f == nil then
    loginfo.LogContent = ""
    io.close()
else
    file = f:read("*a")
    loginfo.LogContent = string.gsub(file, "\r\n", "\n")
    f:close()
    os.remove("/var/logtemp")
end

cmd_line = "cat /config/coredump/vmlinux.core >/var/con_number"
os.execute(cmd_line)
fh = io.open("/var/con_number", "r")
if fh == nil then
  	loginfo.PanicLog = ""
else
	loginfo.PanicLog = ""
	loginfo.CrashTime = ""
	file = fh:read("*a")
	if file == '' then
		loginfo.PanicLog = ""
		loginfo.CrashTime = ""
	else
		file = string.gsub(file, "\r\n", "\n")
		file = string.gsub(file, "<", '&lt')
		loginfo.PanicLog = string.gsub(file, ">", '&gt')
		local start = string.find(loginfo.PanicLog, ":")
		local endflag = string.find(loginfo.PanicLog, "|")
		loginfo.CrashTime = string.sub(loginfo.PanicLog, start+1, endflag-1)
		loginfo.PanicLog = string.gsub(loginfo.PanicLog, "|", '\n')
		fh:close()
	--	sys.exec("rm /var/con_number")
    end
end
web.print(json.encode(loginfo))