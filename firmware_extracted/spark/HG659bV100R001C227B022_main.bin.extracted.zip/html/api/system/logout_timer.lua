local utils = require('utils')

local maps = {
    idletime = "Timeout"
}

function add_one_parameter(paras, name, value)
    table.insert(paras, {name, value})
end

local paras = {}
add_one_parameter(paras, "InternetGatewayDevice.UserInterface.X_Web.Timeout", data["idletime"])

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
utils.responseErrorcode(errcode, paramerr, maps)