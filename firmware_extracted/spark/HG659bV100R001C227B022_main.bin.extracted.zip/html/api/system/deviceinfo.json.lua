local dm  = require('dm')
local web = require('web')
local json = require('json')
local utils = require('utils')
local tostring = tostring
local GetParameterValues = dm.GetParameterValues

local errcode,host = GetParameterValues("InternetGatewayDevice.DeviceInfo.",
    {
        "ProductClass",
        "SerialNumber",
        "HardwareVersion",
        "SoftwareVersion",
        "ManufacturerOUI",
        "UpTime"
    }
);

local obj = host["InternetGatewayDevice.DeviceInfo."]

local Device = {}

Device.DeviceName = obj["ProductClass"]
Device.SerialNumber = obj["SerialNumber"]
Device.HardwareVersion = obj["HardwareVersion"]
Device.SoftwareVersion = obj["SoftwareVersion"]
Device.ManufacturerOUI = obj["ManufacturerOUI"]
Device.UpTime = obj["UpTime"]

web.print(json.encode(Device))