local dm = require('dm')
local web = require('web')
local json = require('json')
local utils = require('utils')

local tostring = tostring
local GetParameterValues, toboolean, insert = dm.GetParameterValues, utils.toboolean, table.insert

local wlanobj = {}

local numbers = 0
local obj = web.gmsgget('wlancms', 2, {})
numbers = obj.number

local errcode,wifiConf = GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",{"Enable","OperatingFrequencyBand"})
function get_WifiEnable(frequency)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return toboolean(v["Enable"])
        end
    end
    return false
end

local errcode,WlanSSID = GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.",{"SSID","X_OperatingFrequencyBand"})

function calc_min(frequency)
    local array = {}
    local i = 1
    if WlanSSID ~= nil then
        for k,v in pairs(WlanSSID) do
            if frequency == v["X_OperatingFrequencyBand"] then
                local wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end
        end
        table.sort(array)
        if 1 == i  then
            return -1
        else
            return array[1]
        end
    end
    return -1
end

wlan_index = calc_min("2.4GHz")
wlan_5gindex = calc_min("5GHz")

for k,v in pairs(WlanSSID) do
    local wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
    local wlanInstance = {}
    if wlan_index == tonumber(wlan_instance_id) then
        wlanInstance.WifiFrequency = 2
        wlanInstance.WifiEnable = get_WifiEnable(v["X_OperatingFrequencyBand"])
        wlanInstance.WifiSsid = v["SSID"]
        wlanInstance.Numbers = numbers
        insert(wlanobj, wlanInstance)
    end
        if wlan_5gindex == tonumber(wlan_instance_id) then
            wlanInstance.WifiFrequency = 5
            wlanInstance.WifiEnable = get_WifiEnable(v["X_OperatingFrequencyBand"])
            wlanInstance.WifiSsid = v["SSID"]
            wlanInstance.Numbers = numbers
            insert(wlanobj, wlanInstance)
        end
end

web.print(json.encode(wlanobj))
