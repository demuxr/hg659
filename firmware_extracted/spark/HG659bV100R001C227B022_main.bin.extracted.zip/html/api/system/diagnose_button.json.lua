require('dm')
require('utils')
require('web')
require('json')

local maps = {
	DiagnoseAction="DiagnosticsState",
	Result = "Results"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_ButtonDiagnostics.", maps)

local obj = values["InternetGatewayDevice.X_ButtonDiagnostics."]

local buttons = {}

local allButton = {
			"RESET",
		"WLAN",
		"WPS",
}

local result = utils.split(obj["Results"], ",")
for k, v in pairs(result) do
	local button = {}
	button.ID = k
	
	local s = utils.split(v, "=")
	button.Key = s[1]
	button.State = s[2]
	buttons[k] = button
end

obj.Buttons = buttons
maps = {
	DiagnoseAction="DiagnosticsState",
	Buttons = "Buttons"
}
utils.responseSingleObject(obj, maps)