local utils = require('utils')
local domain = "InternetGatewayDevice.Time."
local maps = {
    Enable="Enable",
    NTPServer1 = "NTPServer1",
    NTPServer2 = "NTPServer2",
    TimeZoneIdx = "X_Label",
    LocalTimeZoneName = "LocalTimeZoneName"
}

if data["NTPServer1"] == "None" then
    data["NTPServer1"] = ""
end

if data["NTPServer2"] == "None" then
    data["NTPServer2"] = ""
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)