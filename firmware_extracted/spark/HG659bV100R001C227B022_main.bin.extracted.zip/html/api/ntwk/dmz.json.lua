require('dm')
require('web')
require('json')
require('utils')

local maps = {
	HostIPAddress="DMZHostMACAddress",
	Enable = "DMZEnable"
}

local domain = "InternetGatewayDevice.Services.X_DMZ."

local errcode, values = dm.GetParameterValues(domain, maps)

local obj
if values ~= nil then
	obj = values[domain]
	obj.DMZEnable = utils.toboolean(obj.DMZEnable)
end

utils.responseSingleObject(obj, maps)

