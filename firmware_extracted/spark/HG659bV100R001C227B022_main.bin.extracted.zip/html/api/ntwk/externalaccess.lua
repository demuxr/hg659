local utils = require('utils')

local domain = "InternetGatewayDevice.Services.X_ExternalAccess."

local maps = {
	Enable		= "Enable",
	TimeOut		= "TimeOut"	
}

if true == data["Enable"] then
	data["TimeOut"] = 1500
else
	data["TimeOut"] = 0
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
