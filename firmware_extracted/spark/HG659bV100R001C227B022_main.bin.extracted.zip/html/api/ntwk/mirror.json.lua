require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_Mirror.",
    {"Enable", "LanInterface", "TypeInterface"});

local obj = values["InternetGatewayDevice.Services.X_Mirror."]

local mirrorCfg = {}

mirrorCfg.Enable = utils.toboolean(obj["Enable"])
mirrorCfg.CapturePort = obj["LanInterface"]
mirrorCfg.DestPort = obj["TypeInterface"]

web.print(json.encode(mirrorCfg))
