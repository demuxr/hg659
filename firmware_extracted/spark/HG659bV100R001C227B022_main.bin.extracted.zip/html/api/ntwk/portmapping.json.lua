require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber

local portmapping = {}


local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.Services.X_Portmapping.{i}.", 
    {"Name", "Enable", "InternalHost", "ApplicationID"});


for k,v in pairs(objs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["Name"] = v["Name"]
    newObj["Enable"] = utils.toboolean(v["Enable"])
    newObj["InternalHost"] = v["InternalHost"]
    newObj["ApplicationID"] = v["ApplicationID"]
    table.insert(portmapping, newObj)
end

utils.multiObjSortByID(portmapping)

web.print(json.encode(portmapping))
