local utils = require('utils')

--local data = utils.getRequestFormData()

local maps = {
    ServerEnable ="DHCPServerEnable",
    MinIP = "MinAddress",
    MaxIP = "MaxAddress",
    DNSServerone = "DNSServers",
    DHCPLeaseTime = "DHCPLeaseTime",
    UseAllocatedWAN = "UseAllocatedWAN",
    PassthroughLease = "PassthroughLease",
    AssociatedConnection = "AssociatedConnection",
    PassthroughMACAddress = "PassthroughMACAddress",
    dnsmode = "X_DNSMode"
}

function add_one_lan_parameter(paras, name, value)
    table.insert(paras, {name, value})
end

function build_lan_parameters()
    local paras = {}
    Dnsstr = ""
    add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPServerEnable", data["ServerEnable"])
    if true == data["ServerEnable"] then
        add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.MinAddress", data["MinIP"])
        add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.MaxAddress", data["MaxIP"])
        if "false" == data["dnsmode"] then
            if "" ~= data["DNSServerone"] then
                Dnsstr = data["DNSServerone"]
                if "" ~= data["DNSServertwo"] then
                    Dnsstr = Dnsstr..","..data["DNSServertwo"]
                end
            else
                if "" ~= data["DNSServertwo"] then
                    Dnsstr = ","
                end    
            end   
            add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DNSServers", Dnsstr)
        end
        add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPLeaseTime", data["DHCPLeaseTime"])
        add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.UseAllocatedWAN", data["UseAllocatedWAN"])
        if "Passthrough" == data["UseAllocatedWAN"] then
            add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.PassthroughLease", data["PassthroughLease"]) 
            add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.AssociatedConnection", data["AssociatedConnection"]) 
            add_one_lan_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.PassthroughMACAddress", data["PassthroughMACAddress"]) 
        end
    end
    return paras    
 end
local bridge = {}

if "true" == data["dnsmode"] then
    add_one_lan_parameter(bridge, "InternetGatewayDevice.Layer2Bridging.Bridge.1.X_DNSMode", 0)
else   
    add_one_lan_parameter(bridge, "InternetGatewayDevice.Layer2Bridging.Bridge.1.X_DNSMode", 2)
end

errcode1, NeedReboot1, paramerr1 = dm.SetParameterValues(bridge)


local paras = build_lan_parameters()

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
