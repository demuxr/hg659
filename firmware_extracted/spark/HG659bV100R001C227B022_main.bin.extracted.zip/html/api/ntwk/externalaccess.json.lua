require('dm')
require('utils')

local domain = "InternetGatewayDevice.Services.X_ExternalAccess."

local maps = {
	Enable		= "Enable",
	TimeOut		= "TimeOut",
	TimeLeft	= "TimeLeft"	
}

local errcode,values = dm.GetParameterValues(domain, maps)

local obj
if values ~= nil then
	obj 		  	= values[domain]
	obj["Enable"] 	= utils.toboolean(obj["Enable"])	
end
utils.responseSingleObject(obj, maps)