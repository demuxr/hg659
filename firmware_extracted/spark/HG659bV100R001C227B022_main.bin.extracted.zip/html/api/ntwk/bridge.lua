require('dm')
require('utils')

local maps = {
	BridgeName = "BridgeName"
}

local errcode, interfaces = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias", "InterfaceType", "AvailableInterfaceKey"})


local errcode, filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.",
		{"FilterBridgeReference", "FilterInterface"})


local intfs = {}
for k, v in pairs(interfaces) do
	local interface = {}
	interface.InterfaceID = v["InterfaceReference"]
	interface.InterfaceName = v["X_InterfaceAlias"]
	interface.InterfaceType = v["InterfaceType"]
	interface.AvailableID = k

	for k1, v1 in pairs(filters) do
		if tostring(v["AvailableInterfaceKey"]) == v1["FilterInterface"] then
			interface.ID = k1
			interface.BridgeKey = v1["FilterBridgeReference"]
			break;
		end
	end
	table.insert(intfs, interface)
end

function bind_intf2br(intf, brkey, binddata)
	print("bind_intf2br", intf, brkey)
	for k, v in pairs(intfs) do 
		print("interface ", v["InterfaceID"], v["ID"])
		if v["InterfaceID"] == intf then
			table.insert(binddata, {v["ID"].."FilterBridgeReference", brkey})			
			break
		end
	end
end

function bind_bridge(domain, binddata, brkey)
	if brkey == nil then
		local errcode, bridges = dm.GetParameterValues(domain, {"BridgeKey"})
		brkey = bridges[domain]["BridgeKey"]
	end

	for k, v in pairs(data["LANInterface"]) do
		bind_intf2br(v["InterfaceID"], brkey, binddata)
	end

	for k, v in pairs(data["WANInterface"]) do
		bind_intf2br(v["InterfaceID"], brkey, binddata)
	end
end

function delete_bind_bridge(domain, binddata)
	local errcode, bridges = dm.GetParameterValues(domain, {"BridgeKey"})
	brkey = bridges[domain]["BridgeKey"]

	for k, v in pairs(intfs) do 
		print("delete_bind_bridge", v["BridgeKey"], brkey, v["InterfaceType"])
		if v["BridgeKey"] == brkey then
			if v["InterfaceType"] == "LANInterface" then
				dm.DeleteObject(v["ID"])
				local errcode = dm.DeleteObject(v["AvailableID"])
				print("delete bridge ", v["ID"], v["AvailableID"], errcode)
			else
				table.insert(binddata, {v["ID"].."FilterBridgeReference", -1})
			end
		end
	end
end

function create_bridge()
	local paras = {{"BridgeName", data["BridgeName"]}}
	local errcode, instId, NeedReboot, errparams = dm.AddObjectWithValues("InternetGatewayDevice.Layer2Bridging.Bridge.", paras);
	utils.responseErrorcode(errcode, errparams, maps)

	if 0 ~= errcode then
		return errcode
	end

	local binddata = {}
	local domain = "InternetGatewayDevice.Layer2Bridging.Bridge."..instId.."."
	bind_bridge(domain, binddata, nil)

	dm.SetParameterValues(binddata)

	return 0
end

function is_not_in_bridge(intfID)
	for k, v in pairs(data["LANInterface"]) do
		if v["InterfaceID"] == intfID then
			return false
		end
	end

	for k, v in pairs(data["WANInterface"]) do
		if v["InterfaceID"] == intfID then
			return false
		end
	end

	return true
end

function update_bridge()
	local paras = {{data["ID"].."BridgeName", data["BridgeName"]}}
	local errcode, NeedReboot, errparams = dm.SetParameterValues(paras);
	utils.responseErrorcode(errcode, errparams, maps)
	if 0 ~= errcode then
		return errcode
	end

	local errcode, bridges = dm.GetParameterValues(data["ID"], {"BridgeKey"})
	local brkey = bridges[data["ID"]]["BridgeKey"]

	print("update bridge", brkey)

	local binddata = {}
	if data["Type"] ~= 1 and data["Type"] ~= 2 then
		for k, v in pairs(data["LANInterface"]) do
			bind_intf2br(v["InterfaceID"], brkey, binddata)
		end
	end

	for k, v in pairs(data["WANInterface"]) do
		bind_intf2br(v["InterfaceID"], brkey, binddata)
	end

	for k, v in pairs(intfs) do 
		if v["BridgeKey"] == brkey then
			if is_not_in_bridge(v["InterfaceID"]) then
				bind_intf2br(v["InterfaceID"], -1, binddata)
			end			
		end
	end

	for k, v in pairs(binddata) do
		print("binddata ", v[1], v[2])
	end

	dm.SetParameterValues(binddata)

	return 0
end

function delete_bridge()
	local binddata = {}
	delete_bind_bridge(data["ID"], binddata)

	local errcode = dm.DeleteObject(data["ID"])
	return errcode
end

if action == 'create' then
	err = create_bridge()
elseif action == 'update' then
	err = update_bridge()
elseif action == 'delete' then
	err = delete_bridge()
else
	return
end
utils.appenderror("errcode", err)