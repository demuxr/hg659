require('dm')
require('utils')
local tostring = tostring

local map_6rd = {
	LowerLayer="AssociatedWanIfName",
    Enable = "Activated",
    AutoMode = "Dynamic",
    PeerAddr = "BorderRelayAddress",
    IPv4MaskLen = "IPv4MaskLen",
    PrefixLen = "6rdPrefixLength",
    Prefix = "Prefix",
    TunnelType = "Mechanism"
}

local map_6to4 = {
	LowerLayer="AssociatedWanIfName",
    Enable = "Activated",
    PeerAddr = "BorderRelayAddress",
    DnsServers = "IPv6DnsServers",
    TunnelType = "Mechanism"
}

local map_gre = {
	LowerLayer="AssociatedWanIfName",
    Enable = "Activated",
    PeerAddr = "TunnelEndpoint",
    IPv4Enable = "IPv4Enable",
    IPv6Enable = "IPv6Enable"	
}

local map_dslite = {
	LowerLayer="AssociatedWanIfName",
    Enable = "Activated",
    AutoMode = "Dynamic",
    PeerAddr = "RemoteIpv6Address",
    TunnelType = "Mechanism"
}

function get_tunnel_domain_map()
	if "6rd" == data["TunnelType"] then
		return "InternetGatewayDevice.X_IPTunnel.V6in4Tunnel.", map_6rd
	elseif "6to4" == data["TunnelType"] then
		return "InternetGatewayDevice.X_IPTunnel.V6in4Tunnel.", map_6to4
	elseif "GRE" == data["TunnelType"] then
		return "InternetGatewayDevice.X_IPTunnel.GRE.", map_gre
	elseif "DSLite" == data["TunnelType"] then
		return "InternetGatewayDevice.X_IPTunnel.V4in6Tunnel.", map_dslite
	else
		return nil, nil
	end
end

local tunnel_domain, tunnel_map = get_tunnel_domain_map()
if tunnel_domain == nil then
	-- tunnel type error.
	utils.appenderror("errcode", 9003)
	return
end

function add_new_tunnel()
	local paras = utils.GenAddObjParamInputs(data, tunnel_map)
	local errcode, instnum, NeedReboot, paramerr = dm.AddObjectWithValues(tunnel_domain, paras);
	if 0 ~= errcode then
		utils.appenderror("errcode", 9003)
		utils.appenderror("tunnel.Enable", "tunnel.singlestack_err")
	else
		utils.appenderror("errcode", 0)
	end
	return errcode
end

function update_tunnel(domain)
	local paras = utils.GenSetObjParamInputs(domain, data, tunnel_map)
	local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	if 0 ~= errcode then
		utils.appenderror("errcode", 9003)
		utils.appenderror("tunnel.Enable", "tunnel.singlestack_err")
	else
		utils.appenderror("errcode", 0)
	end
	return errcode
end

local res = {}
res.ID = ""

local errcode,v4in6Tunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.V4in6Tunnel.{i}.",
            {"AssociatedWanIfName", "Mechanism"})
if v4in6Tunnels then
    for k,v in pairs(v4in6Tunnels) do
        res.LowerLayer = v["AssociatedWanIfName"]
        res.TunnelType = v["Mechanism"]
        res.ID = k
    end
end

if "" == res.ID then
	local errcode,v6in4Tunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.V6in4Tunnel.{i}.",
            {"AssociatedWanIfName", "Mechanism"})
	if v6in4Tunnels then
		for k,v in pairs(v6in4Tunnels) do
		    res.LowerLayer = v["AssociatedWanIfName"]
		    res.TunnelType = v["Mechanism"]
		    res.ID = k
		end
	end
end

if "" == res.ID then
	local errcode,GRETunnels = dm.GetParameterValues("InternetGatewayDevice.X_IPTunnel.GRE.{i}.",
	            {"AssociatedWanIfName"})
	if GRETunnels then
		for k,v in pairs(GRETunnels) do
		    res.LowerLayer = v["AssociatedWanIfName"]
		    res.TunnelType = "GRE"
		    res.ID = k
		end
	end
end

if res.ID == "" then
	if not utils.toboolean(data["Enable"]) then
		-- Previously Tunnel disabled, nothing to do
		utils.appenderror("errcode", 0)
		return
	end

	-- Enable, we should add new Tunnel object
	add_new_tunnel()
	return
elseif not utils.toboolean(data["Enable"]) then
	local errcode = dm.DeleteObject(res.ID)
	utils.appenderror("errcode", errcode)
	utils.appenderror("ID", res.ID)
	return
elseif data["TunnelType"] ~= res.TunnelType then
	dm.DeleteObject(res.ID)
	add_new_tunnel()
	return
else
    update_tunnel(res.ID)
    return
end
