local utils = require('utils')

local paras = {}
table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.IGMPSnoopingEnable", data["IGMPSnoopingEnable"]})
table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.IGMPProxyEnable", data["IGMPProxyEnable"]})
if utils.toboolean(data["IGMPProxyEnable"]) then
	table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV.WanList", data["IGMPWan"]})
end

table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV6.MLDSnoopingEnable", data["MLDSnoopingEnable"]})
table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV6.MLDProxyEnable", data["MLDProxyEnable"]})
if utils.toboolean(data["MLDProxyEnable"]) then
	table.insert(paras, {"InternetGatewayDevice.Services.X_IPTV6.Wan6List", data["MLDWan"]})
end

local errcode,needreboot, paramerror = dm.SetParameterValues(paras)

utils.appenderror("errcode", errcode)
