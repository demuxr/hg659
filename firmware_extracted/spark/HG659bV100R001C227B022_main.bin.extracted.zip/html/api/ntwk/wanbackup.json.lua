require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode,backupParams = dm.GetParameterValues("InternetGatewayDevice.Services.X_WANBackup.", 
    {"Mode", "TimeForChange"});

params = backupParams["InternetGatewayDevice.Services.X_WANBackup."]

res = {}
res.Mode = params["Mode"]
res.Idletime = params["TimeForChange"]

web.print(json.encode(res))
