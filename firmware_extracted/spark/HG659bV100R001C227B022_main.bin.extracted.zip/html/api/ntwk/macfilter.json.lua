require('dm')
require('web')
require('json')
require('utils')

function parsemacs(srcmac)
	local start = 1
	local devices = {}
	while true do
		ip, fp = string.find(srcmac, "|", start)
		if not ip then
			local mac = {}
			mac["MACAddress"] = string.sub(srcmac, start)
			table.insert(devices, mac)
			break
		end
		local mac = {}
		mac["MACAddress"] = string.sub(srcmac, start, ip-1)
		table.insert(devices, mac)
		start = fp +1
	end

	return devices
end

local weekday = {
	[0]="Daily", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
}

function setweektime(newObj, key, times)
	local start = 1
	local devices = {}
	local index = 1
	while true do
		ip, fp = string.find(times, "|", start)
		if not ip then
			newObj[weekday[index]..key] = string.sub(times, start)
			break
		end
		local mac = {}
		newObj[weekday[index]..key] = string.sub(times, start, ip-1)
		index = index + 1
		start = fp +1
	end
end


function parsetime(newObj, dmObj)
	if dmObj["TimeMode"] == 0 then
		for k, v in pairs(weekday) do
			newObj[v.."From"] = dmObj["WeekTimeStart"]
			newObj[v.."To"] = dmObj["WeekTimeEnd"]
		end
	else
		local from = dmObj["WeekTimeStart"]
		local to = dmObj["WeekTimeEnd"]
		setweektime(newObj, "From", from)
		setweektime(newObj, "To", to)

		newObj["DailyFrom"] = newObj["MondayFrom"]
	    newObj["DailyTo"] = newObj["MondayTo"]
	end
end


local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.TimeRule.{i}.", 
    {"Name", "Enable", "TimeMode", "WeekTimeStart", "WeekTimeEnd", "DevMac"});

local macfilter = {}

if objs ~= nil then
	for k,v in pairs(objs) do
	    local newObj = {}
	    newObj["ID"] = k
	    newObj["RuleName"] = v["Name"]
	    newObj["Enable"] = utils.toboolean(v["Enable"])
	    newObj["TimeMode"] = v["TimeMode"]
	    if v["DevMac"] == '' then
	    	newObj["Devices"] = {}
	    else
	    	newObj["Devices"] = parsemacs(v["DevMac"])
	    end
	    parsetime(newObj, v)
		table.insert(macfilter, newObj)
	end
end
utils.multiObjSortByID(macfilter)
web.print(json.encode(macfilter))
