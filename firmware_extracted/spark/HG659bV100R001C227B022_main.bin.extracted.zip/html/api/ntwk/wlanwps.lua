local utils = require('utils')

local tostring = tostring

local maps = {
	WpsEnable = "Enable",
	WpsMode = "X_WPSMode",
	WifiWpsPinCode = "X_PinPhrase",
	WifiWpsApPinCode = "DevicePassword"
}

function add_one_wlan_parameter(paras, name, value)
	if nil == value then
		return 
	end	
	table.insert(paras, {name, value})
end

local paras = {}

function submit_frequency_data(paras, data)
	if nil == data then
		return
	end
	if nil == data["ID"] then
		return 
	end	
	local wps_str = data["ID"]
	add_one_wlan_parameter(paras, wps_str.."Enable", data["WpsEnable"])
	if true == data["WpsEnable"] then
		add_one_wlan_parameter(paras, wps_str.."X_WPSMode", data["WpsMode"])
		if data["WpsMode"] == "pbc" then
			add_one_wlan_parameter(paras, wps_str.."X_PinPhrase", "")
			add_one_wlan_parameter(paras, wps_str.."DevicePassword", "")
		end
		if data["WpsMode"] == "client-pin" then
			add_one_wlan_parameter(paras, wps_str.."X_PinPhrase", data["WifiWpsPinCode"])
			add_one_wlan_parameter(paras, wps_str.."DevicePassword", "")
		end
		if data["WpsMode"] == "ap-pin" then
			add_one_wlan_parameter(paras, wps_str.."X_PinPhrase", "")
			add_one_wlan_parameter(paras, wps_str.."DevicePassword", data["WifiWpsApPinCode"])
		end
	end	
end

submit_frequency_data(paras, data["config2g"])
submit_frequency_data(paras, data["config5g"])
local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
