require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local tonumber = tonumber
local find_index = false

local errcode,wlaninfo = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.",
    {
        "Enable",
        "X_OperatingFrequencyBand",
        "TotalBytesSent",
        "TotalPacketsSent",
        "TotalBytesReceived",
        "TotalPacketsReceived",
        "SSID"
    }
)

local wlan = {}
for k,v in pairs(wlaninfo) do
    local wlanitem = {}
    find_index = true;
    local wifi_enable = v["Enable"]

    if 1 == wifi_enable then
        local stats_domain = k.."Stats."
        local err, statsInfo = dm.GetParameterValues(stats_domain,
            {
                "ErrorsSent",
                "DiscardPacketsSent",
                "ErrorsReceived",
                "DiscardPacketsReceived"
            }
        )
        local obj = statsInfo[stats_domain]
        wlanitem["senderror"] = obj["ErrorsSent"]
        wlanitem["senddiscard"] = obj["DiscardPacketsSent"]
        wlanitem["receiveerror"] = obj["ErrorsReceived"]
        wlanitem["receivediscard"] = obj["DiscardPacketsReceived"]
        
        wlanitem["wifimode"] = v["X_OperatingFrequencyBand"]
        wlanitem["name"] = v["SSID"]
        wlanitem["sendbytes"] = v["TotalBytesSent"]
        wlanitem["sendpacket"] = v["TotalPacketsSent"]
        wlanitem["receivebytes"] = v["TotalBytesReceived"]
        wlanitem["receivepacket"] = v["TotalPacketsReceived"]
        table.insert(wlan, wlanitem)
    end
end 

web.print(json.encode(wlan))