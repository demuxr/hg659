require('dm')
require('web')
require('json')

local voipProvider = {}
local err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.", {"Name"});
if values ~= nil then
    for k,v in pairs(values) do
    	local provideritem = {}
		provideritem.ID = k
		provideritem.Name = v["Name"]
		table.insert(voipProvider,provideritem)
    end
    utils.multiObjSortByID(voipProvider)
end
web.print(json.encode(voipProvider))