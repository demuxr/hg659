require('web')
require('dm')
local utils = require('utils')

local voip_line_maps = {
    Number="DirectoryNumber",
    Enable="Enable"
}

local voip_line_sip_maps = {
    Username="AuthUserName"
}

if data["Password"] ~= "KioqKioqKio=" then
	voip_line_sip_maps["Password"] = "AuthPassword"
end

--update
function update_voip_line(line_domain, line_data)
	print("update_voip_line")
	if line_data["Enable"] ~= nil and line_data["Enable"] == true then
		line_data["Enable"] = "Enabled"
	else
		line_data["Enable"] = "Disabled"
	end
	print("Enable "..line_data["Enable"])
	local update_line = {}
	utils.GenSetObjParamInputsEx(line_domain, line_data, voip_line_maps,update_line)
	print("utils")
	local err,needreboot, paramerror = dm.SetParameterValues(update_line)
	print("err "..err)
	if err == 0 then
		local linesip_domain = line_domain.."SIP."
		local update_linesip = {}
		utils.GenSetObjParamInputsEx(linesip_domain, line_data, voip_line_sip_maps,update_linesip)
		err,needreboot, paramerror = dm.SetParameterValues(update_linesip);
		utils.responseErrorcode(err, paramerr, voip_line_sip_maps)
	else
		utils.responseErrorcode(err, paramerr, voip_line_maps)
		utils.appenderror("Number", "voip.provider.SipNum.Number.Invalid")
	end
end

--create
function add_voip_line(profile_domain, line_data)
	
	if line_data["Enable"] ~= nil and line_data["Enable"] == true then
        line_data["Enable"] = "Enabled"
	else
        line_data["Enable"] = "Disabled"
	end

	local adding_paras = utils.GenAddObjParamInputs(line_data, voip_line_maps)
	local err,instId,needreboot,errs = dm.AddObjectWithValues(profile_domain.."Line.", adding_paras)

	if err ~= 0 then
         utils.responseErrorcode(err, errs, voip_line_maps)
         for k,v in pairs(errs) do
             if v == "voip.provider.SipNum.Number.Limit" then
             return
             end
        end
	utils.appenderror("Number", "voip.provider.SipNum.Number.Invalid")
        return
	end
	print("err "..err)
	if err == 0 then
        local linesip_domain = profile_domain.."Line."..instId..".SIP."
        local update_linesip = {}
        utils.GenSetObjParamInputsEx(linesip_domain, line_data, voip_line_sip_maps,update_linesip)
        err,needreboot, paramerror = dm.SetParameterValues(update_linesip);
        utils.responseErrorcode(err, paramerror, voip_line_sip_maps)
        return
	end
end
if data["Number"] == "" then
	utils.appenderror("Number", "voip.provider.SipNum.Number.Emptyerr")
	utils.appenderror("errcode", 9003)
	return
end

function delete_voip_line()
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 300)
    end
end

print("action "..action)
if action == "create" then
	print("create ProviderID",data["ProfileID"])
    add_voip_line(data["ProfileID"], data)
elseif action == "update" then
	print("ID "..data["ID"])
	update_voip_line(data["ID"], data)
elseif action == "delete" then
    delete_voip_line()
else
    utils.appenderror("errcode", 400)
end