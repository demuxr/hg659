require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsEnable"})
if values ~= nil then
    local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
    umtsEnable = utils.toboolean(obj["X_UmtsEnable"])
end

local FullList = {}
local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.Line.{i}.", {
        "Enable",
        "DirectoryNumber",
        "X_LineSeq"
    }
);
if values ~= nil then
    for k,v in pairs(values) do
        local each_line = {}
        each_line.ID = k
        each_line.Value = v["DirectoryNumber"]
        each_line.LineSeq = v["X_LineSeq"]
        if v["Enable"] ~= "Disabled" then
            table.insert(FullList, each_line)
        end
    end
    table.sort(FullList, function (a, b) return a.LineSeq < b.LineSeq end)
end

if umtsEnable ~= nil and umtsEnable == true then
    local umts_obj = {}
    umts_obj.ID = "cs"
    umts_obj.Value = "CS"
    table.insert(FullList, umts_obj)
end

web.print(json.encode(FullList))