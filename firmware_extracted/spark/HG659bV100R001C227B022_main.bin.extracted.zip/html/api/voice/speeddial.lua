require('web')
require('dm')
local utils = require('utils')

local voip_speeddial_maps = {
	SpeedNumber="QuickDialNumber",
	ActualNumber="Destination",
	SpeedDescription="Description"
}

function create_speeddialinfo()
        --for id,speeddialdata in pairs(data["Emergency"]) do
		data["SpeedNumber"] = "**"..data["SpeedNumber"]
                if data["ID"] == "" then
			local adding_speeddial_paras = utils.GenAddObjParamInputs(data, voip_speeddial_maps)
			local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.Button.", adding_speeddial_paras)
			print("err "..err)
			--print("errs "..errs)
			if err ~= 0 then
				utils.responseErrorcode(err, errs, voip_speeddial_maps)
			else
				utils.appenderror("errcode", 0)
			end
		end
	--end
end

function update_speeddialinfo()
	--for k,speeddialdata in pairs(data["SipNums"]) do
		data["SpeedNumber"] = "**"..data["SpeedNumber"]
		if data["ID"] == "" then
                        local adding_speeddial_paras = utils.GenAddObjParamInputs(data, voip_speeddial_maps)
			local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.Button.", adding_speeddial_paras)
			if err ~= 0 then
				utils.responseErrorcode(err, errs, voip_speeddial_maps)
			end
		else
			local setting_paras = {}
			utils.GenSetObjParamInputsEx(data["ID"], data, voip_speeddial_maps, setting_paras)
			local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)
			 utils.responseErrorcode(err, paramerror, voip_speeddial_maps)
		end
	--end
end

function delete_speeddialinfo()
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 300)
    end
end

if data["ActualNumber"] ~= nil and data["ActualNumber"] == "CS" then
	err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsNumber"})
	if values ~= nil then
		local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
		data["ActualNumber"] = obj["X_UmtsNumber"]
	end
end

if action == "create" then
        create_speeddialinfo()
elseif action == "update" then
    update_speeddialinfo()
elseif action == "delete" then
    delete_speeddialinfo()
else
    utils.appenderror("errcode", 400)
end