require('web')
require('dm')
local utils = require('utils')

function setOutgoingline()
	if data["OutgoingLine"] ~= "" then
		if data["OutgoingLine"] == "CS" then
			err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsNumber"})
			if values ~= nil then
				local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
				data["OutgoingLine"] = obj["X_UmtsNumber"]
				err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.X_EmergencyRoute", "2")
			end
		else
			err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.X_EmergencyRoute", "1")
		end
		err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.X_EmergencyRouteAccount", data["OutgoingLine"])
	end
        utils.appenderror("errcode", 0)
end

setOutgoingline()