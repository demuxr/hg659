require('dm')
require('utils')

local maps = {
	Enable="Enable",
	UpBandWidth = "X_BandWidth",
	DownBandWidth = "DownBandWidth",
	WmmEnable = "X_WmmEnable"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.", 
    maps);

local obj = values["InternetGatewayDevice.QueueManagement."]
obj.Enable = utils.toboolean(obj.Enable)
obj.X_WmmEnable = utils.toboolean(obj.X_WmmEnable)

utils.responseSingleObject(obj, maps)
