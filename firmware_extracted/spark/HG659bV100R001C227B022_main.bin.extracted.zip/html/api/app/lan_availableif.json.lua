require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", {"InterfaceReference", "X_InterfaceAlias"})
for k, v in pairs(lanVals) do
    local lanarray = {}
    lanarray[v["X_InterfaceAlias"]] = v["InterfaceReference"]
end

local lanifs = {}

function add_lanif_lanname(lanname)
    for k,v in pairs(lanVals) do
        if v["X_InterfaceAlias"] == lanname then
           local lanif = {}
           lanif.ID = v["InterfaceReference"]
           lanif.lanif = lanname
           table.insert(lanifs, lanif)
           return
        end
    end
end

function add_ssid_by_dm(domain_prefix)
    local domain = domain_prefix.."."
    local errcode, values = dm.GetParameterValues(domain, { "SSID" });
    if values ~= nil then
        local obj
        local ssid = {}
        obj = values[domain]
        ssid.ID = domain_prefix
        ssid.lanif = obj["SSID"]
        table.insert(lanifs, ssid)
    end
end

-- LAN1
add_lanif_lanname("LAN1")

-- LAN2
add_lanif_lanname("LAN2")

-- LAN3
add_lanif_lanname("LAN3")

-- LAN4
add_lanif_lanname("LAN4")

-- 2.4GHz wifi
add_ssid_by_dm("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1")
-- 5GHz wifi
add_ssid_by_dm("InternetGatewayDevice.LANDevice.1.WLANConfiguration.2")

-- 2.4GHz guest network
add_ssid_by_dm("InternetGatewayDevice.LANDevice.2.WLANConfiguration.1")

-- 5GHz guest network
add_ssid_by_dm("InternetGatewayDevice.LANDevice.2.WLANConfiguration.2")

web.print(json.encode(lanifs))
