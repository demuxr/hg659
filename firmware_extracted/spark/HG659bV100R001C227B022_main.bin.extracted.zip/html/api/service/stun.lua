local utils = require('utils')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="STUNEnable",
    url = "STUNServerAddress",
    name = "STUNUsername",
    conname = "X_StunConnectionRequestUsername",
    port = "STUNServerPort",
    min = "STUNMinimumKeepAlivePeriod",
    max = "STUNMaximumKeepAlivePeriod",
}
if data["pwd"] ~= _G["defaultPasswd"] then
	maps["pwd"] = "STUNPassword"
end

if data["conpwd"] ~= _G["defaultPasswd"] then
	maps["conpwd"] = "X_StunConnectionRequestPassword"
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
