Atp.LanInfoController = Atp.MultiObjController.create ({
    objName: 'ntwk/lan_info'
});

Atp.LanInfoItemsView = Em.CollectionView.extend ({
    tagName: "tbody",
    itemViewClass: Em.View.extend ({
        tagName: "tr",
        itemelementId:function(){
            if(this.content.ID){
                return this.content.ID;
            }else{
                return this.get("parentView").get("elementId");
            }
        }.property(),
        receivebytesID:function(){
            return this.get("itemelementId") +"_receivebytes";
        }.property(),
        receivepacketsID:function(){
            return this.get("itemelementId") +"_receivepacket";
        }.property(),
        receiveerrorID:function(){
            return this.get("itemelementId") +"receiveerror";
        }.property(),
        receivediscardID:function(){
            return this.get("itemelementId") +"_receivediscard";
        }.property(),
        sendbytesID:function(){
            return this.get("itemelementId") +"_sendbytes";
        }.property(),
        sendpacketID:function(){
            return this.get("itemelementId") +"_sendpacket";
        }.property(),
        senderrorID:function(){
            return this.get("itemelementId") +"_senderror";
        }.property(),
        senddiscardID:function(){
            return this.get("itemelementId") +"_senddiscard";
        }.property(),
        template: Em.Handlebars.compile(' \
            <td {{bindAttr id="view.itemelementId"}}>{{view.content.ID}}</td> \
            <td {{bindAttr id="view.receivebytesID"}}>{{view.content.receivebytes}}</td> \
            <td {{bindAttr id="view.receivepacketsID"}}>{{view.content.receivepacket}}</td> \
            <td {{bindAttr id="view.receiveerrorID"}}>{{view.content.receiveerror}}</td> \
            <td {{bindAttr id="view.receivediscardID"}}>{{view.content.receivediscard}}</td> \
            <td {{bindAttr id="view.sendbytesID"}}>{{view.content.sendbytes}}</td> \
            <td {{bindAttr id="view.sendpacketID"}}>{{view.content.sendpacket}}</td> \
            <td {{bindAttr id="view.senderrorID"}}>{{view.content.senderror}}</td> \
            <td {{bindAttr id="view.senddiscardID"}}>{{view.content.senddiscard}}</td> \
        ')
    })
});

Atp.LanInfoEditView = Em.View.extend ({
    template: Em.Handlebars.compile('<div class="form-horizontal scroll_x paddingleft_15"> \
        <table class="table table-striped table-bordered table-condensed">\
            <thead>\
                <tr>\
                    <th><label id="laninfo_interface">{{t homentwk_info.interface}}</label></th>\
                    <th colspan="4"><label id="laninfo_receive">{{t homentwk_info.receive}}</label></th>\
                    <th colspan="4"><label id="laninfo_send">{{t homentwk_info.send}}</label></th>\
                </tr>\
                <tr>\
                    <th>&nbsp;</th>\
                    <th><label id="laninfo_receivebyte">{{t homentwk_info.byte}}</label></th>\
                    <th><label id="laninfo_receivepacket">{{t homentwk_info.packet}}</label></th>\
                    <th><label id="laninfo_receiveerror">{{t homentwk_info.error}}</label></th>\
                    <th><label id="laninfo_receivediscard">{{t homentwk_info.discard}}</label></th>\
                    <th><label id="laninfo_sendbyte">{{t homentwk_info.byte}}</label></th>\
                    <th><label id="laninfo_sendpacket">{{t homentwk_info.packet}}</label></th>\
                    <th><label id="laninfo_senderror">{{t homentwk_info.error}}</label></th>\
                    <th><label id="laninfo_senddiscard">{{t homentwk_info.discard}}</label></th>\
                </tr>\
            </thead>\
            {{view Atp.LanInfoItemsView contentBinding="Atp.LanInfoController.content" }} \
        </table>\
    </div>')
});

Atp.LanInfoView = Atp.SingleObjView.extend ({
    bClosed: false,
    readOnly: true,
    hasHelpView: false,
    prefixName: "homentwk_info.laninfo",
    controller: Atp.LanInfoController,
    EditView: Atp.LanInfoEditView
});

Atp.WifiInfoModel = Em.Object.extend({
    interface: function(){
        return this.get("wifimode") + " : " + this.get("name");
    }.property("wifimode", "name")
});

Atp.WifiInfoController = Atp.MultiObjController.create ({
    objName: 'ntwk/wifi_info',
    modelClass: Atp.WifiInfoModel
});

Atp.WifiInfoItemsView = Em.CollectionView.extend ({
    tagName: "tbody",
    itemViewClass: Em.View.extend ({
        tagName: "tr",
        elementId:function(){
            return this.content.get("wifimode").replace(/\./g,"_") + "_ctrl";
        }.property(),
        interfaceID:function(){
            return this.get("elementId") + "_interface";
        }.property(),
        receivebytesID:function(){
            return this.get("elementId") + "_receivebytes";
        }.property(),
        receivepacketID:function(){
            return this.get("elementId") + "_receivepacket";
        }.property(),
        receiveerrorID:function(){
            return this.get("elementId") + "_receiveerror";
        }.property(),
        receivediscardID:function(){
            return this.get("elementId") + "_receivediscard";
        }.property(),
        sendbytesID:function(){
            return this.get("elementId") + "_sendbytes";
        }.property(),
        sendpacketID:function(){
            return this.get("elementId") + "_sendpacket";
        }.property(),
        senderrorID:function(){
            return this.get("elementId") + "_senderror";
        }.property(),
        senddiscardID:function(){
            return this.get("elementId") + "_senddiscard";
        }.property(),
        template: Em.Handlebars.compile(' \
            <td {{bindAttr id="view.interfaceID"}}>{{view.content.interface}}</td>\
            <td {{bindAttr id="view.receivebytesID"}}>{{view.content.receivebytes}}</td>\
            <td {{bindAttr id="view.receivepacketID"}}>{{view.content.receivepacket}}</td>\
            <td {{bindAttr id="view.receiveerrorID"}}>{{view.content.receiveerror}}</td>\
            <td {{bindAttr id="view.receivediscardID"}}>{{view.content.receivediscard}}</td>\
            <td {{bindAttr id="view.sendbytesID"}}>{{view.content.sendbytes}}</td>\
            <td {{bindAttr id="view.sendpacketID"}}>{{view.content.sendpacket}}</td>\
            <td {{bindAttr id="view.senderrorID"}}>{{view.content.senderror}}</td>\
            <td {{bindAttr id="view.senddiscardID"}}>{{view.content.senddiscard}}</td>\
        ')
    })
});

Atp.WifiInfoView = Em.View.extend ({
    template: Em.Handlebars.compile('<div class="form-horizontal scroll_x paddingleft_15"> \
        <table class="table table-striped table-bordered table-condensed">\
            <thead>\
                <tr>\
                    <th><label id="wifiinfo_interface">{{t homentwk_info.interface}}</label></th>\
                    <th colspan="4"><label id="wifiinfo_receive">{{t homentwk_info.receive}}</label></th>\
                    <th colspan="4"><label id="wifiinfo_send">{{t homentwk_info.send}}</label></th>\
                </tr>\
                <tr>\
                    <th>&nbsp;</th>\
                    <th><label id="wifiinfo_receivebyte">{{t homentwk_info.byte}}</label></th>\
                    <th><label id="wifiinfo_receivepacket">{{t homentwk_info.packet}}</label></th>\
                    <th><label id="wifiinfo_receiveerror">{{t homentwk_info.error}}</label></th>\
                    <th><label id="wifiinfo_receivediscard">{{t homentwk_info.discard}}</label></th>\
                    <th><label id="wifiinfo_sendbyte">{{t homentwk_info.byte}}</label></th>\
                    <th><label id="wifiinfo_sendpacket">{{t homentwk_info.packet}}</label></th>\
                    <th><label id="wifiinfo_senderror">{{t homentwk_info.error}}</label></th>\
                    <th><label id="wifiinfo_senddiscard">{{t homentwk_info.discard}}</label></th>\
                </tr>\
            </thead>\
             {{view Atp.WifiInfoItemsView contentBinding="Atp.WifiInfoController.content" }} \
        </table>\
    </div>')
});

Atp.WifiInfoStatusView = Atp.SingleObjView.extend ({
    prefixName: "homentwk_info.wifiinfo",
    readOnly: true,
    hasHelpView: false,
    controller: Atp.WifiInfoController,
    EditView: Atp.WifiInfoView
});


Atp.UmtsInfoController = Atp.SingleObjController.create ({
    objName: 'ntwk/umts_info_st'
});

Atp.UmtsInfoSTView = Atp.SingleObjView.extend ({
    prefixName: "homentwk_info.umts_info",
    readOnly: true,
    hasHelpView: false,
    controller: Atp.UmtsInfoController,
    EditView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{#if content.HasDatacard}}\
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.downstreamRate" valueBinding="content.DownstreamRate" }} \
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.upstreamRate" valueBinding="content.UpstreamRate" }} \
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.bytesSent" valueBinding="content.BytesSent" }} \
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.bytesReceived" valueBinding="content.BytesReceived" }} \
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.PacketsSent" valueBinding="content.PacketsSent" }} \
                {{ view Atp.LabelView textType="label" labelID="homentwk_info.umts_info.PacketsReceived" valueBinding="content.PacketsReceived" }} \
            {{else}} \
                {{t homentwk_info.umts_info.nodatacard}} \
            {{/if}} \
        ')
    })
});

Atp.WanInfoController = Atp.MultiObjController.create ({
    objName: 'ntwk/wan_st'
});

Atp.WanInfoItemsView = Em.CollectionView.extend ({
    tagName: "tbody",
    content: null,

    itemViewClass: Em.View.extend ({
        tagName: "tr",
        elementId:function(){
            return this.content.get("ID").replace(/\./g,"_") + "ctrl";
        }.property(),
        interfaceID:function(){
            return this.get("elementId") + "_name";
        }.property(),
        receivebytesID:function(){
            return this.get("elementId") + "_receivebytes";
        }.property(),
        receivepacketID:function(){
            return this.get("elementId") + "_receivepacket";
        }.property(),
        receiveerrorID:function(){
            return this.get("elementId") + "_receiveerror";
        }.property(),
        receivediscardID:function(){
            return this.get("elementId") + "_receivediscard";
        }.property(),
        sendbytesID:function(){
            return this.get("elementId") + "_sendbytes";
        }.property(),
        sendpacketID:function(){
            return this.get("elementId") + "_sendpacket";
        }.property(),
        senderrorID:function(){
            return this.get("elementId") + "_senderror";
        }.property(),
        senddiscardID:function(){
            return this.get("elementId") + "_senddiscard";
        }.property(),

        template: Em.Handlebars.compile(' \
            <td {{bindAttr id="view.interfaceID"}} class="wordbreak">{{view.content.Name}}</td> \
            <td {{bindAttr id="view.receivebytesID"}}>{{view.content.receivebytes}}</td> \
            <td {{bindAttr id="view.receivepacketID"}}>{{view.content.receivepacket}}</td> \
            <td {{bindAttr id="view.receiveerrorID"}}>{{view.content.receiveerror}}</td> \
            <td {{bindAttr id="view.receivediscardID"}}>{{view.content.receivediscard}}</td> \
            <td {{bindAttr id="view.sendbytesID"}}>{{view.content.sendbytes}}</td> \
            <td {{bindAttr id="view.sendpacketID"}}>{{view.content.sendpacket}}</td> \
            <td {{bindAttr id="view.senderrorID"}}>{{view.content.senderror}}</td> \
            <td {{bindAttr id="view.senddiscardID"}}>{{view.content.senddiscard}}</td>')
    })
});

Atp.WanInfoView = Atp.SingleObjView.extend({
    readOnly: true,
    hasHelpView: false,
    controller: Atp.WanInfoController,
    prefixName: "homentwk_info.waninfo",
    EditView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            <div class="form-horizontal scroll_x paddingleft_15"> \
                <table class="table table-striped table-bordered table-condensed"> \
                    <thead> \
                        <tr> \
                            <th><label id="waninfo_interface">{{t homentwk_info.interface}}</label></th>\
                            <th colspan="4"><label id="waninfo_receive">{{t homentwk_info.receive}}</label></th> \
                            <th colspan="4"><label id="waninfo_send">{{t homentwk_info.send}}</label></th> \
                        </tr> \
                        <tr> \
                            <th>&nbsp;</th> \
                            <th><label id="waninfo_receivebyte">{{t homentwk_info.byte}}</label></th> \
                            <th><label id="waninfo_receivepacket">{{t homentwk_info.packet}}</label></th> \
                            <th><label id="waninfo_receiveerror">{{t homentwk_info.error}}</label></th> \
                            <th><label id="waninfo_receivediscard">{{t homentwk_info.discard}}</label></th> \
                            <th><label id="waninfo_sendbyte">{{t homentwk_info.byte}}</label></th> \
                            <th><label id="waninfo_sendpacket">{{t homentwk_info.packet}}</label></th> \
                            <th><label id="waninfo_senderror">{{t homentwk_info.error}}</label></th> \
                            <th><label id="waninfo_senddiscard">{{t homentwk_info.discard}}</label></th> \
                        </tr> \
                    </thead> \
                    {{view Atp.WanInfoItemsView contentBinding="Atp.WanInfoController.content" }} \
                </table> \
            </div> \
        ')
    })
});

Atp.IptvInfoController = Atp.SingleObjController.create ({
    objName: 'ntwk/iptv_st'
});

Atp.IptvInfoItemsView = Em.View.extend ({
    tagName: "tbody",
    receivebytesID:function(){
        return this.get("elementId") + "_receivebytes";
    }.property(),
    receivepacketID:function(){
        return this.get("elementId") + "_receivepacket";
    }.property(),
    receiveerrorID:function(){
        return this.get("elementId") + "_receiveerror";
    }.property(),
    receivediscardID:function(){
        return this.get("elementId") + "_receivediscard";
    }.property(),
    sendbytesID:function(){
        return this.get("elementId") + "_sendbytes";
    }.property(),
    sendpacketID:function(){
        return this.get("elementId") + "_sendpacket";
    }.property(),
    senderrorID:function(){
        return this.get("elementId") + "_senderror";
    }.property(),
    senddiscardID:function(){
        return this.get("elementId") + "_senddiscard";
    }.property(),
    template: Em.Handlebars.compile('<tr>\
            <td {{bindAttr id="view.receivebytesID"}}>{{view.content.receivebytes}}</td> \
            <td {{bindAttr id="view.receivepacketID"}}>{{view.content.receivepacket}}</td> \
            <td {{bindAttr id="view.receiveerrorID"}}>{{view.content.receiveerror}}</td> \
            <td {{bindAttr id="view.receivediscardID"}}>{{view.content.receivediscard}}</td> \
            <td {{bindAttr id="view.sendbytesID"}}>{{view.content.sendbytes}}</td> \
            <td {{bindAttr id="view.sendpacketID"}}>{{view.content.sendpacket}}</td> \
            <td {{bindAttr id="view.senderrorID"}}>{{view.content.senderror}}</td> \
            <td {{bindAttr id="view.senddiscardID"}}>{{view.content.senddiscard}}</td></tr>')
});

Atp.IptvInfoView = Atp.SingleObjView.extend ({
    prefixName: "homentwk_info.iptvinfo",
    readOnly: true,
    hasHelpView: false,    
    controller: Atp.IptvInfoController,
    EditView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{#if content.Enable}}\
            <table class="table table-striped table-bordered table-condensed">\
                <thead>\
                    <tr>\
                        <th colspan="4"><label id="iptvinfo_receive">{{t homentwk_info.receive}}</label></th>\
                        <th colspan="4"><label id="iptvinfo_send">{{t homentwk_info.send}}</label></th>\
                    </tr>\
                    <tr>\
                        <th><label id="iptvinfo_receivebyte">{{t homentwk_info.byte}}</label></th>\
                        <th><label id="iptvinfo_receivepacket">{{t homentwk_info.packet}}</label></th>\
                        <th><label id="iptvinfo_receiveerror">{{t homentwk_info.error}}</label></th>\
                        <th><label id="iptvinfo_receivediscard">{{t homentwk_info.discard}}</label></th>\
                        <th><label id="iptvinfo_sendbyte">{{t homentwk_info.byte}}</label></th>\
                        <th><label id="iptvinfo_sendpacket">{{t homentwk_info.packet}}</label></th>\
                        <th><label id="iptvinfo_senderror">{{t homentwk_info.error}}</label></th>\
                        <th><label id="iptvinfo_senddiscard">{{t homentwk_info.discard}}</label></th>\
                    </tr>\
                </thead>\
                {{view Atp.IptvInfoItemsView contentBinding="Atp.IptvInfoController.content" }} \
            </table>\
            {{else}}\
                {{t homentwk_info.iptvinfo.iptvdisabled}} \
            {{/if}}\
        ')
    })
});
