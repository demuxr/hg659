require('web')
require('dm')
local utils = require('utils')

local ID = data["ID"]
local username = data["Username"]
local pwd = data["Password"]
local isallpath = data["AllPath"]
local iswrite = data["ReadOnly"]
local utf8dir = data["Path"]
local nativedir = data["Base64Path"]

local enable
if data["Enable"] then
    enable = 1
else
    enable = 0
end

if utf8dir == "" then
    utf8dir = "/mnt"
end
if nativedir == "" then
    nativedir = "/mnt"
end

function get_oldfolder(domain)
    local start = string.find(domain, "UserAccess")
    local folder_domain = string.sub(domain, 1, start - 1)
    if folder_domain == nil then
        return "",""
    end

    local errcode, values = dm.GetParameterValues(folder_domain, { "Name" });
    local obj = values[folder_domain]

    return folder_domain, obj["Name"]
end

-- add usb user account
if ID == '' then
    err,errstr = web.addusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, "0")
    if err ~= 0 then
       utils.appenderror("fs.storage.pwd", errstr)
    end
    utils.appenderror("errcode", err)
    return
end

if action == 'delete' then
    err = dm.DeleteObject(ID)
    utils.appenderror("errcode", err)
    return
end

if action ~= 'update' then
    utils.appenderror("errcode", 12)
    return
end

if string.len(utf8dir) > 64 then
    utils.appenderror("Menu.tr140path", "Menu.tr140path_err")
    utils.appenderror("errcode", 140)
    return
end

-- set user account
local errcode, account_values = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.LogicalVolume.{i}.Folder.{i}.UserAccess.{i}.",
    {"UserReference"}
)

for k,v in pairs(account_values) do
    if ID == (v["UserReference"]..".") then
        local d,useraccid = utils.findLastPoint(v["UserReference"])
        local folderdomain, foldername = get_oldfolder(k)
        err, errstr = web.setusbuser(enable, username, pwd, isallpath, iswrite, utf8dir, nativedir, useraccid, folderdomain, foldername)
        if err ~= 0 then
           utils.appenderror("fs.storage.pwd", errstr)
        end
        utils.appenderror("errcode", err)
        return
    end
end

local accountstr = data["ID"]
err,needreboot, paramerror = dm.SetParameterValues ({
    {accountstr.."Enable", enable},
    {accountstr.."Username", username},
    {accountstr.."Password", pwd},
    {accountstr.."X_AllPath", isallpath},
    {accountstr.."X_Permissions", iswrite}
});

if paramerror ~= nil then
    for k,v in pairs(paramerror) do
        if k == ID..".Enable" then
            utils.appenderror("Enable", v)
        elseif k == ID..".Username" then
            utils.appenderror("Username", v)
        elseif k == ID..".Password" then
            utils.appenderror("Password", v)
        elseif k == ID..".X_AllPath" then
            utils.appenderror("AllPath", v)
        elseif k == ID..".X_Permissions" then
            utils.appenderror("ReadOnly", v)
        end
    end
end
utils.appenderror("errcode", err)
