require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,data = dm.GetParameterValues("InternetGatewayDevice.Services.X_DmsService.",
    {
        "Enable",
        "ShareAllPath"
    }
);

local errcode, dirs = dm.GetParameterValues("InternetGatewayDevice.Services.X_DmsService.Directory.{i}.",
    {
        "Active",
        "ContentDirectory",
        "ContentDirectoryUTF"
    }
);

local dmsdirs = {}
for kk, vv in pairs(dirs) do
    local dir = {}
    dir.active = utils.toboolean(vv["Active"])
    dir.dir = vv["ContentDirectory"]
    dir.dirutf = vv["ContentDirectoryUTF"]
    table.insert(dmsdirs, dir)
end

local dms = {}

autodetect, diropt = web.getautodetectutf8()

local obj = data["InternetGatewayDevice.Services.X_DmsService."]

dms.enable = utils.toboolean(obj["Enable"])
dms.diropt = obj["ShareAllPath"]
dms.autodetect = utils.toboolean(autodetect)
dms.dirs = dmsdirs

web.print(json.encode(dms))
