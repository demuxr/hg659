local utils = require('utils')

utils.sendDmsContent()