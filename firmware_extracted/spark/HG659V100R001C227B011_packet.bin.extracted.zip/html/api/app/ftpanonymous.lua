require('web')
local utils = require('utils')

if data["AllPath"] == nil or data["Enable"] == nil or data["ReadOnly"] == nil or data["Path"] == nil or data["Base64Path"] == nil then
    utils.appenderror("errcode", 9003)
    return
end

local enablevalue
if data["Enable"] then
    enablevalue = "1"
else
    enablevalue = "0"
end

ret = web.setanonymous(enablevalue, data["AllPath"], data["ReadOnly"], data["Path"], data["Base64Path"])
utils.appenderror("errcode", ret)
