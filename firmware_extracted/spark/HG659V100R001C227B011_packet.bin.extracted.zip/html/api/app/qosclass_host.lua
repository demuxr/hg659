local utils = require('utils')
require('dm')

local print = print

local policerMaps = {
	MeterType = "MeterType",
	DeviceDownRateEnable = "PolicerEnable",
	DeviceMaxDownLoadRate = "X_DownPeakRate"
}

local classMaps = {
	DeviceDownRateEnable = "ClassificationEnable",
	Name = "ClassificationName",
	MACAddress = "SourceMACAddress",
	ClassQueue = "ClassQueue"
}

function calc_index(instanceId)
	local errcode,policerVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Policer.{i}.", 
		{"MeterType"});
	local array = {}
	i = 1
	if policerVals ~= nil then
		for k,v in pairs(policerVals) do
	    	local p,e = utils.findLastPoint(k)
	    	array[i] = tonumber(p)
	    	i = i+1
		end
	end
	table.sort(array)

	for j=1, i-1 do
		if array[j] == instanceId then
			return j
		end
	end
	return -1
end

-- new class
function create_class()
	local errcode
	local name = nil
	if data["DeviceDownRateEnable"] == false then
		utils.appenderror("errcode", 0)
		return 0
	end
	if data["ActualName"] ~= '' then
		name = data["ActualName"]
	else
		name = data["HostName"]
	end
	
	-- add policer
	data["MeterType"] = "TwoRateThreeColor"
	local paras = utils.GenAddObjParamInputs(data, policerMaps) 

	local errcode, newPolicer, NeedReboot, errparams = dm.AddObjectWithValues("InternetGatewayDevice.QueueManagement.Policer.", paras);
	utils.responseErrorcode(errcode, errparams, policerMaps)

	if 0 ~= errcode then
		return errcode
	end

	local policerIdex = calc_index(newPolicer)

	-- mac class
	paras = {{"ClassificationEnable", data["DeviceDownRateEnable"]}, 
	     {"ClassificationName", name},	
		 {"X_QosLinkType", 3},
		 {"X_ShowFlag", 1},
		 {"SourceMACAddress", data["MACAddress"]}, 
		 {"X_Type", 2}, 
		 {"ClassQueue", -1},
		 {"ClassPolicer", policerIdex}}

	if utils.toboolean(data["DeviceDownRateEnable"]) then
		local err = dm.SetParameterValues("InternetGatewayDevice.QueueManagement.Enable", "1")
	end

	local errcode, newClass, NeedReboot,paramerr = dm.AddObjectWithValues("InternetGatewayDevice.QueueManagement.Classification.", paras);
	utils.responseErrorcode(errcode, paramerr, classMaps)
	if errcode ~= 0 then
		dm.DeleteObject("InternetGatewayDevice.QueueManagement.Policer."..newPolicer)
	end

	return errcode
end

function update_class()
	-- body
	local domain = data["PolicerID"]
	local paras = {{domain.."PolicerEnable", data["DeviceDownRateEnable"]}, 
		{domain.."X_DownPeakRate", data["DeviceMaxDownLoadRate"]}}

	local errcode , NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, policerMaps)
	
	domain = data["QosclassID"]


	local name = nil
	if data["ActualName"] ~= '' then
		name = data["ActualName"]
	else
		name = data["HostName"]
	end

	-- mac class
	paras = {{domain.."ClassificationEnable", data["DeviceDownRateEnable"]},{domain.."ClassQueue", data["ClassQueue"]},{domain.."ClassificationName", name}};

	errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, classMaps)
	
	return errcode
end

if data["QosclassID"] == '' then
	err = create_class()
else
	err = update_class()
end


