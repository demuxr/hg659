require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local accounts = {}

function get_folderinfo(domain)
    local start = string.find(domain, "UserAccess")
    local folder_domain = string.sub(domain, 1, start - 1)
    if folder_domain == nil then
        return "",""
    end

    local errcode, values = dm.GetParameterValues(folder_domain, { "Name", "X_NameNative" });
    local obj = values[folder_domain]

    return obj["Name"], obj["X_NameNative"]
end

-- user accounts
local errcode, pathAcc = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.LogicalVolume.{i}.Folder.{i}.UserAccess.{i}.",
    {"UserReference"}
)

function set_account_path(domain, account)
    if pathAcc ~= nil then
        for k,v in pairs(pathAcc) do
            if (v["UserReference"]..".") == domain then
                account.Path, account.Base64Path = get_folderinfo(k)
                print(v["UserReference"], account.Path)
            end
        end
    end
end


local accounts_data = {}
local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.UserAccount.{i}.", { "Enable", "Username", "Password", "X_AllPath", "X_Permissions" } )
if values ~= nil then
    for k,v in pairs(values) do
        local account = {}
        account.ID = k
        account.Enable = utils.toboolean(v["Enable"])
        account.Username = v["Username"]
        account.Password = v["Password"]
        account.AllPath = v["X_AllPath"]
        account.ReadOnly = v["X_Permissions"]
        account.Path = ""
        account.Base64Path = ""
        set_account_path(k, account)

        table.insert(accounts_data, account)
    end
end

web.print(json.encode(accounts_data))