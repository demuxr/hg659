require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber
local app = {}
local type = 0

if FormData["type"] ~= nil then
    type = tonumber(FormData["type"])
end

function match_type(type, datatype)	
	if type == 0 then
		return true
	end

	local bit = {0, 0 ,0, 0}

	if datatype >= 8 then
		bit[4] = 1
		datatype = datatype -8
	end

	if datatype >= 4 then
		bit[3] = 1
		datatype = datatype - 4
	end

	if datatype >= 2 then
		bit[2] = 1
		datatype = datatype - 2
	end

	if datatype >= 1 then
		bit[1] = 1
	end

	if bit[type] == 1 then
		return true
	end
	return false
end

local itemsmaps = {
    Protocol = "Protocol",
    ExternalPort = "ExternalPort",
    ExternalPortEnd = "ExternalPortEnd"
    }

function GetApplicationPortType(ApplicationId)
	local  webport = 80
	local domain = ApplicationId.."Content.{i}."
    local errcode, appVals = dm.GetParameterValues(domain, itemsmaps)    
    local IfHaveWebPort = false
    for kk,vv in pairs(appVals) do     	
        local start = string.find(vv["Protocol"], "TCP")
        if start then
            if (vv["ExternalPort"] <= webport) and (vv["ExternalPortEnd"] >= webport) then                
                return true
            end            
        end
    end
    return false
end

local errcode, appVals = dm.GetParameterValues("InternetGatewayDevice.Services.X_Application.{i}.", 
    {"Name", "Type"});

if appVals ~= nil then 
	for k,v in pairs(appVals) do
	    if match_type(type, v["Type"]) then
	        local newApp = {}
	        newApp["ID"] = k
	        newApp["Name"] = v["Name"]
	        newApp["Type"] = v["Type"]
	        newApp["EnablePortmapping"] = match_type(1, v["Type"])
	        newApp["EnablePorttrigger"] = match_type(2, v["Type"])
	        newApp["EnableQos"] = match_type(3, v["Type"])
	        newApp["EnableFilter"] = match_type(4, v["Type"])
	        newApp["ObjAcc"] = v["ObjAcc"]
	        local webPortFlag = GetApplicationPortType(k)
	        if true == webPortFlag then
	        	newApp["Flag"] = 1
	        else
	        	newApp["Flag"] = 0
	        end
	        table.insert(app, newApp)
	    end
	end
end

utils.multiObjSortByID(app)
web.print(json.encode(app))