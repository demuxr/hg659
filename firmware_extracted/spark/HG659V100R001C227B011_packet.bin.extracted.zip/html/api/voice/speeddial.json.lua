local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues

local buttondata = {}
local errcode,buttonlist = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.Button.{i}.",{"QuickDialNumber","Destination","Description"});

if buttonlist then
	for k,v in pairs(buttonlist) do
		local buttonitem = {}
		buttonitem["ID"] = k
		if v["QuickDialNumber"]~= "" then
			buttonitem["SpeedNumber"] =string.sub(v["QuickDialNumber"], 3, -1) 
		else
			buttonitem["SpeedNumber"] = ""
		end
		print("SpeedNumber",v["QuickDialNumber"])
		buttonitem["ActualNumber"] = v["Destination"]
		buttonitem["SpeedDescription"] = v["Description"]
		table.insert(buttondata,buttonitem)
	end
end
web.print(json.encode(buttondata))
