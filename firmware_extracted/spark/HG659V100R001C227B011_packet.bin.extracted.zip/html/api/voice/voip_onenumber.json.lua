require('dm')
require('web')
require('json')

local ID = nil

local voice_number = {}

if FormData["ID"] ~= nil then
    ID = FormData["ID"]
end

if ID == nil then
    web.print(json.encode(voice_number))
    return 
end


local numbertems = {}
local SipNum_obj = {}
local errcode, line_values = dm.GetParameterValues(ID, {"Status", "DirectoryNumber", "X_LineSeq", "Enable"});
if nil ~= line_values then
    for kk, vv in pairs(line_values) do
        SipNum_obj.ID = kk
        SipNum_obj.Status = vv["Status"]
        SipNum_obj.Number = vv["DirectoryNumber"]
        SipNum_obj.LineSeq = vv["X_LineSeq"]

        if vv["Enable"] == "Enabled" then
            SipNum_obj.Enable = true
        else
            SipNum_obj.Enable = false
        end
        
        local errcode, each_line_sip = dm.GetParameterValues(kk.."SIP.", {"AuthUserName", "AuthPassword"});
        local each_line_sip_obj = each_line_sip[kk.."SIP."]
        SipNum_obj.Username = each_line_sip_obj["AuthUserName"]
        SipNum_obj.Password = each_line_sip_obj["AuthPassword"]
    end
end
web.print(json.encode(SipNum_obj))
