local utils = require('utils')

local domain = data["ID"]

local maps = {
    AttachedList="X_AttachedLineList"
}

print(data["ID"])
print(data["AttachedList"])

local param = utils.GenSetObjParamInputs(data["ID"], data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)