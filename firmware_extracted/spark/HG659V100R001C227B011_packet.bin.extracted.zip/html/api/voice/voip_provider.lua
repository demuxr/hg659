require('web')
require('dm')
local utils = require('utils')

local voip_profile_maps = {
    ProviderName="Name"
}

local voip_sip_maps = {
    RegistrarServer="RegistrarServer",
    ProxyServer="ProxyServer",
    SipDomain="X_SIPDomain",
    OutboundServer="OutboundProxy",
    OutboundServerPort = "OutboundProxyPort",
    MainRegisterPort = "RegistrarServerPort",
    MainProxyPort = "ProxyServerPort",
    SecondRegistrarServer = "X_SecondRegistrarServer",
    SecondRegistrarPort = "X_SecondRegistrarServerPort",
    SecondProxyServer = "X_SecondProxyServer",
    SecondProxyPort = "X_SecondProxyServerPort",
    UserAgentPort = "UserAgentPort"
}

function gen_voip_profile_settings(domain)
    local setting_paras = {}
    utils.GenSetObjParamInputsEx(domain, data, voip_profile_maps, setting_paras)
    utils.GenSetObjParamInputsEx(domain.."SIP.", data, voip_sip_maps, setting_paras)

    return setting_paras
end

function create_voip_profile()
    local adding_profile_paras = utils.GenAddObjParamInputs(data, voip_profile_maps)
    local err,profile_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.", adding_profile_paras)
    if err ~= 0 then
        utils.responseErrorcode(err, errs, voip_profile_maps)
    else
        local profile_domain = "InternetGatewayDevice.Services.VoiceService.1.VoiceProfile."..profile_id.."."
        local setting_profile_sipdata = gen_voip_profile_settings(profile_domain)
        err,needreboot, paramerror = dm.SetParameterValues(setting_profile_sipdata)
        if err ~= 0 then
            utils.responseErrorcode(err, paramerror, voip_sip_maps)
            return
        end
        utils.appenderror("errcode", 0)
    end
end

function update_profile()
    if data["ID"] == "" then
        utils.appenderror("errcode", 200)
        return
    end
    local setting_paras = gen_voip_profile_settings(data["ID"])
  
    if nil == setting_paras then
        utils.appenderror("errcode", 201)
    else
        local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)
        utils.responseErrorcode(err, paramerror, voip_profile_maps)
        utils.responseErrorcode(err, paramerror, voip_sip_maps)
    end
end

function delete_voip_profile()
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 300)
    end
end
print("action "..action)
if data["SecondRegistrarPort"] == nil then
	data["SecondRegistrarPort"] = "5060"
end
if data["SecondRegistrarServer"] == nil then
	data["SecondRegistrarServer"] = ""
end
if data["SipDomain"] == nil then
	data["SipDomain"] = ""
end
if action == "create" then
        create_voip_profile()
elseif action == "update" then
	update_profile()
elseif action == "delete" then
    delete_voip_profile()
else
    utils.appenderror("errcode", 400)
end