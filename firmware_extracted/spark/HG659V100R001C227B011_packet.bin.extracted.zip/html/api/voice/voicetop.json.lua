require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode_line,line_values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.VoiceProfile.{i}.Line.{i}.", {"DirectoryNumber", "CallState"});

function IsNumberBusy(attachlist, linevalues)
    if nil ~= linevalues then
        if "all" == attachlist then
            for k,v in pairs(linevalues) do
                if v["CallState"] == "Busy" or v["CallState"] == "Calling" or v["CallState"] == "Ringing" then
                    return "Busy"
                end
            end
        else
            local splitlist = utils.split(attachlist, ",")
            for k1, v1 in pairs(splitlist) do
                for k2,v2 in pairs(linevalues) do
                    if v1 == v2["DirectoryNumber"] then
                        if v2["CallState"] == "Busy" or v2["CallState"] == "Calling" or v2["CallState"] == "Ringing" then
                            return "Busy"
                        end
                   end
                end
            end
        end
    end
    return "Idle"
end

local  voiceList = {}
local phy_errcode,phy_values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.PhyInterface.{i}.", {"X_InCallNumber", "InterfaceID"});
for k,v in pairs(phy_values) do
    local voiceitem = {}
    voiceitem.ID = k  
    voiceitem.callnumber = v["X_InCallNumber"]
    
    local status = web.getVoicePortStatus(v["InterfaceID"]-1)
    if 1 == status then
        voiceitem.status = "Busy"
    else
        voiceitem.status = "Idle"
    end 

    table.insert(voiceList, voiceitem)
end
utils.multiObjSortByID(voiceList)
web.print(json.encode(voiceList))
