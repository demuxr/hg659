local utils = require('utils')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="STUNEnable",
    url = "STUNServerAddress",
    name = "STUNUsername",
    pwd = "STUNPassword",
    conname = "X_StunConnectionRequestUsername",
    conpwd = "X_StunConnectionRequestPassword",
    port = "STUNServerPort",
    min = "STUNMinimumKeepAlivePeriod",
    max = "STUNMaximumKeepAlivePeriod",
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
