local utils = require('utils')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="EnableCWMP",
    acsurl = "URL",
    acsname = "Username",
    acspwd = "Password",
    inform = "PeriodicInformEnable",
    interval = "PeriodicInformInterval",
    conname = "ConnectionRequestUsername",
    conpwd = "ConnectionRequestPassword",
    conport = "X_ConnReqPort",
    cert = "X_SSLCertEnable"
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
