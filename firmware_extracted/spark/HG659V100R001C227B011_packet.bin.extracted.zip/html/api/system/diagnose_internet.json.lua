local dm = require('dm')
local utils = require('utils')
local web = require('web')
local json = require('json')

local GetParameterValues, appendSingleObj, toboolean  = dm.GetParameterValues, utils.appendSingleObj, utils.toboolean
local strsub, strlen, find = string.sub, string.len, string.find
local pmupnp = web.gmsgget('nat', 0, {})

local defaultwan = ""
local has_internet = true

if defaultwan == "" then
	defaultwan, has_internet = utils.getDefaultWan()
	defaultwan = strsub(defaultwan, 1, strlen(defaultwan)-1)
end

local obj = web.gmsgget('wan', 3, {Path=defaultwan})

utils.parse_wan_status(obj.StatusCode, obj)


local ip = find(defaultwan, "WANConnectionDevice")
local linkLayer = ""
if nil ~= ip then
	linkLayer = strsub(defaultwan, 1, ip-1)
end
maps = {
	WANAccessType = "WANAccessType",
	UpMaxBitRate = "Layer1UpstreamMaxBitRate",
	DownMaxBitRate = "Layer1DownstreamMaxBitRate"
}

local errcode,values = GetParameterValues(linkLayer.."WANCommonInterfaceConfig.", maps)
if values ~= nil then
	local linklayerObj = values[linkLayer.."WANCommonInterfaceConfig."]

	linklayerObj.Layer1UpstreamMaxBitRate   = linklayerObj.Layer1UpstreamMaxBitRate/1000000
	linklayerObj.Layer1DownstreamMaxBitRate = linklayerObj.Layer1DownstreamMaxBitRate/1000000

	appendSingleObj(obj, linklayerObj, maps)

	if linklayerObj["WANAccessType"] == 'Ethernet' then
		local errcode, values = GetParameterValues(linkLayer.."WANEthernetInterfaceConfig.", 
			{"MaxBitRate", "DuplexMode", "Status"})
		local ethObj = values[linkLayer.."WANEthernetInterfaceConfig."]
		obj.MaxBitRate = ethObj["MaxBitRate"]
		obj.DuplexMode = ethObj["DuplexMode"]
		obj.LinkStatus = ethObj["Status"]
		obj.UpMaxBitRate = ethObj["MaxBitRate"]
		obj.DownMaxBitRate = ethObj["MaxBitRate"]
	elseif linklayerObj["WANAccessType"] == 'DSL' then
		local errcode, values = GetParameterValues(linkLayer.."WANDSLInterfaceConfig.", 
			{"ModulationType", "Status", "UpstreamCurrRate", "DownstreamCurrRate"})
		if values ~= nil then
			local dslObj = values[linkLayer.."WANDSLInterfaceConfig."]
			obj.ModulationType = dslObj["ModulationType"]
			obj.LinkStatus = dslObj["Status"]
			obj.UpMaxBitRate = dslObj["UpstreamCurrRate"]/1000
			obj.DownMaxBitRate = dslObj["DownstreamCurrRate"]/1000
		end
	elseif linklayerObj["WANAccessType"] == 'VDSL' then
		local errcode, values = GetParameterValues(linkLayer.."WANDSLInterfaceConfig.", 
			{"ModulationType", "Status", "UpstreamCurrRate", "DownstreamCurrRate"})
		if values ~= nil then
			local dslObj = values[linkLayer.."WANDSLInterfaceConfig."]
			obj.ModulationType = dslObj["ModulationType"]
			obj.LinkStatus = dslObj["Status"]
			obj.UpMaxBitRate = dslObj["UpstreamCurrRate"]/1000
			obj.DownMaxBitRate = dslObj["DownstreamCurrRate"]/1000
		end
	end
end

local maps = {
	DefaultGateway="DefaultGateway",
	DNSServers = "DNSServers",
	ExternalIPAddress = "ExternalIPAddress",
	X_IPv4Enable = "X_IPv4Enable",
	X_IPv6Enable = "X_IPv6Enable",
	X_IPv6ConnectionStatus = "X_IPv6ConnectionStatus",
	X_IPv6Address = "X_IPv6Address",
	X_IPv6PrefixLength = "X_IPv6PrefixLength",
	X_IPv6DefaultGateway = "X_IPv6DefaultGateway",
	X_IPv6DNSServers = "X_IPv6DNSServers",
	X_IPv6PrefixList = "X_IPv6PrefixList",
	X_IPv6AddressingType = "X_IPv6AddressingType",
	ConnectionStatus = "ConnectionStatus",
	Uptime = "Uptime",
	MACAddress = "MACAddress"
}

local errcode, values = GetParameterValues(defaultwan..'.', maps)

if values ~= nil then
	local wanStatusObj = values[defaultwan.."."]
	wanStatusObj.X_IPv4Enable = toboolean(wanStatusObj.X_IPv4Enable)
	wanStatusObj.X_IPv6Enable = toboolean(wanStatusObj.X_IPv6Enable)
	wanStatusObj.MACAddress = wanStatusObj.MACAddress
	appendSingleObj(obj, wanStatusObj, maps)
end
obj.HasInternetWan = has_internet
web.print(json.encode(obj))
