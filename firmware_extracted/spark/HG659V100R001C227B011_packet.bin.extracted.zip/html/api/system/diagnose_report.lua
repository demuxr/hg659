require('dm')
require('web')
require('json')
require('utils')

local fo = assert (io.open ("/var/diagnose_report", "w"))
fo:write(data["Report"])

local pmupnp = io.open ("/var/pmupnp", "r")
if nil ~= pmupnp then
    fo:write("\r\n")
    for line in pmupnp:lines() do
        fo:write(line)
        fo:write("\r\n")
    end

    pmupnp:close()
    os.remove("/var/pmupnp")
end


fo:close()