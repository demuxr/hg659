require('dm')
require('utils')
require('web')
require('json')

local maps = {
	MACAddress = "AssociatedDeviceMACAddress",
	Rssi = "AssociatedDeviceRssi",
	Rate = "AssociatedDeviceRate",
	BandWidth = "AssociatedDeviceBandWidth"
}

local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.WLANConfiguration.{i}.AssociatedDevice.{i}.",
    maps)

utils.responseMultiObjects(lanVals, maps)