local dm  = require('dm')
local web = require('web')
local json = require('json')
local utils = require('utils')
local tostring = tostring
local GetParameterValues = dm.GetParameterValues

local errcode,cap = GetParameterValues("InternetGatewayDevice.DeviceInfo.X_Capacity.",
    {
        "WIFI",
        "GuestNetwork",
        "USB",
        "PowerSave"
    }
);

local obj = cap["InternetGatewayDevice.DeviceInfo.X_Capacity."]

local devcap = {}

devcap.WIFI = obj["WIFI"]
devcap.GuestNetwork = obj["GuestNetwork"]
devcap.USB = obj["USB"]
devcap.PowerSave = obj["PowerSave"]

web.print(json.encode(devcap))