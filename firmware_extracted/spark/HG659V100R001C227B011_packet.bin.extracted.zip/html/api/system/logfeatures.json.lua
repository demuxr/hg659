local features = {
    [1] = {
        feature = "igmp",
        enable = true
    },
    [2] = {
        feature = "web",
        enable = true
    },
    [3] = {
        feature = "upg",
        enable = true
    },
    [4] = {
        feature = "cfm",
        enable = true
    },
    [5] = {
        feature = "nat",
        enable = true
    },
    [6] = {
        feature = "qos",
        enable = true
    },
    [7] = {
        feature = "wan",
        enable = true
    },
    [8] = {
        feature = "sntp",
        enable = true
    },
    [9] = {
        feature = "wlan",
        enable = true
    },
    [10] = {
        feature = "log",
        enable = true
    },
    [11] = {
        feature = "upnp",
        enable = true
    },
    [12] = {
        feature = "cwmp",
        enable = true
    },
    [13] = {
        feature = "pppc",
        enable = true
    },
    [14] = {
        feature = "ddns",
        enable = true
    },
    [15] = {
        feature = "voice",
        enable = true
    },
    [16] = {
        feature = "usbmount",
        enable = true
    },
    [17] = {
        feature = "cli",
        enable = true
    },
    [18] = {
        feature = "bhal",
        enable = true
    },
    [19] = {
        feature = "firewall",
        enable = true
    },
    [20] = {
        feature = "xdsl",
        enable = true
    },
    [21] = {
        feature = "powermngt",
        enable = true
    }
}

web.print(json.encode(features))
