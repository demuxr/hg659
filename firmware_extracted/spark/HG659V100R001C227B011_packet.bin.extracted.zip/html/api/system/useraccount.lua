local utils = require('utils')
local web = require('web')
local tostring = tostring

local maps = {
	username = "Username",
	newpwd = "Userpassword",
	enableprompt = "EnablePasswdPrompt",
	promptinfo = "UserpasswdPrompt"
}

function add_one_parameter(paras, name, value)
	if nil == value then
		return 
	end	
	table.insert(paras, {name, value})
end

function submit_data(paras, data)
	
	if nil == data then
		return
	end
	if nil == data["ID"] then
		return 
	end	
	local domain = data["ID"]
	-- check password
	local login_user, login_level = web.getuserinfo()
	local errcode,values = dm.GetParameterValues(domain, {"Userpassword", "Userlevel"});
	local cur_account = values[domain]

	if login_level ~= 2 or data["userlevel"] == 2 then
		if cur_account["Userpassword"] ~= data["curpwd"] then
			utils.appenderror("errcode", 10)
			utils.appenderror("curpwd", "useraccount.errpwd")
			return
		end
	end

	add_one_parameter(paras, domain.."Userpassword", data["newpwd"])
	if data["userlevel"] ~= 2 then
		add_one_parameter(paras, domain.."Username", data["username"])
	end

end

function create()
    local paras = utils.GenAddObjParamInputs(data, maps)
    
    local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.UserInterface.X_Web.UserInfo.", paras);
    utils.responseErrorcode(errcode, paramerr, maps)
    return errcode
end

function delete()
    return dm.DeleteObject(data["ID"])
end

function update()	
	local paras = {}
	submit_data(paras, data)
    local errcode, NeedReboot, paramerr =  dm.SetParameterValues(paras)
    utils.responseErrorcode(errcode, paramerr, maps)
    if errcode ~= 0 then
    	_G["webtimes"] = _G["webtimes"] + 1
    	if _G["webtimes"] > 3 then
    		_G["webtimes"] = 0
    		web.logout()
    	end
    else
    	_G["webtimes"] = 0
    end
    return errcode
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    err = update()
elseif action == 'delete' then
    err = delete()
else
    return
end
utils.appenderror("errcode", err)
