require('dm')
require('utils')

local maps = {
	DiagnoseAction="DiagnosticsState"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_WLANDiagnostic.", maps)

local obj = values["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_WLANDiagnostic."]
utils.responseSingleObject(obj, maps)
