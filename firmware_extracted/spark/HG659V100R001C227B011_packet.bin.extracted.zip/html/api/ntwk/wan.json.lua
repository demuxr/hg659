require('dm')
require('web')
require('json')
require('utils')


local tostring = tostring
local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType", "PhysicalLinkStatus"})
    
local errcode, atmlink = dm.GetParameterValues("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.{i}.WANDSLLinkConfig.",
            {"LinkStatus"})
local errcode, ptmlink = dm.GetParameterValues("InternetGatewayDevice.WANDevice.2.WANConnectionDevice.{i}.WANDSLLinkConfig.",
            {"LinkStatus"})

local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    "Enable", "ConnectionType", "Username", "Password", 
    "X_APN", "X_DialNumber",
    "X_IPv4Enable", "X_IPv6Enable", "X_IPv6ConnectionStatus", "X_IPv6AddressingType", "X_IPv6Address", "X_IPv6PrefixLength",
     "X_IPv6DefaultGateway", "X_IPv6DNSServers", "X_IPv6PrefixList",
     "X_ServiceList", "X_LowerLayers", "MaxMRUSize", "X_TCP_MSS", "NATEnabled", "X_NATType",
     "PPPAuthenticationProtocol", "ConnectionTrigger", "IdleDisconnectTime",
     "ExternalIPAddress", "DNSServers", "DNSOverrideAllowed","ConnectionStatus", "X_ServerACName",
     "X_Default", "MACAddressOverride", "MACAddress", "PPPoEServiceName"});

local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    "Enable", "ConnectionType", "X_ServiceList", "X_LowerLayers", "MaxMTUSize", "X_TCP_MSS", "NATEnabled", "X_NATType",
    "X_IPv4Enable", "X_IPv6Enable", "X_IPv6ConnectionStatus", "X_IPv6AddressingType", "X_IPv6Address", "X_IPv6PrefixLength",
     "X_IPv6DefaultGateway", "X_IPv6DNSServers", "X_IPv6PrefixList",
     "AddressingType", "ExternalIPAddress", "SubnetMask", "DefaultGateway", "DNSServers", "DNSOverrideAllowed", "ConnectionStatus",
     "X_Default", "MACAddressOverride", "MACAddress"});

function get_lower_layer(ID, lowerlayer)
    if nil == lowerlayer or "" == lowerlayer then
        local start = string.find(ID, ".WANPPPConnection.")
        if not start then
            start = string.find(ID, ".WANIPConnection.")
        end
        return string.sub(ID, 0, start)
    else
        lowerlayer = string.gsub(lowerlayer, "X_".."ATP".."_VLANTermination", "X_VLANTermination")
    end

    return lowerlayer.."."
end

local connections = {}

-- Support three mode:
-- 0: get all wan
-- 1: get all default wan
-- 2: get currently active default wan
local wantype = 0

if FormData and FormData["type"] ~= nil then
    if "alldefault" == FormData["type"] then
        wantype = 1
    elseif "active" == FormData["type"] then
        wantype = 2
    end
end

local activeDftWan = ""
if 2 == wantype then    
    local obj = web.gmsgget("wan", 0, {})
    -- 1: not backup; 2: confirming; 3: backup obj.Status
    if "1" ~= tostring(obj.Status) then
        activeDftWan = utils.getUmtsWan(pppCon, accessdevs)
        if "" == activeDftWan then
            activeDftWan = utils.getDefaultWan(pppCon, ipCon, accessdevs)
        end
    else
        activeDftWan = utils.getDefaultWan(pppCon, ipCon, accessdevs)
    end
end
function get_str_before(str, symbol)
    if str == nil then
        return nil
    end
    local pos = string.find(str, symbol)
    if pos then
        return string.sub(str, 0, pos-1)
    end
    return str
end

for k,v in pairs(pppCon) do
    local con = {}
    con.ID = k
    con.Name = v["Name"]
    con.Alias = v["X_WanAlias"]
    if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
        con.Name = v["X_WanAlias"]
    end
    con.Enable = utils.toboolean(v["Enable"])
    utils.fill_access_info_by_ID(k, con, accessdevs);
    if con.AccessType == "DSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, atmlink)
    elseif con.AccessType == "VDSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, ptmlink)
    end

    con.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
    con.LowerLayer = get_lower_layer(k, v["X_LowerLayers"])
    con.Username = v["Username"]
    con.Password = _G["defaultPasswd"]
    con.ConnectionStatus = v["ConnectionStatus"]
    con.IPv6ConnectionStatus = v["X_IPv6ConnectionStatus"]
    con.APN = v["X_APN"]
    con.DialNum = v["X_DialNumber"]
    con.ServiceList = v["X_ServiceList"]
    con.MRU = v["MaxMRUSize"]
    con.MTU = 1500
    con.MSS = v["X_TCP_MSS"]
    con.NATType = 0
    if utils.toboolean(v["NATEnabled"]) then
        if "full cone" == v["X_NATType"] then
            con.NATType = 2
        else
            con.NATType = 1
        end
    end
    con.PPPAuthMode = v["PPPAuthenticationProtocol"]
    con.PPPTrigger = v["ConnectionTrigger"]
    con.PPPIdletime = v["IdleDisconnectTime"]
    con.IPv4Enable = utils.toboolean(v["X_IPv4Enable"])
    con.IPv4AddrType = "DHCP"
    con.IPv4Addr = v["ExternalIPAddress"]
    con.IPv4Mask = ""
    con.IPv4Gateway = ""
    con.IPv4DnsServers = v["DNSServers"]
    
    con.DNSOverrideAllowed = utils.toboolean(v["DNSOverrideAllowed"])
    if con.DNSOverrideAllowed then
        con.DNSOverrideAllowed = false
    else
        con.DNSOverrideAllowed = true
    end
    con.IPv6Enable = utils.toboolean(v["X_IPv6Enable"])
    con.IPv6AddrType = v["X_IPv6AddressingType"]
    con.IPv6Addr = v["X_IPv6Address"]
    con.IPv6AddrSet = get_str_before(v["X_IPv6Address"], "/")
    if "Static" ~= con.IPv6AddrType then
        con.IPv6AddrPrefixLen = 64
    else
        con.IPv6AddrPrefixLen = v["X_IPv6PrefixLength"]
    end
    con.IPv6Gateway = v["X_IPv6DefaultGateway"]
    con.IPv6DnsServers = v["X_IPv6DNSServers"]
    con.IPv6PrefixList = v["X_IPv6PrefixList"]
    con.IsDefault = v["X_Default"]
    con.MACColone = v["MACAddress"]
    con.MACColoneEnable = utils.toboolean(v["MACAddressOverride"])
    con.PPPoEServiceName = v["PPPoEServiceName"]
    con.PPPoEACName     = v["X_ServerACName"]
    if ("" ~= activeDftWan and k == activeDftWan) then
        web.print(json.encode(con))
        return
    end

    if (0 == wantype) or
       (1 == wantype and utils.toboolean(v["X_Default"])) then
        if utils.is_same_mode(CurrentMode, con.AccessType) then
        table.insert(connections, con)
        end
    end
end

for k,v in pairs(ipCon) do
    local con = {}
    con.ID = k
    con.Name = v["Name"]
    con.Alias = v["X_WanAlias"]
    if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
        con.Name = v["X_WanAlias"]
    end
    con.Enable = utils.toboolean(v["Enable"])
    utils.fill_access_info_by_ID(k, con, accessdevs);
    if con.AccessType == "DSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, atmlink)
    elseif con.AccessType == "VDSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, ptmlink)
    end
    con.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
    con.LowerLayer = get_lower_layer(k, v["X_LowerLayers"])
    con.Username = ""
    con.Password = _G["defaultPasswd"]
    con.ConnectionStatus = v["ConnectionStatus"]
    con.IPv6ConnectionStatus = v["X_IPv6ConnectionStatus"]
    con.APN = ""
    con.DialNum = ""
    con.ServiceList = v["X_ServiceList"]
    con.MRU = 1492
    con.MTU = v["MaxMTUSize"]
    con.MSS = v["X_TCP_MSS"]
    con.NATType = 0
    if utils.toboolean(v["NATEnabled"]) then
        if "full cone" == v["X_NATType"] then
            con.NATType = 2
        else
            con.NATType = 1
        end
    end
    con.PPPAuthMode = "AUTO"
    con.PPPTrigger = "AlwaysOn"
    con.PPPIdletime = 60
    con.IPv4Enable = utils.toboolean(v["X_IPv4Enable"])
    con.IPv4AddrType = v["AddressingType"]
    con.IPv4Addr = v["ExternalIPAddress"]
    con.IPv4Mask = v["SubnetMask"]
    con.IPv4Gateway = v["DefaultGateway"]
    con.IPv4DnsServers = v["DNSServers"]
    con.DNSOverrideAllowed = utils.toboolean(v["DNSOverrideAllowed"])

    if con.DNSOverrideAllowed then
        con.DNSOverrideAllowed = false
    else
        con.DNSOverrideAllowed = true
    end
    con.IPv6Enable = utils.toboolean(v["X_IPv6Enable"])
    con.IPv6AddrType = v["X_IPv6AddressingType"]
    con.IPv6Addr = v["X_IPv6Address"]
    con.IPv6AddrSet = get_str_before(v["X_IPv6Address"], "/")
    if "Static" ~= con.IPv6AddrType then
        con.IPv6AddrPrefixLen = 64
    else
        con.IPv6AddrPrefixLen = v["X_IPv6PrefixLength"]
    end
    con.IPv6Gateway = v["X_IPv6DefaultGateway"]
    con.IPv6DnsServers = v["X_IPv6DNSServers"]
    con.IPv6PrefixList = v["X_IPv6PrefixList"]
    con.IsDefault = v["X_Default"]
    con.MACColone = v["MACAddress"]
    con.MACColoneEnable = utils.toboolean(v["MACAddressOverride"])
    if ("" ~= activeDftWan and k == activeDftWan) then
        web.print(json.encode(con))
        return
    end
    if (0 == wantype) or
       (1 == wantype and utils.toboolean(v["X_Default"])) then

        if utils.is_same_mode(CurrentMode, con.AccessType) then
        table.insert(connections, con)
        end
    end
end

utils.multiObjSortByID(connections)

web.print(json.encode(connections))
