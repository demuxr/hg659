local utils = require('utils')
require('dm')
local print = print

local pt_maps = {
    Name="Name",
    Enable="Enable",
    ApplicationID="ApplicationID"
}

function create()
	-- add 
	local paras = {{"Name", data["Name"]}, 
		{"Enable", data["Enable"]},
	 	{"ApplicationID", data["ApplicationID"]}}

	local errcode, instnum, NeedReboot , errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.X_Porttrigger.", paras);
	
	if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, pt_maps)
    end
    utils.appenderror("errcode", 0)
	return errcode
end

function delete()

	return dm.DeleteObject(data["ID"])
end

function update()
    local domain = data["ID"]

    local param = utils.GenSetObjParamInputs(domain, data, pt_maps)
    local err,needreboot, paramerror = dm.SetParameterValues(param);
    if err ~= 0 then
        utils.responseErrorcode(err, paramerror, pt_maps)
    end
    utils.appenderror("errcode", 0)
    return err
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()

elseif action == 'delete' then
	err = delete()
else
	return
end
utils.appenderror("errcode", err)
