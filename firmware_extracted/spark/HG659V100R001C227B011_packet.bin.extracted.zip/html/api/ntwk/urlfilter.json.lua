require('dm')
require('web')
require('json')
require('utils')

function parsemacs(key, srcmac)
    local start = 1
    local devices = {}
    while true do
        print(srcmac)
        ip, fp = string.find(srcmac, "|", start)
        if not ip then
            local mac = {}
            mac[key] = string.sub(srcmac, start)
            table.insert(devices, mac)
            break
        end
        local mac = {}
        mac[key] = string.sub(srcmac, start, ip-1)
        table.insert(devices, mac)
        start = fp +1
    end

    return devices
end

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.UrlFilter.{i}.",
    {"Url", "Status", "DevMac"});

local urlfilter = {}

if objs ~= nil then
    for k,v in pairs(objs) do
        local newObj = {}
        newObj["ID"] = k
        newObj["URL"] = v["Url"]
        newObj["Status"] = v["Status"]
        if 0 == string.len(v["DevMac"]) then
            newObj["DevManual"] = false
            newObj["Devices"] = {}
        else
            newObj["DevManual"] = true
            newObj["Devices"] = parsemacs("MACAddress", v["DevMac"])
        end
        table.insert(urlfilter, newObj)
    end
end

utils.multiObjSortByID(urlfilter)
web.print(json.encode(urlfilter))