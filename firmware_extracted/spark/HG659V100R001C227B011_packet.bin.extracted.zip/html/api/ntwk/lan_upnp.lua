local utils = require('utils')

--local data = utils.getRequestFormData()

local maps = {
    enable ="Enable"
}

function add_one_upnp_parameter(paras, name, value)
    table.insert(paras, {name, value})
end

local paras = {}

add_one_upnp_parameter(paras, "InternetGatewayDevice.Services.X_UPnP.Enable", data["enable"])

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
