local utils = require('utils')

local maps = {
	DMZEnable="DMZEnable",
	DMZHostIPAddress = "DMZHostIPAddress"
}

local domain = data["WanID"].."X_DMZ."

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);

utils.responseErrorcode(err, paramerror, maps)
