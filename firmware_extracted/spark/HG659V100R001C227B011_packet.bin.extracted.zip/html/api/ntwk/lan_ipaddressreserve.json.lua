require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode,ipaddressreserve = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DHCPStaticAddress.{i}.", 
        {"Enable", "Chaddr", "Yiaddr"});

local errcode, hosts = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.", 
    {"X_DeviceName", "MACAddress","HostName"});

local ipaddresses = {}
for k,v in pairs(ipaddressreserve) do
    local ipaddress = {}
    ipaddress.ID = k
    ipaddress.Enable = utils.toboolean(v["Enable"])
    ipaddress.Chaddr = v["Chaddr"]
    ipaddress.Yiaddr = v["Yiaddr"]
    for p,q in pairs(hosts) do
    	if q["MACAddress"] == v["Chaddr"] then
    		ipaddress.ActualName = q["X_DeviceName"]
    		if "" == ipaddress.ActualName then
    			ipaddress.ActualName = q["HostName"]
    		end
    	end
    end

    table.insert(ipaddresses, ipaddress)
end
     
web.print(json.encode(ipaddresses))  