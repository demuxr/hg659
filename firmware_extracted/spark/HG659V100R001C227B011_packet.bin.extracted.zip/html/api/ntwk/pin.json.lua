local web = require('web')
require('json')
require('utils')

local tonumber = tonumber

local pin_result = {}

local stat,times = web.getPINStatus();

pin_result["SimState"] = stat
pin_result["RemainTime"] = times

web.print(json.encode(pin_result))
