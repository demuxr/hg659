local utils = require('utils')

local domain = "InternetGatewayDevice.X_VPN.L2TP_LAC."

local maps = {
	LACEnable="Enable",
	LNSAddress = "LNSAddress",
	HostName = "HostName",
	TunnelPassword = "PassWord",
	KeepAliveTime = "KeepAliveTime",
	PPPUsername = "PppUser",
	PPPPassword = "PppPass",
	ConnectionMode = "ConnectionTrigger",
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
