
require('dm')
require('web')
require('json')
require('utils')

local type = FormData["type"]


function CheckWan(id, wan)
    if type == "spoof" then
        if "DHCP_Spoofed" == wan.ConnectionType then 
            return true
        end
        return false
    end

    if type == "mldwan" then
        if utils.toboolean(wan.X_IPv6Enable) == false then
            return false
        end

        ip = string.find(wan.ConnectionType, "IP_Routed")
        if not ip then 
            return false
        end

        ip = string.find(wan.X_ServiceList, "INTERNET")
        ip2 = string.find(wan.X_ServiceList, "Other")
        if not ip and not ip2 then
            return false
        end

        if not wan.ConnectionTrigger then
            return true
        end

        trigger = string.find(wan.ConnectionTrigger, "OnDemand")
        if trigger then
                return false
        end

        return true
    end

    if type == "igmpwan" then
        if utils.toboolean(wan.X_IPv4Enable) == false then
            return false
        end
        if wan.NATEnabled == 0 then
            return false
        end

        ip = string.find(wan.ConnectionType, "IP_Routed")
        if not ip then 
            return false
        end

        ip = string.find(wan.X_ServiceList, "INTERNET")
        ip2 = string.find(wan.X_ServiceList, "Other")
        if not ip and not ip2 then
            return false
        end

        if not wan.ConnectionTrigger then
            return true
        end

        trigger = string.find(wan.ConnectionTrigger, "OnDemand")
        if trigger then
                return false
        end
        
        return true
    end

    if type == "routewan" then
        ip = string.find(wan.X_ServiceList, "INTERNET")
        ip2 = string.find(wan.X_ServiceList, "Other")
        if not ip and not ip2 then
            return false
        end
    end
    
    return true
end

local tostring = tostring
local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    "ConnectionType", "X_ServiceList", "NATEnabled", "ConnectionTrigger", 
    "X_IPv6Enable", "X_IPv4Enable"
    });
local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    {"Name",
    "X_WanAlias",
    "ConnectionType", "X_ServiceList", "NATEnabled",
    "X_IPv6Enable", "X_IPv4Enable"
    });

local connections = {}

for k,v in pairs(pppCon) do
    if CheckWan(k, v) then
        local con = {}
        con.ID = string.sub(k, 1, string.len(k)-1)
        con.Name = v["Name"]
        if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
            con.Name = v["X_WanAlias"]
        end
        table.insert(connections, con)
    end
end

for k,v in pairs(ipCon) do
    if CheckWan(k, v) then
        local con = {}
        con.ID = string.sub(k, 1, string.len(k)-1)
        con.Name = v["Name"]
        if v["X_WanAlias"] and "" ~= v["X_WanAlias"] then
            con.Name = v["X_WanAlias"]
        end
        table.insert(connections, con)
    end
end

local con = {}
con.ID = ""
con.Name = ""
if type ~= "routewan" and type ~= "allwan" then
    table.insert(connections, con)
end
utils.multiObjSortByID(connections)
web.print(json.encode(connections))
