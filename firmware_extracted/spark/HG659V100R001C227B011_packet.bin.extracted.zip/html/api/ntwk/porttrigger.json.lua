require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber

local portmapping = {}


local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.Services.X_Porttrigger.{i}.", 
    {"Name", "ApplicationID", "Enable"});

for k,v in pairs(objs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["Name"] = v["Name"]
    newObj["ApplicationID"] = v["ApplicationID"]
    newObj["Enable"] = utils.toboolean(v["Enable"])
    table.insert(portmapping, newObj)
end
utils.multiObjSortByID(portmapping)
web.print(json.encode(portmapping))

