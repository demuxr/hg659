require('web')
require('json')

local downcmd = "xdslcmd connection --down"
local upcmd = "xdslcmd connection --up"

web.exec(downcmd)
web.exec(upcmd)

utils.appenderror("errcode", 0)