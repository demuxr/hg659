require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local searchWanOnly = false
local res = {}

local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
            {"WANAccessType", "PhysicalLinkStatus"})

local wan = FormData["ID"]
res.BackupStatus = 1
if not wan then
	local obj = web.gmsgget("wan", 0, {})
	-- 1: not backup; 2: confirming; 3: backup obj.Status
	res.BackupStatus = obj.Status;
	--res.BackupStatus = 2;

	if "1" ~= tostring(res.BackupStatus) then
		wan = utils.getUmtsWan(nil, accessdevs)
		if "" == wan then
			wan = utils.getDefaultWan(nil, nil, accessdevs)
		end
	else
		wan = utils.getDefaultWan(nil, nil, accessdevs)
	end
end

-- Get Link status
res.ID = wan
res.AccessType = "Down"
res.AccessStatus = "DSL"
utils.fill_access_info_by_ID(wan, res, accessdevs)

-- Get PVCSearch result
res.PVCResult = ""
res.WanResult = "0"
res.SearchingStatus = "Finished"
local errcode,backupParams = dm.GetParameterValues("InternetGatewayDevice.Services.X_PVCSearch.", 
	    {"PVCSearchResult", "ResultFlag", "Enable"});
if backupParams then
	params = backupParams["InternetGatewayDevice.Services.X_PVCSearch."]
	if utils.toboolean(params["Enable"]) then
		res.SearchingStatus = "Scanning"
	end
	res.PVCResult = params["PVCSearchResult"]
	res.WanResult = params["ResultFlag"]
end

-- Get Connection Type detection result
local obj = web.gmsgget("pvcsearchcms", 0, {})
if obj then
if "0" ~= tostring(obj.SearchStatus) then
	res.SearchingStatus = "Scanning"
end
if "0" == tostring(res.WanResult) then
res.WanResult = obj.WanType
end
end
-- Get wan connection status
local stripped_wan = utils.strip_end_dot(wan)
local obj = web.gmsgget('wan', 3, {Path=stripped_wan})
utils.parse_wan_status(obj.StatusCode, res)

local maps = {
	ConnectionType="ConnectionType",
	DefaultGateway="DefaultGateway",
	DNSServers = "DNSServers",
	ExternalIPAddress = "ExternalIPAddress",
	IPv4Enable = "X_IPv4Enable",
	IPv6Enable = "X_IPv6Enable",
	IPv6ConnectionStatus = "X_IPv6ConnectionStatus",
	IPv6Address = "X_IPv6Address",
	IPv6PrefixLength = "X_IPv6PrefixLength",
	IPv6DefaultGateway = "X_IPv6DefaultGateway",
	IPv6DNSServers = "X_IPv6DNSServers",
	IPv6PrefixList = "X_IPv6PrefixList",
	IPv6AddressingType = "X_IPv6AddressingType",
	ConnectionStatus = "ConnectionStatus",
	Uptime = "Uptime",
}

local errcode, values = dm.GetParameterValues(wan, maps)
if values ~= nil then
	local wanStatusObj = values[wan]
	wanStatusObj.X_IPv4Enable = utils.toboolean(wanStatusObj.X_IPv4Enable)
	wanStatusObj.X_IPv6Enable = utils.toboolean(wanStatusObj.X_IPv6Enable)
	wanStatusObj.ConnectionType = utils.get_ip_conn_type(wan, wanStatusObj.ConnectionType)
	utils.appendSingleObj(res, wanStatusObj, maps)
end

web.print(json.encode(res))
