
require('dm')
require('web')
require('json')
require('utils')
local print = print
local tostring = tostring

local errcode,bridges = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Bridge.{i}.", 
    {"BridgeKey", "X_Type", "BridgeName"});
local errcode,filters = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.Filter.{i}.", 
    {"FilterBridgeReference", "FilterInterface"});
local errcode,intfs = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.", 
    {"AvailableInterfaceKey", "InterfaceReference", "X_InterfaceAlias", "InterfaceType"});

local iptv = {}
iptv.Enable = false
local br_key, br_path = utils.get_iptv_bridge(bridges)
print(br_key, br_path)
if -1 == br_key then
	web.print(json.encode(iptv))
	return
end

local wan_intf = ""

for k,v in pairs(filters) do
	if tostring(v["FilterBridgeReference"]) == tostring(br_key) then
		local binded_intf = utils.get_intf_by_key(intfs, v["FilterInterface"])
		if binded_intf then
			if "LANInterface" ~= binded_intf["InterfaceType"] then
				wan_intf = binded_intf["InterfaceReference"]
			end
		end
	end
end

local maps = {
	sendbytes = "EthernetBytesSent",
	receivebytes = "EthernetBytesReceived",
	sendpacket = "EthernetPacketsSent",
	receivepacket = 'EthernetPacketsReceived',
	senderror = "EthernetErrorsSent",
	receiveerror = "EthernetErrorsReceived",
	senddiscard = "EthernetDiscardPacketsSent",
	receivediscard = "EthernetDiscardPacketsReceived",
}

local errcode, wanSt = dm.GetParameterValues(wan_intf .. ".Stats.", maps)

local obj = wanSt[wan_intf .. ".Stats."]
obj.Enable = true

maps.Enable = 'Enable'

utils.responseSingleObject(obj, maps)

