Atp.LoadHelper.appendLangRes("logcfg_res.js");
Atp.LoadHelper.appendJs("/js/log.js");

Atp.LoadHelper.loadAll();

Atp.LogContainerView = Atp.PageContainerView.extend ({
    prefixName: 'log',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.LogCfgView }} \
            {{ view Atp.LogInfoView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.LogContainerView, "log");