Atp.LoadHelper.appendLangRes("guest_network_res.js");
Atp.LoadHelper.appendLangRes("wizard_res.js");
Atp.LoadHelper.appendLangRes("wlan_res.js");
Atp.LoadHelper.appendJs("/js/guest_network.js");
Atp.LoadHelper.loadAll();

Atp.GuestNetworkContainerView = Atp.PageContainerView.extend ({
	prefixName: "gstntwk",

    init: function(){
        this._super();
        AtpValidator.registerCallback("validwlsharekey", callback_check_wlsharekey);
    },
	dataView: Em.View.extend ({
		template: Em.Handlebars.compile('\
			    {{view Atp.GuestNtwkViewCollapse}}')
	})
    
});

Atp.MenuController.createSubmenuView(Atp.GuestNetworkContainerView, "guest_network");