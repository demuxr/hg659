Atp.LoadHelper.appendLangRes("wlan_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/wlan_access.js");
Atp.LoadHelper.loadAll();

Atp.WlanAccessContainerView = Atp.PageContainerView.extend ({
	prefixName: "wa",

	pageload: function () {
		
	},

	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
			    {{view Atp.WpsViewCollapse}} \
			    {{view Atp.WlanMacFilterViewCollapse}} \
			    {{view Atp.LanDeviceWindowView id="wlanaccess_landevice_window"}} \
			')
	})
    
});

Atp.MenuController.createSubmenuView(Atp.WlanAccessContainerView, "wlan_access");