Atp.LoadHelper.appendLangRes('device_info_res.js');
Atp.LoadHelper.appendLangRes('wan_res.js');
Atp.LoadHelper.appendLangRes('wlan_res.js');
Atp.LoadHelper.appendLangRes('diagnose_overview_res.js');

Atp.LoadHelper.appendJs('/js/device_info.js');
Atp.LoadHelper.appendJs('/js/diagnose_wifi.js');
Atp.LoadHelper.appendJs('/js/access.js');

Atp.LoadHelper.loadAll();

Atp.DevInfoContainerView = Atp.PageContainerView.extend ({
    prefixName: 'deviceinfo',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.DevInfoView }} \
            {{ view Atp.WlanStatusCollapse }} \
            {{ view Atp.DslInfoView }} \
            {{ view Atp.EthWanInfoView }} \
            {{ view Atp.UmtsInfoView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.DevInfoContainerView, "device_info");