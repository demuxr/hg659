Atp.LoadHelper.appendLangRes("homenetwork_info_res.js");
Atp.LoadHelper.appendJs("/js/homenetwork_info.js");

Atp.LoadHelper.loadAll();

Atp.HomeNtwkContainer = Atp.PageContainerView.extend ({
    prefixName: 'homentwk_info',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.LanInfoView }} \
            {{ view Atp.WifiInfoStatusView }} \
            {{ view Atp.UmtsInfoSTView }} \
            {{ view Atp.WanInfoView }} \
            {{ view Atp.IptvInfoView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.HomeNtwkContainer, "statistics");