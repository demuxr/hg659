Atp.LoadHelper.appendLangRes('device_mngt_res.js');

utilLoadJavascript('/lib/jquery.form.min.js');
Atp.LoadHelper.appendJs('/js/device_mngt.js');

Atp.LoadHelper.loadAll();

Atp.DevMngtContainerView = Atp.PageContainerView.extend ({
    prefixName: 'dm',

    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.RebootView }} \
            {{ view Atp.RestoreView }} \
            {{#if Atp.UserLevelController.isAdminUser}} \
            {{ view Atp.UpgView }} \
            {{ view Atp.ConfigFileView }} \
            {{/if}} \
            {{ view Atp.ModalView controllerBinding="Atp.DeviceMngtModalController" }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.DevMngtContainerView, "device_mngt");