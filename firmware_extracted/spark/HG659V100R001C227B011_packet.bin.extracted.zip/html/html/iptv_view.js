Atp.LoadHelper.appendLangRes("wan_res.js");
Atp.LoadHelper.appendLangRes("homenetwork_info_res.js");
Atp.LoadHelper.appendJs("/js/link.js");
Atp.LoadHelper.appendJs("/js/wan.js");
Atp.LoadHelper.appendJs("/js/iptv.js");
Atp.LoadHelper.loadAll();

Atp.IptvContainerView = Atp.PageContainerView.extend ({
	titleId: "Menu.iptv",
	descriptionId: "iptv.description",

	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
		    {{view Atp.IptvView}} \
		    {{view Atp.IptvStatusView}} \
		')
	})
});

Atp.MenuController.createSubmenuView(Atp.IptvContainerView,"iptv");