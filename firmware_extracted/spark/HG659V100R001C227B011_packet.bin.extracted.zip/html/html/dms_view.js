Atp.LoadHelper.appendJs("/lib/base64.js", true);
Atp.LoadHelper.appendJs("/js/jquery.ztree.core-3.1.js", true);
Atp.LoadHelper.appendLangRes("dms_res.js", true);
Atp.LoadHelper.appendJs("/js/usbtree.js", true);
Atp.LoadHelper.appendJs("/js/dms.js", true);

Atp.LoadHelper.loadAll();


Atp.DmsContainerView = Atp.PageContainerView.extend ({
    prefixName: "dmspage",
    dataView: Em.View.extend({
        template: Em.Handlebars.compile('\
            {{ view Atp.DmsCollapse }} \
            <div id="dms_usb_diag" class="modal hide" style="z-index:3000"> \
                <div class="header height_25 modaltitlebackcolor" align="right"> \
                    <a class="pull-right fontweight_thick marginright_10 accordion-toggle close_detail" data-dismiss="modal" aria-hidden="true" {{action "cancelDir" target="Atp.DmsController"}}>X</a>\
                </div> \
                <div class="modal-header"> \
                    <div class="pull-left dev-usb ie6image"></div><span class="paddingleft_15 paddingtop_5 fontweight_thick">{{t dms.modalhead }}</span>\
                    <div class="third_menu_below_config_font">{{t dms.modalhead.info}}</div>\
                </div>\
                <div class="modal-body">\
                    <div class="zTreeDemoBackground left">\
                        {{ view Atp.DupDirTipView }}\
                        <ul id="dmstree" class="ztree"></ul>\
                    </div>\
                </div>\
                <div class="modal-footer">\
                    <button class="atp_button width_120" id="dms_shareId" {{action "changeDir" target="Atp.DmsController"}}>{{t dms.modalshare }}</button>\
                    <button class="atp_button width_120" id="dms_cancelId" data-dismiss="modal" {{action "cancelDir" target="Atp.DmsController"}}>{{t Menu.Cancel }}</button>\
                </div>\
            </div>')
    })
});

Atp.MenuController.createSubmenuView(Atp.DmsContainerView, "dlna_sharing");