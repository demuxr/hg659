
--lua_content_for__ include begin
 web.print('\
');  html.lang('wizard_res.js')  web.print('\
');  html.lang('wlan_res.js')  web.print('\
');  html.lang('user_login_res.js')  web.print('\
');  html.script('/js/wlan.js')  web.print('\
');  html.script('/js/wizard.js')  web.print('\
'); 
--lua_content_end__
 web.print('\
\
'); 
--lua_content_for__ script_tag begin
 web.print('\
<script language="JavaScript" type="text/javascript">\
function pageload(controller) {\
    if (controller) {\
        controller.load(controller.loadFinished);\
        return;\
    }\
    pageload(Atp.WlanObjs);\
}\
function DisplayImage(){\
    $("#ic_internet").addClass("ic_internet");\
    $("#ic_wifi").addClass("ic_wifi");\
    $("#ic_network").addClass("ic_network");\
}\
$(document).ready(function(){\
    pageload();\
    Atp.LoginInternetController.load();\
    Atp.WizardWifiController.load();\
    Atp.IndexLanDeviceCountController.load();\
    $("#to_wizard_wifi_page").live("click", function(){\
        window.location.href = "./wifi.html";\
        return false;\
    });\
    $("#ic_internet").live("click",function(){\
        window.location.href = "./internet.html";\
        return false;\
    });\
    $("#ic_network").live("click",function(){\
        window.location.href = "./network.html";\
        return false;\
    });\
    setTimeout(DisplayImage,350);\
});\
</script>\
'); 
--lua_content_end__
 web.print('\
<div class="paddingleft_33 fontsize_20 fontweight_thick paddingtop_10">\
    <font color="#2A5081">{{t home.title}}</font>\
</div>\
<div class="row margintop_10 paddingbottom_20">\
    <div class="wizard_part pull-left">\
        <div class="ie6image" id="ic_internet">\
            <div class="paddingleft_35 ic_internet_title">\
                {{t home.internet.title}}\
            </div>\
            <div class="internet_status">\
                {{view Atp.WizardInternetStatustime id="internet_wizard_id"}}\
            </div>\
        </div>\
    </div>\
    <div class="wizard_part pull-left" id="to_wizard_wifi_page">\
        <div class="ie6image" id="ic_wifi">\
            <div  class="paddingleft_35 ic_wifi_title">\
                {{t home.wifi.title }}\
            </div>\
            <div  class="wifi_user_status text_center">\
                <div class="paddingleft_10">\
                    {{view Atp.WizardOFFOrUserCount id="wifi_wizard_id"}}\
                </div>\
            </div>\
        </div>\
    </div>\
    <div class="wizard_part pull-left">\
        <div class="ie6image" id="ic_network">\
            <div  class="paddingleft_35 ic_network_title">\
                {{t home.network.title }}\
            </div>\
            <div class="network_connect_status">\
                <div class="text_center">\
                    {{view Atp.ActiveDeviceCount id="network_wizard_id"}}\
                </div>\
            </div>\
        </div>\
    </div>\
</div>\
'); 