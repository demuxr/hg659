Atp.LoadHelper.appendLangRes("route_res.js");
Atp.LoadHelper.appendJs("/js/route.js");
Atp.LoadHelper.appendJs("/js/rip.js");
Atp.LoadHelper.loadAll();

Atp.RouteContainerView = Atp.PageContainerView.extend ({
	prefixName: "route",

	dataView: Em.View.extend({
		template: Em.Handlebars.compile('\
			{{#if Atp.UserLevelController.isAdminUser}} \
			{{ view Atp.StaticRouteCollapse }} \
			{{ view Atp.RipCollapse }} \
			{{/if}} \
		')
	})
    
});

Atp.MenuController.createSubmenuView(Atp.RouteContainerView,'route');