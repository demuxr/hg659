local GetParamValues = dm.GetParameterValues
local SetDBParamValues = mic.setdbparavalues
local SetConfigTool  = mic.setconfigtool
local GetConfigTool  = mic.getconfigtool
local DBRestore      = mic.dbrestore
local DBSave         = mic.dbsave
local ChangeDest     = mic.changemsgdest
local GetValues      = mic.bahlgetvalues
local Detect         = mic.detectequipment
local DecodeFactoryCfg = mic.decodefactorycfg
local DBInit = mic.redbinit
local UpgradeReserve = mic.upgreserve
local FreeObjlist = mic.freeobjlist
local print          = print


-- define recover single objs
local recoverObjs = {
	'InternetGatewayDevice.X_SyslogConfig.',
	'InternetGatewayDevice.IPPingDiagnostics.',
	'InternetGatewayDevice.TraceRouteDiagnostics.',
	'InternetGatewayDevice.UserInterface.X_Web.UserInfo.UserInfoInstance.2.',
	'InternetGatewayDevice.Services.X_DmsService.',
	'InternetGatewayDevice.Services.X_UPnP.',
	'InternetGatewayDevice.Services.StorageService.StorageServiceInstance.1.',
	'InternetGatewayDevice.LANDevice.LANDeviceInstance.1.',
	'InternetGatewayDevice.Layer2Bridging.Bridge.BridgeInstance.1.',
	'InternetGatewayDevice.X_WiFi.Radio.',
	'InternetGatewayDevice.X_FireWall.',
	'InternetGatewayDevice.DosAttack.',	
	'InternetGatewayDevice.X_IPTunnel.',
	'InternetGatewayDevice.X_VPN.',	
	'InternetGatewayDevice.ACL.',
	'InternetGatewayDevice.Services.X_LanDomainManage.',
	'InternetGatewayDevice.Services.X_DMZ.',
	'InternetGatewayDevice.Services.X_Application.',
	'InternetGatewayDevice.Services.X_DDNSConfiguration.',
	'InternetGatewayDevice.Services.X_Portmapping.',
	'InternetGatewayDevice.Services.X_Porttrigger.',
	'InternetGatewayDevice.Services.X_ALGAbility.',
	'InternetGatewayDevice.Services.VoiceService.VoiceServiceInstance.1.X_CommonConfig.RouteprefixInfo.',
	'InternetGatewayDevice.Services.VoiceService.VoiceServiceInstance.1.X_CommonConfig.Button.'
}


--print("-----------------------------restore factory values form lua script.")
ChangeDest('cms')
SetConfigTool('cms')

--print("---------------------------------------------reverse obj.")
DecodeFactoryCfg()
UpgradeReserve(recoverObjs)

--print("---------------------------------------------DBSave---------------------.")
DBSave()

FreeObjlist()

--print("---------------------------------------------Part Restore.")
DBInit()

--print("---------------------------------------------Detect.")
Detect()





