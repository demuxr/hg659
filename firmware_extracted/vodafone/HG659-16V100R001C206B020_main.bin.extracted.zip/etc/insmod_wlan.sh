# /etc/profile: system-wide .profile file for the Bourne shells

PATH=/bin:/sbin:/usr/bin
export PATH
echo "INSMOD wlan START......"

	test -e /lib/extra/wl.ko && insmod /lib/extra/wl.ko
	test -e /lib/kernel/drivers/net/wl/wl.ko && insmod /lib/kernel/drivers/net/wl/wl.ko

echo "INSMOD wlan Done"


