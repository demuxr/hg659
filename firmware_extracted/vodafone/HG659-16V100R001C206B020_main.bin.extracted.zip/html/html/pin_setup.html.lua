
--lua_content_for__ include begin
 web.print('\r\
');  html.lang('pin_res.js')  web.print('\r\
');  html.script('../js/pin.js')  web.print('\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
'); 
--lua_content_for__ script_tag begin
 web.print('\r\
<script language="JavaScript" type="text/javascript">\r\
\r\
$(document).ready(function() {\r\
    AtpValidator.registerCallback("pwdMatch", callback_verify_pin);\r\
    pageload();\r\
});\r\
</script>\r\
\r\
'); 
--lua_content_end__
 web.print('\r\
\r\
<div class="well setconfig_height well_reset">\r\
    {{view Atp.PageHelpView label="pin.title" body="pin.pin_help"}}\r\
    <div class="form-horizontal paddingleft_editview">\r\
        {{view Atp.PinView}}\r\
    </div>\r\
    <div class="form-horizontal paddingleft_editview">\r\
        {{view Atp.WanbackupView}}\r\
    </div>\r\
</div>\r\
\r\
'); 