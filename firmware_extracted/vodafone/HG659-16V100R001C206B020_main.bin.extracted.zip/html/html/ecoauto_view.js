Atp.LoadHelper.appendLangRes("ecoauto_res.js");
Atp.LoadHelper.appendJs("/js/ecoauto.js");

Atp.LoadHelper.loadAll();

Atp.EcoAutoContainerView = Atp.PageContainerView.extend ({
    prefixName: 'ecoauto',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{view Atp.EcoAutoView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.EcoAutoContainerView, "ecoauto");