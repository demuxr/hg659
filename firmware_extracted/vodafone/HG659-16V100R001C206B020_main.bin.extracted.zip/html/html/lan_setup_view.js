Atp.LoadHelper.appendLangRes("lan_setup_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/lan_setup.js");
Atp.LoadHelper.appendJs("/js/wan.js");
Atp.LoadHelper.appendJs("/lib/base64.js");
Atp.LoadHelper.loadAll();

Atp.LanSetupContainerView = Atp.PageContainerView.extend({
    prefixName: "lan",

    init: function(){
        this._super();
        AtpValidator.registerCallback("Prefix", callback_check_prefix_value);
        AtpValidator.registerCallback("RAPrefix", callback_check_raprefix_value);
        AtpValidator.registerCallback("Dns", callback_check_dns_value);
    },

    dataView: Em.View.extend ({
        template: Em.Handlebars.compile('\
            {{view Atp.LanStatusCollapseView}} \
            {{view Atp.LanHostViewCollapse}} \
            {{view Atp.LanServerCollapseView}} \
            {{view Atp.IpAddressReserveCollapseView}} \
            {{view Atp.LanRadvdCollapseView}} \
            {{view Atp.LanDhcp6sCollapseView}} \
            {{view Atp.LanUpnpCollapseView}} \
            {{view Atp.ModalView controllerBinding="Atp.LanHostModalController" }}\
            {{view Atp.LanDeviceWindowView id="lansetup_landevice_window"}} ')
    })
});

Atp.MenuController.createSubmenuView(Atp.LanSetupContainerView, "lan");
