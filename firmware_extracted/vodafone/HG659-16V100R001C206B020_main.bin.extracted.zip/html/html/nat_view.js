Atp.LoadHelper.appendLangRes("nat_res.js");
Atp.LoadHelper.appendLangRes("alg_res.js");
Atp.LoadHelper.appendLangRes("application_res.js");
Atp.LoadHelper.appendLangRes("host_info_res.js");
Atp.LoadHelper.appendJs("/js/alg.js");
Atp.LoadHelper.appendJs("/js/host_info.js");
Atp.LoadHelper.appendJs("/js/landevices.js");
Atp.LoadHelper.appendJs("/js/nat.js");
Atp.LoadHelper.appendLangRes("application_res.js");
Atp.LoadHelper.appendJs("/js/application.js");
Atp.LoadHelper.loadAll();

Atp.NatContainerView = Atp.PageContainerView.extend ({
    prefixName: "nat",
    dataView: Em.View.extend({
        template: Em.Handlebars.compile('\
            {{view Atp.PortMapingCollapse}} \
            {{view Atp.PortTriggerCollapse}} \
            {{view Atp.AlgViewCollapse}} \
            {{view Atp.ApplicationWindowView type=1 elementId="portmapping_application_id"}} \
            {{view Atp.ApplicationWindowView type=2 elementId="porttrigger_application_id"}} \
            {{view Atp.LanDeviceWindowView id="nat_landevice_window"}} \
            ')
    })
});

Atp.MenuController.createSubmenuView(Atp.NatContainerView,"nat");
