require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.ManagementServer.",
    {
        "EnableCWMP",
        "URL",
        "Username",
        "Password",
        "PeriodicInformEnable",
        "PeriodicInformInterval",
        "ConnectionRequestUsername",
        "ConnectionRequestPassword",
        "X_ConnReqPort",
        "X_SSLCertEnable"
    }
);

local obj = values["InternetGatewayDevice.ManagementServer."]

local cwmpCfg = {}

cwmpCfg.enable = utils.toboolean(obj["EnableCWMP"])
cwmpCfg.acsurl = obj["URL"]
cwmpCfg.acsname = obj["Username"]
cwmpCfg.acspwd = utils.getdefaultPasswd(obj['Password'])
cwmpCfg.inform = utils.toboolean(obj["PeriodicInformEnable"])
cwmpCfg.interval = obj["PeriodicInformInterval"]
cwmpCfg.conname = obj["ConnectionRequestUsername"]
cwmpCfg.conpwd = utils.getdefaultPasswd(obj['ConnectionRequestPassword'])
cwmpCfg.conport = obj["X_ConnReqPort"]
cwmpCfg.cert = utils.toboolean(obj["X_SSLCertEnable"])

web.print(json.encode(cwmpCfg))