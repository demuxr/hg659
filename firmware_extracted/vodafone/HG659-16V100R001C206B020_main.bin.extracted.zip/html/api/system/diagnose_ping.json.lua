require('dm')
require('utils')

local maps = {
	DiagnosticsState="DiagnosticsState",
	NumberOfRepetitions = "NumberOfRepetitions",
	DataBlockSize = "DataBlockSize",
	SuccessCount = "SuccessCount",
	FailureCount = "FailureCount",
	AverageResponseTime = "AverageResponseTime",
	MinimumResponseTime = "MinimumResponseTime",
	MaximumResponseTime = "MaximumResponseTime",
	Host = "Host"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.IPPingDiagnostics.", maps)

local obj = values["InternetGatewayDevice.IPPingDiagnostics."]

utils.responseSingleObject(obj, maps)