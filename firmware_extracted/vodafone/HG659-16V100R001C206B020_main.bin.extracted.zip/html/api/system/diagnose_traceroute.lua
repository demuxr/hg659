local utils = require('utils')

local maps = {
	DiagnosticsState="DiagnosticsState",
	Interface = "Interface",
	Host="Host"
}

local	domain = "InternetGatewayDevice.TraceRouteDiagnostics."
data["Interface"] = ""
data["DiagnosticsState"] = "Requested"

local param = utils.GenSetObjParamInputs(domain, data, maps)

local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)