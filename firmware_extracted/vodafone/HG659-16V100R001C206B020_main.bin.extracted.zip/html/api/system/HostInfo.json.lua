
require('dm')
require('web')
require('json')
require('utils')

local sort, strlen = table.sort, string.len

-- get qos info ---------------------------------------------------------------------------------------------
local qosclasses = {}
local devType = nil
if FormData["devType"] ~= nil then
     devType = FormData["devType"]
end
local errcode,policerVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Policer.{i}.", 
    {"X_DownPeakRate"});

local array = {}
i = 1
for k,v in pairs(policerVals) do
    local p,e = utils.findLastPoint(k)
    array[i] = tonumber(p)
    i = i+1
end
table.sort(array)


function apendPolicerData(classval, policerIndex)
    local domain = 'InternetGatewayDevice.QueueManagement.Policer.'..array[policerIndex]..'.'
    for k,v in pairs(policerVals) do
        if k == domain then
            classval["DownPeakRate"] = v["X_DownPeakRate"]
            classval["PolicerID"] = k
            return
        end
    end
end

local errcode, classVals = dm.GetParameterValues("InternetGatewayDevice.QueueManagement.Classification.{i}.", 
    {"ClassificationEnable", "SourceMACAddress", "ClassPolicer",  "X_Type", "ClassQueue"});

for k,v in pairs(classVals) do
    if 2 == v["X_Type"] then
    local newClass = {}
        newClass["ID"] = k
        newClass["SourceMACAddress"] = v["SourceMACAddress"]
        newClass["Enable"] = utils.toboolean(v["ClassificationEnable"])
        newClass["ClassQueue"] = v["ClassQueue"]
        apendPolicerData(newClass, v["ClassPolicer"])
        table.insert(qosclasses, newClass)
    end
end

function set_qos_info(newobj, mac)
    for k, v in pairs(qosclasses) do
        if mac == v["SourceMACAddress"] then
            newobj["DeviceMaxDownLoadRate"] = v["DownPeakRate"]
            newobj["DeviceDownRateEnable"] = v["Enable"]
            newobj["QosclassID"] = v["ID"]
            newobj["PolicerID"] = v["PolicerID"]
            newobj["ClassQueue"] = v["ClassQueue"]
            return 
        end
    end
    
    newobj["DeviceMaxDownLoadRate"] = 0
    newobj["DeviceDownRateEnable"] = false
    newobj["QosclassID"] = ''
    newobj["PolicerID"] = ''
    newobj["ClassQueue"] = -1
end


-- get parent control info ----------------------------------------------------------------------------------
function parsemacs(srcmac)
    local start = 1
    local devices = {}
    while true do
        ip, fp = string.find(srcmac, "|", start)
        if not ip then
            local mac = {}
            mac["MACAddress"] = string.sub(srcmac, start)
            table.insert(devices, mac)
            break
        end
        local mac = {}
        mac["MACAddress"] = string.sub(srcmac, start, ip-1)
        table.insert(devices, mac)
        start = fp +1
    end

    return devices
end

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.TimeRule.{i}.", {"DevMac"});
local macfilter = {}

if objs ~= nil then
    for k,v in pairs(objs) do
        local newObj = {}
        newObj["ID"] = k
        newObj["Devices"] = parsemacs(v["DevMac"])
        table.insert(macfilter, newObj)
    end
end

function set_parentControl_info(newObj, mac)
    for k, v in pairs(macfilter) do
        for k1, v1 in pairs(v["Devices"]) do
            if v1["MACAddress"] == mac then
                newObj["MacFilterID"] = v["ID"]
                newObj["ParentControlEnable"] = true
                return
            end
        end
    end
    newObj["MacFilterID"] = ""
    newObj["ParentControlEnable"] = false

    return 
end
----------------------------------------------------------------------------------------------------------
function isWifiDev(iconType, interface)
    if 'smartphone' == iconType or 'pad' == iconType then
        return true
    end
    if nil ~= interface then
        if string.find(interface, "SSID") then
            return true
        end
    end
    return false
end
local isWifi = false
local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias"})

local lanarray = {}

for k, v in pairs(lanVals) do
    lanarray[v["InterfaceReference"]] = v["X_InterfaceAlias"]
end

local hosts = {}

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.", 
    {"X_DeviceName", "X_DeviceType", "HostName", "MACAddress", "IPAddress", "InterfaceType", "Active",
    "X_IPv6Active","X_IPv6Address",
    "Layer2Interface", "AddressSource", "LeaseTimeRemaining","VendorClassID"});

for k,v in pairs(objs) do
    local newObj = {}
        newObj["ID"] = k
        newObj["MACAddress"] = v["MACAddress"]
        newObj["IPAddress"] = v["IPAddress"]        
        newObj["Active"] = utils.toboolean(v["Active"])
        newObj["Active46"] = false
        if utils.toboolean(v["Active"]) then
            newObj["Active46"] = true
        end        
        newObj["IPv6Address"] = v["X_IPv6Address"]
        newObj["V6Active"] = utils.toboolean(v["X_IPv6Active"])     
        if utils.toboolean(v["X_IPv6Active"]) then
            newObj["Active46"] = true
        end
        newObj["IconType"] = v["X_DeviceType"]
        newObj["ActualName"] = v["X_DeviceName"]
        newObj["domain"] = v["Layer2Interface"]
        newObj["HostName"] = v["HostName"]
        newObj["Layer2Interface"] = lanarray[v["Layer2Interface"]]
        if "wifi" == devType then
            isWifi = isWifiDev(newObj["IconType"],newObj["Layer2Interface"])
        end
        newObj["AddressSource"] = v["AddressSource"]
        newObj["LeaseTime"] = v["LeaseTimeRemaining"]
        newObj["VendorClassID"] = v["VendorClassID"]
        local addr_err, addr_objs = dm.GetParameterValues(k.."X_IPv6Addresses.{i}.", {"X_IPv6Address"});
        local ipv6_addrs = {}
        if addr_objs ~= nil then
            for kk, vv in pairs(addr_objs) do
                local one_ipv6 = {}
                one_ipv6["Ipv6Addr"] = vv["X_IPv6Address"]
                if "wifi" == devType then
                    if isWifi then
                        table.insert(ipv6_addrs, one_ipv6)
                    end
                else
                    table.insert(ipv6_addrs, one_ipv6)
                end
            end
        end
        newObj["Ipv6Addrs"] = ipv6_addrs
        set_parentControl_info(newObj, v["MACAddress"])
        set_qos_info(newObj, v["MACAddress"])

        if "wifi" == devType then
            if isWifi then
                table.insert(hosts, newObj)
            end
        else
             table.insert(hosts, newObj)
        end
end

function compID(a, b)
    if strlen(a.ID) > strlen(b.ID) then
        return false
    elseif strlen(a.ID) < strlen(b.ID) then
        return true
    end

    if a.ID >= b.ID then
        return false
    else
        return true
    end
end

function comp(a, b)
    if a.Active46 == b.Active46 then
        return compID(a, b)
    end
    
    if a.Active46 == true and b.Active46 == false then
        return true
    end

    return false
end
sort(hosts, comp)
web.print(json.encode(hosts))
