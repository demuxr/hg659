print("...........excute selfdiagnose........")
require('dm')
require('web')
require('utils')
local string = string
local tostring = tostring

local fo = assert (io.open ("/var/selfdiagnose_report", "w"))

function getReport(data)
	for k, v in pairs(data) do
		fo:write(k .. ": " .. tostring(v) .. "\r\n")
	end
end

-- device 
local errcode,host = dm.GetParameterValues("InternetGatewayDevice.DeviceInfo.",
    {
        "ProductClass",
        "SerialNumber",
        "HardwareVersion",
        "SoftwareVersion",
        "ManufacturerOUI"
    }
);

local obj = host["InternetGatewayDevice.DeviceInfo."]

local Device = {}

Device.DeviceName = obj["ProductClass"]
Device.SerialNumber = obj["SerialNumber"]
Device.HardwareVersion = obj["HardwareVersion"]
Device.SoftwareVersion = obj["SoftwareVersion"]
Device.ManufacturerOUI = obj["ManufacturerOUI"]

local errcode,host = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.", {"MACAddress"})
local obj = host["InternetGatewayDevice.LANDevice.1.LANHostConfigManagement."]
Device.MacAddress = obj["MACAddress"]


web.exec("top -n 1 >/var/diagnose_top")
fh = io.open("/var/diagnose_top", "r")
line = fh.read(fh)
ip = string.find(line, "Mem:")
Device.Mem = string.sub(line, ip+5)

line = fh.read(fh)
ip = string.find(line, "CPU:")
Device.CPU = string.sub(line, ip+5)

io.close(fh)
web.exec("rm /var/diagnose_top")

getReport(Device)

--- lan info
fo:write("\r\nLAN info:\r\n")
local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias"})

local lanarray = {}

for k, v in pairs(lanVals) do
    lanarray[v["X_InterfaceAlias"]] = v["InterfaceReference"]
end


local laninfo = {}
for i=1,4 do
	local newObj = {}
	local errcode, values = dm.GetParameterValues(lanarray["LAN"..i]..".", 
		{"Enable", "Status", "Name", "MACAddress"})

	local obj = values[lanarray["LAN"..i].."."]
	
	newObj["Name"] = "LAN"..i
	newObj["Status"] = obj["Status"]
	newObj["Enable"] = obj["Enable"]
	newObj["IPAddress"] = "N/A"
	newObj["HostName"] = "N/A"
	if newObj["Status"] ~= "Up" then
		newObj["Auto-negotiation"] = "N/A"
		newObj["Duplexmode"] = "N/A"
		newObj["Rate"] = "N/A"
	else
		newObj["Auto-negotiation"], newObj["Duplexmode"], newObj["Rate"] =	utils.getEthPortStatus(i-1)
	end

	local fp = string.find(lanarray["LAN"..i], 'LANEthernetInterfaceConfig')
	local brdomain = string.sub(lanarray["LAN"..i], 1, fp-1)..'LANHostConfigManagement.IPInterface.1.'
	local errcode, values = dm.GetParameterValues(brdomain,
			{'IPInterfaceIPAddress'})
	if values then
		local obj = values[brdomain]
		newObj["IPAddress"] = obj['IPInterfaceIPAddress']
	else
		newObj["IPAddress"] = ""
	end

	getReport(newObj)
	fo:write("\r\n")
end


-- internet 
fo:write("\r\nInternet info:\r\n")
local GetParameterValues, appendSingleObj, toboolean  = dm.GetParameterValues, utils.appendSingleObj, utils.toboolean
local strsub, strlen, find = string.sub, string.len, string.find

local defaultwan = ""
local has_internet = true

if defaultwan == "" then
	defaultwan, has_internet = utils.getDefaultWan()
	defaultwan = strsub(defaultwan, 1, strlen(defaultwan)-1)
end

local obj = web.gmsgget('wan', 3, {Path=defaultwan})

utils.parse_wan_status(obj.StatusCode, obj)



local ip = find(defaultwan, "WANConnectionDevice")
local linkLayer = ""
if nil ~= ip then
	linkLayer = strsub(defaultwan, 1, ip-1)
end
maps = {
	WANAccessType = "WANAccessType",
	UpMaxBitRate = "Layer1UpstreamMaxBitRate",
	DownMaxBitRate = "Layer1DownstreamMaxBitRate"
}

local errcode,values = GetParameterValues(linkLayer.."WANCommonInterfaceConfig.", maps)
if values ~= nil then
	local linklayerObj = values[linkLayer.."WANCommonInterfaceConfig."]

	linklayerObj.Layer1UpstreamMaxBitRate   = linklayerObj.Layer1UpstreamMaxBitRate/1000000
	linklayerObj.Layer1DownstreamMaxBitRate = linklayerObj.Layer1DownstreamMaxBitRate/1000000

	appendSingleObj(obj, linklayerObj, maps)

	if linklayerObj["WANAccessType"] == 'Ethernet' then
		local errcode, values = GetParameterValues(linkLayer.."WANEthernetInterfaceConfig.", 
			{"MaxBitRate", "DuplexMode", "Status"})
		local ethObj = values[linkLayer.."WANEthernetInterfaceConfig."]
		obj.MaxBitRate = ethObj["MaxBitRate"]
		obj.DuplexMode = ethObj["DuplexMode"]
		obj.LinkStatus = ethObj["Status"]
		obj.UpMaxBitRate = ethObj["MaxBitRate"]
		obj.DownMaxBitRate = ethObj["MaxBitRate"]
	elseif linklayerObj["WANAccessType"] == 'DSL' then
		local errcode, values = GetParameterValues(linkLayer.."WANDSLInterfaceConfig.", 
			{"ModulationType", "Status", "UpstreamCurrRate", "DownstreamCurrRate"})
		if values ~= nil then
			local dslObj = values[linkLayer.."WANDSLInterfaceConfig."]
			obj.ModulationType = dslObj["ModulationType"]
			obj.LinkStatus = dslObj["Status"]
			obj.UpMaxBitRate = dslObj["UpstreamCurrRate"]/1000
			obj.DownMaxBitRate = dslObj["DownstreamCurrRate"]/1000
		end
	elseif linklayerObj["WANAccessType"] == 'VDSL' then
		local errcode, values = GetParameterValues(linkLayer.."WANDSLInterfaceConfig.", 
			{"ModulationType", "Status", "UpstreamCurrRate", "DownstreamCurrRate"})
		if values ~= nil then
			local dslObj = values[linkLayer.."WANDSLInterfaceConfig."]
			obj.ModulationType = dslObj["ModulationType"]
			obj.LinkStatus = dslObj["Status"]
			obj.UpMaxBitRate = dslObj["UpstreamCurrRate"]/1000
			obj.DownMaxBitRate = dslObj["DownstreamCurrRate"]/1000
		end
	end
end

local maps = {
	DefaultGateway="DefaultGateway",
	DNSServers = "DNSServers",
	ExternalIPAddress = "ExternalIPAddress",
	X_IPv4Enable = "X_IPv4Enable",
	X_IPv6Enable = "X_IPv6Enable",
	X_IPv6ConnectionStatus = "X_IPv6ConnectionStatus",
	X_IPv6Address = "X_IPv6Address",
	X_IPv6PrefixLength = "X_IPv6PrefixLength",
	X_IPv6DefaultGateway = "X_IPv6DefaultGateway",
	X_IPv6DNSServers = "X_IPv6DNSServers",
	X_IPv6PrefixList = "X_IPv6PrefixList",
	X_IPv6AddressingType = "X_IPv6AddressingType",
	ConnectionStatus = "ConnectionStatus",
	Uptime = "Uptime",
	MACAddress = "MACAddress"
}

local errcode, values = GetParameterValues(defaultwan..'.', maps)

if values ~= nil then
	local wanStatusObj = values[defaultwan.."."]
	wanStatusObj.X_IPv4Enable = toboolean(wanStatusObj.X_IPv4Enable)
	wanStatusObj.X_IPv6Enable = toboolean(wanStatusObj.X_IPv6Enable)
	wanStatusObj.MACAddress = wanStatusObj.MACAddress
	appendSingleObj(obj, wanStatusObj, maps)
end
obj.HasInternetWan = has_internet

getReport(obj)

--wifi
local tonumber = tonumber
local  print = print

local ApNums = 0
local ApNums_30 = 0
local ApNums_50 = 0

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand"
    }
);

function get_WifiEnable(frequency, ssidEnble)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return utils.toboolean(v["Enable"]) and ssidEnble
        end
    end

    return false
end

function getWifiInstance(instance)
	local maps = {
		Channel = "Channel",
		AutoChannelEnable = "AutoChannelEnable",
		Enable = "Enable",
		X_OperatingFrequencyBand = "X_OperatingFrequencyBand",
		SSID = "SSID",
	    BSSID = "BSSID",
		TransmitPower = "TransmitPower",
		BeaconType = "BeaconType",
		BasicEncryptionModes = "BasicEncryptionModes",
	    BasicAuthenticationMode = "BasicAuthenticationMode",
	    WEPEncryptionLevel = "WEPEncryptionLevel",
	    WEPKeyIndex = "WEPKeyIndex",
	    WPAEncryptionModes = "WPAEncryptionModes",
	    IEEE11iEncryptionModes = "IEEE11iEncryptionModes",
	    X_MixedEncryptionModes = "X_MixedEncryptionModes",
	    X_Wlan11NBWControl = 'X_Wlan11NBWControl',
	    X_WlanStandard = 'X_WlanStandard',
	    MaxBitRate = "MaxBitRate",
	    RegulatoryDomain = "RegulatoryDomain"
	}

	local domain = "InternetGatewayDevice.LANDevice.1.WLANConfiguration."..instance.."."
	local errcode, wlanVals = dm.GetParameterValues(domain, maps)
		
	wlanObj = wlanVals[domain]

	if "Basic" == wlanObj["BeaconType"] and "None" == wlanObj["BasicEncryptionModes"] then
	    wlanObj.BeaconType = "None"
	end
	if wlanObj["X_WlanStandard"] == "b/g/n" or wlanObj["X_WlanStandard"] == "a/n/ac" then
		wlanObj["Bandwidth"] = wlanObj["X_Wlan11NBWControl"]
	else
		wlanObj["Bandwidth"] = wlanObj["MaxBitRate"]
	end

	wlanObj.Enable = get_WifiEnable(wlanObj.X_OperatingFrequencyBand, wlanObj.Enable)
	wlanObj.AutoChannelEnable = utils.toboolean(wlanObj.AutoChannelEnable)

	local errcode, lanVals = dm.GetParameterValues(domain.."X_WLANDiagnostic.APList.{i}.",
	    {"Signal"})
	if lanVals ~= nil then
	    for k, v in pairs(lanVals) do
	    	ApNums = ApNums + 1
	    	if v["Signal"] <= 30 then
	    		ApNums_30 = ApNums_30 + 1
	    	elseif v["Signal"] <= 50 then
	    		ApNums_50 = ApNums_50 + 1
	    	end
	    end
	end

	wlanObj['ApNums'] = ApNums

	if ApNums_30 >= 5 then
		wlanObj["Signal"] = 0
	elseif ApNums_30 + ApNums_50 >= 5 then
		wlanObj["Signal"] = 1
	else
		wlanObj["Signal"] = 2
	end
	return wlanObj
end

fo:write("\r\nWLAN 2.4G info:\r\n")
getReport(getWifiInstance(1))

fo:write("\r\nWLAN 5G info:\r\n")
getReport(getWifiInstance(2))

-- STA
local maps = {
	MACAddress = "MACAddress",
	PhyMode = "PhyMode",
	CodeType = "CodeType",
	BW = "BW",
	Rate = "Rate",
	RSSI = "RSSI",
	SNR = "SNR",
	CHT = "CHT",
	TxSuccPkt = "TxSuccPkt",
	ReTxPkt = "ReTxPkt",
	TxFailPkt = "TxFailPkt",
	RxSuccPkt = "RxSuccPkt",
	RxFailPkt = "RxFailPkt"
}

fo:write("\r\nSTA info:\r\n")
local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.WLANConfiguration.{i}.X_WLANDiagnostic.STAList.{i}.",
    maps)
local staNum = 0
for k, v in pairs(lanVals) do
	staNum = staNum +1
	getReport(v)
	fo:write("\r\n")
end
if staNum == 0 then
	fo:write("No STA\r\n")
end

-- USB
local usb = {}

local maps = {
    Name  = "Name",
    Model = "ConnectionType",
    Capacity = "Capacity"
}

local errcode,usbPhysicalStorage = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.{i}.PhysicalMedium.{i}.", maps);

if usbPhysicalStorage ~= nil then
    for k, v in pairs(usbPhysicalStorage) do
        table.insert(usb, v)
    end
end

for k, v in pairs(usb) do
    v.DeviceType = 'Storage'
end

local maps = {
    Name="Name"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_Printer.", maps)
if values ~= nil then
    local obj = values["InternetGatewayDevice.Services.X_Printer."]
    local printer = {}
    if obj["Name"] ~= 'Unknown' then
        printer.Name = obj["Name"]
        printer.DeviceType = "Printer"
        table.insert(usb, printer)
    end
end

web.exec("cat /proc/proc_user_umts >/var/diagnose_umts")
fh = io.open("/var/diagnose_umts", "r")
line = fh:read("*a")
fh:close()
web.exec("rm /var/diagnose_umts")
ip = string.find(line, "modem")
if ip ~= nil then
    -- has datacard
    web.exec("atcmd ati display >/var/diagnose_umts")
    fh = io.open("/var/diagnose_umts", "r")
    line = fh:read("*a")
    fh:close()
    web.exec("rm /var/diagnose_umts")
    ip = string.find(line, "Model:")
    ep = string.find(line, "Revision:")

    local datacard = {}
    datacard.Name = string.sub(line, ip+string.len("Model:"), ep-1)
    datacard.DeviceType = "Datacard"
    table.insert(usb, datacard)
end

fo:write("\r\nUSB info:\r\n")
local usbNum = 0
for k, v in pairs(usb) do
	usbNum = usbNum +1
	getReport(v)
	fo:write("\r\n")
end
if usbNum == 0 then
	fo:write("No Devices\r\n")
end

fo:close()