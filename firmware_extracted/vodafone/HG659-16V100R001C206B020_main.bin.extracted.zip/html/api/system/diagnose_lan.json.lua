require('dm')
require('utils')

local errcode, lanVals = dm.GetParameterValues("InternetGatewayDevice.Layer2Bridging.AvailableInterface.{i}.",
    {"InterfaceReference", "X_InterfaceAlias"})

local lanarray = {}

for k, v in pairs(lanVals) do
    lanarray[v["X_InterfaceAlias"]] = v["InterfaceReference"]
end

local errcode, hosts = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.", 
    {"X_DeviceName", "X_DeviceType", "HostName", "MACAddress", "IPAddress", "InterfaceType", "Active", "Layer2Interface"});


local laninfo = {}
for i=1,4 do
	local newObj = {}
	local errcode, values = dm.GetParameterValues(lanarray["LAN"..i]..".", 
		{"Enable", "Status", "Name", "MACAddress"})

	local obj = values[lanarray["LAN"..i].."."]
	
	newObj["Name"] = "LAN"..i
	newObj["Status"] = obj["Status"]
	newObj["Enable"] = obj["Enable"]
	newObj["IPAddress"] = "N/A"
	newObj["HostName"] = "N/A"
	if newObj["Status"] ~= "Up" then
		newObj["Auto-negotiation"] = "N/A"
		newObj["Duplexmode"] = "N/A"
		newObj["Rate"] = "N/A"
	else
		newObj["Auto-negotiation"], newObj["Duplexmode"], newObj["Rate"] =	utils.getEthPortStatus(i-1)
	end

    newObj["Hosts"] = {}
	for k, v in pairs(hosts) do
		if v["Layer2Interface"] == lanarray["LAN"..i] then
			table.insert(newObj["Hosts"], v)
			newObj["IPAddress"] = v['IPAddress']
			newObj["HostName"] = v['HostName']
		end		
	end

	local errcode, values = dm.GetParameterValues(lanarray["LAN"..i]..".Stats.", {"BytesReceived", "PacketsReceived", 
			"X_PacketsReceivedError", "X_PacketsReceivedDrops", "BytesSent", "PacketsSent",
			"X_PacketsSentError", "X_PacketsSentDrops"})

	local obj = values[lanarray["LAN"..i]..".Stats."]
	newObj["BytesReceived"] = obj["BytesReceived"]
	newObj["PacketsReceived"] = obj["PacketsReceived"]
	newObj["PacketsReceivedError"] = obj["X_PacketsReceivedError"]
	newObj["PacketsReceivedDrops"] = obj["X_PacketsReceivedDrops"]
	newObj["BytesSent"] = obj["BytesSent"]
	newObj["PacketsSent"] = obj["PacketsSent"]
	newObj["PacketsSentError"] = obj["X_PacketsSentError"]
	newObj["PacketsSentDrops"] = obj["X_PacketsSentDrops"]

	local fp = string.find(lanarray["LAN"..i], 'LANEthernetInterfaceConfig')
	local brdomain = string.sub(lanarray["LAN"..i], 1, fp-1)..'LANHostConfigManagement.IPInterface.1.'
	local errcode, values = dm.GetParameterValues(brdomain,
			{'IPInterfaceIPAddress'})
	if values then
		local obj = values[brdomain]
		newObj["IPAddress"] = obj['IPInterfaceIPAddress']
	else
		newObj["IPAddress"] = ""
	end
	

	laninfo[i] = newObj
end

web.print(json.encode(laninfo))
