local utils = require('utils')

local domain = "InternetGatewayDevice.X_ButtonDiagnostics."

local maps = {
		DiagnoseAction="DiagnosticsState",
	}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)