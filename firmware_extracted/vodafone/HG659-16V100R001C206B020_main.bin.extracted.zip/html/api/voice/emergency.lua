require('web')
require('dm')
local utils = require('utils')

local voip_emergency_maps = {
    EmergencyNumber="PrefixRange",
    EmergencyDescription="Description"
}

function setOutgoingline()
	if data["OutgoingLine"] == "CS" then
		err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsNumber"})
		if values ~= nil then
			local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
			data["OutgoingLine"] = obj["X_UmtsNumber"]
		end
	end
	local err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.X_EmergencyRouteAccount", data["OutgoingLine"])
    print("set OutgoingLine..")
    return err
end

function create_emergencyinfo()
    if data["ID"] == "" then
    	--setOutgoingline()
		local adding_emergency_paras = utils.GenAddObjParamInputs(data, voip_emergency_maps)
		local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.EmergencyInfo.", adding_emergency_paras)
		if err ~= 0 then
			utils.responseErrorcode(err, errs, voip_emergency_maps)
		else
			utils.appenderror("errcode", 0)
		end
	end
end

function update_emergencyinfo()
		print("ID "..data["ID"])
		--setOutgoingline()
		if data["ID"] == "" then
            local adding_emergency_paras = utils.GenAddObjParamInputs(emergencydata, voip_emergency_maps)
			local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.EmergencyInfo.", adding_emergency_paras)
			if err ~= 0 then
				utils.responseErrorcode(err, errs, voip_emergency_maps)
			end
		else
			local setting_paras = {}
			utils.GenSetObjParamInputsEx(data["ID"], data, voip_emergency_maps, setting_paras)
			local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)
			 utils.responseErrorcode(err, paramerror, voip_emergency_maps)
		end
	--end
end

function delete_emergencyinfo()
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 300)
    end
end

if action == "create" then
        create_emergencyinfo()
elseif action == "update" then
    update_emergencyinfo()
elseif action == "delete" then
    delete_emergencyinfo()
else
    utils.appenderror("errcode", 400)
end