require('dm')
require('web')
require('json')
local tapi = {}

local err, NumPlanvalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.", {"InterDigitTimerShort", "InterDigitTimerLong", "StartDigitTimerStd"})
	local  NumPlan_obj = NumPlanvalues["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan."]
	tapi.DialingDuration = NumPlan_obj["StartDigitTimerStd"]
	tapi.Shorttimeout = NumPlan_obj["InterDigitTimerShort"]
	tapi.Longtimeout = NumPlan_obj["InterDigitTimerLong"]


local err, Commonvalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", {"MinHookFlash", "MaxHookFlash", "TransmitGain", "ReceiveGain", "X_HookFlashCustomize"})
	local  Common_obj = Commonvalues["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig."]
	tapi.TransGain = Common_obj["TransmitGain"]
	tapi.RecepGain = Common_obj["ReceiveGain"]
	tapi.FlashMinTime = Common_obj["MinHookFlash"]
	tapi.FlashMaxTime  = Common_obj["MaxHookFlash"]
	tapi.HookFlashCustomize = utils.toboolean(Common_obj["X_HookFlashCustomize"])

web.print(json.encode(tapi))
