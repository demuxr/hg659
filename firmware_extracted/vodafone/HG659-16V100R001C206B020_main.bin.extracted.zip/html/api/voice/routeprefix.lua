require('web')
require('dm')
local utils = require('utils')
local bCS = 0
local voip_routeprefix_maps = {
	Prefix="PrefixRange",
	PrefixNumber="Account",
	PrefixDescription="Description"
}

function create_routeprefix()
         data["Prefix"] = "##"..data["Prefix"]
        if data["ID"] == "" then
		local adding_routeprefix_paras = utils.GenAddObjParamInputs(data, voip_routeprefix_maps)
		local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.RouteprefixInfo.", adding_routeprefix_paras)
		if err ~= 0 then
			utils.responseErrorcode(err, errs, voip_routeprefix_maps)
		else
			if bCS == 1 then
				err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.RouteprefixInfo."..inst_id..".OutgoingRoute", "2")
			else
				err = dm.SetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.RouteprefixInfo."..inst_id..".OutgoingRoute", "1")
			end
			utils.appenderror("errcode", err)
		end
	end
end

function update_routeprefix()
	data["Prefix"] = "##"..data["Prefix"]
	if data["ID"] == "" then
		local adding_routeprefix_paras = utils.GenAddObjParamInputs(data, voip_routeprefix_maps)
		local err,inst_id,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.RouteprefixInfo.", adding_routeprefix_paras)
		if err ~= 0 then
			utils.responseErrorcode(err, errs, voip_routeprefix_maps)
		end
	else
		local setting_paras = {}
		utils.GenSetObjParamInputsEx(data["ID"], data, voip_routeprefix_maps, setting_paras)
		local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)
		if err == 0 then
			if bCS == 1 then
				err = dm.SetParameterValues(data["ID"].."OutgoingRoute", "2")
			else
				err = dm.SetParameterValues(data["ID"].."OutgoingRoute", "1")
			end
			utils.appenderror("errcode", err)
		else
			utils.responseErrorcode(err, paramerror, voip_routeprefix_maps)
		end
	end
end

function delete_routeprefix()
    if data["ID"] ~= "" then
        err = dm.DeleteObject(data["ID"])
        utils.appenderror("errcode", err)
    else
        utils.appenderror("errcode", 300)
    end
end

if data["PrefixNumber"] ~= nil and data["PrefixNumber"] == "CS" then
	bCS = 1
	err, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.", {"X_UmtsNumber"})
	if values ~= nil then
		local obj = values["InternetGatewayDevice.Services.VoiceService.1."]
		data["PrefixNumber"] = obj["X_UmtsNumber"]		
	end
end 

if data["Prefix"] ~= nil and data["Prefix"] == "" then
	utils.appenderror("Prefix", "dialplan.prefixerr1")
	utils.appenderror("errcode", 9003)
	return
end

if action == "create" then
        create_routeprefix()
elseif action == "update" then
    update_routeprefix()
elseif action == "delete" then
    delete_routeprefix()
else
    utils.appenderror("errcode", 400)
end