require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring

local errcode, values = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.",
    {
        "X_UmtsEnable",
        "X_UmtsNumber",
        "X_CsStatus"
    }
);

local cs_obj = values["InternetGatewayDevice.Services.VoiceService.1."]

local csinfo = {}
if cs_obj["X_UmtsEnable"] == 1 then
	csinfo.SipNumber = "CS"
	csinfo.LineStatus = cs_obj["X_UmtsEnable"]
	csinfo.CallStatus = cs_obj["X_CsStatus"]
end

web.print(json.encode(csinfo))
