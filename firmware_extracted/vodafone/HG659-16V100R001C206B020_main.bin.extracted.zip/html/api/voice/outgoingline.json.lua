local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues

local outgoingline = {}
local obj
local errcode,outgoingaccount = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan.",{"X_EmergencyRouteAccount", "X_EmergencyRoute"});
if outgoingaccount ~=nil then
	obj = outgoingaccount["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.NumberingPlan."]
end

if obj ~= nil then
	if obj["X_EmergencyRoute"] == 2 then
		outgoingline.OutgoingLine = "CS"
	else
		outgoingline.OutgoingLine = obj["X_EmergencyRouteAccount"]
	end
end
web.print(json.encode(outgoingline))