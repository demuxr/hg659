require('web')
require('dm')
local utils = require('utils')

local voip_digitmap_maps = {
	DigitMap="DigitMap"
}

function update_digitmapinfo()
	local setting_paras = {}
	utils.GenSetObjParamInputsEx("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", data, voip_digitmap_maps, setting_paras)
	local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)
	utils.responseErrorcode(err, paramerror, voip_digitmap_maps)
end

--if action == "update" then
print("update_digitmapinfo")
    update_digitmapinfo()
--else
    --utils.appenderror("errcode", 400)
--end