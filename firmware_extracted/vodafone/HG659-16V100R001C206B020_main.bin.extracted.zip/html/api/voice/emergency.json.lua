local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues

local emergencydata = {}
local errcode,emergencyaccount = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.EmergencyInfo.{i}.",{"PrefixRange","Description"});
if emergencyaccount ~= nil then
	for k,v in pairs(emergencyaccount) do
		local emergency = {}
		emergency["ID"] = k
		emergency["EmergencyNumber"] = v["PrefixRange"]
		emergency["EmergencyDescription"] = v["Description"]
		table.insert(emergencydata,emergency)
	end
end

web.print(json.encode(emergencydata))