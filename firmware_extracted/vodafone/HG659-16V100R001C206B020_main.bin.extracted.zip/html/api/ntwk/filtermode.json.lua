
require('dm')
require('web')
require('json')
require('utils')

local maps = {
			 Level="Level"}

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.FilterMode.{i}.", 
    maps);

local levals = {}

for k, v in pairs(objs) do
	local newObj = {}
	newObj.Level = v["Level"]
	table.insert(levals, newObj)
end

web.print(json.encode(levals))