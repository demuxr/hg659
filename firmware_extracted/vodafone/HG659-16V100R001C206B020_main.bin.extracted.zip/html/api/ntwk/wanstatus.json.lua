require('dm')
require('web')
require('json')
require('utils')

if FormData["ID"] ~= nil then
    wanID = FormData["ID"]
end

local tostring = tostring
local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",{"WANAccessType","PhysicalLinkStatus"})
    
local errcode, atmlink = dm.GetParameterValues("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.{i}.WANDSLLinkConfig.",{"LinkStatus"})
local errcode, ptmlink = dm.GetParameterValues("InternetGatewayDevice.WANDevice.2.WANConnectionDevice.{i}.WANDSLLinkConfig.",{"LinkStatus"})

local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    {"ConnectionType", 
    "X_IPv4Enable", "X_IPv6Enable", "X_IPv6ConnectionStatus", "X_IPv6Address", "X_IPv6DNSServers", "X_IPv6PrefixList",
    "ExternalIPAddress", "DNSServers","ConnectionTrigger","ConnectionStatus", "X_ServerACName","X_Default"});

local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    {"ConnectionType",
    "X_IPv4Enable", "X_IPv6Enable", "X_IPv6ConnectionStatus", "X_IPv6Address","X_IPv6DNSServers", "X_IPv6PrefixList",
    "ExternalIPAddress", "DefaultGateway", "DNSServers", "ConnectionStatus","X_Default"});

local connections = {}

for k,v in pairs(pppCon) do
    local con = {}
    con.ID = k
    con.Enable = utils.toboolean(v["Enable"])
    utils.fill_access_info_by_ID(k, con, accessdevs);
    if con.AccessType == "DSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, atmlink)
    elseif con.AccessType == "VDSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, ptmlink)
    end

    con.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
    con.ConnectionStatus = v["ConnectionStatus"]
    con.IPv6ConnectionStatus = v["X_IPv6ConnectionStatus"]
    con.IPv4Enable = utils.toboolean(v["X_IPv4Enable"])

    con.IPv4Addr = v["ExternalIPAddress"]
    con.IPv4Gateway = ""
    con.IPv4DnsServers = v["DNSServers"]
    
    con.IPv6Enable = utils.toboolean(v["X_IPv6Enable"])
    con.IPv6Addr = v["X_IPv6Address"]
    con.IPv6DnsServers = v["X_IPv6DNSServers"]
    con.IPv6PrefixList = v["X_IPv6PrefixList"]
    con.IsDefault = v["X_Default"]
    con.PPPoEACName  = v["X_ServerACName"]
    con.PPPTrigger = v["ConnectionTrigger"]
    table.insert(connections, con)
end

for k,v in pairs(ipCon) do
    local con = {}
    con.ID = k
    utils.fill_access_info_by_ID(k, con, accessdevs);
    if con.AccessType == "DSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, atmlink)
    elseif con.AccessType == "VDSL" then
        utils.fill_xdls_linkstatus_by_ID(k, con, ptmlink)
    end
    con.ConnectionType = utils.get_ip_conn_type(k, v["ConnectionType"])
    con.ConnectionStatus = v["ConnectionStatus"]
    con.IPv6ConnectionStatus = v["X_IPv6ConnectionStatus"]

    con.IPv4Enable = utils.toboolean(v["X_IPv4Enable"])

    con.IPv4Addr = v["ExternalIPAddress"]
    con.IPv4Gateway = v["DefaultGateway"]
    con.IPv4DnsServers = v["DNSServers"]

    con.IPv6Enable = utils.toboolean(v["X_IPv6Enable"])

    con.IPv6Addr = v["X_IPv6Address"]
    con.IPv6DnsServers = v["X_IPv6DNSServers"]
    con.IPv6PrefixList = v["X_IPv6PrefixList"]
    con.IsDefault = v["X_Default"]
    table.insert(connections, con)
end
utils.multiObjSortByID(connections)
for k, v in pairs(connections) do
    if wanID == v["ID"] then
        web.print(json.encode(v))
        return
    end
end