require('dm')
require('web')
require('json')
require('utils')

local utils = require('utils')

local detectType = data["Type"]

local err = 0
if "pvc" == detectType then
	err = dm.SetParameterValues({{"InternetGatewayDevice.Services.X_PVCSearch.Enable", true}})
else
	local wan = ""
	if data["wan"] then
		wan = data["wan"]
	end
    err = web.gmsgsend("pvcsearchcms", 1, {Path=wan})
end

utils.appenderror("errcode", err)
