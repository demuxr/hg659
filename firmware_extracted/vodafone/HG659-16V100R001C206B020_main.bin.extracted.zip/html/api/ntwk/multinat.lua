local utils = require('utils')
require('dm')
local print = print

local multinat_maps = {
    Enable="Enabled",
    Type="Type",
    LocalStartIP="LocalStartIP",
    LocalEndIP="LocalEndIP",
    PublicStartIP="PublicStartIP",
    PublicEndIP="PublicEndIP"
}

function GenerateAddSetData(domain, mnatdata, param)
    local localendIP = ""
    local publicendIP = ""
    
    table.insert(param, {domain.."Enabled", mnatdata["Enable"]})
    table.insert(param, {domain.."Type", mnatdata["Type"]})
    table.insert(param, {domain.."LocalStartIP", mnatdata["LocalStartIP"]})
    table.insert(param, {domain.."PublicStartIP", mnatdata["PublicStartIP"]})

    if mnatdata["Type"] ~= 1 then
        localendIP = mnatdata["LocalEndIP"]
    end
    if mnatdata["Type"] == 3 or mnatdata["Type"] == 4 then
        publicendIP = mnatdata["PublicEndIP"]
    end   

    table.insert(param, {domain.."LocalEndIP", localendIP})
    table.insert(param, {domain.."PublicEndIP", publicendIP})
end

function create()
    -- add
    local paras = {}
    GenerateAddSetData("",data,paras) 
    local errcode, instnum, NeedReboot, errs = dm.AddObjectWithValues(data["Interface"]..".X_MultiNat.", paras);
    if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, multinat_maps)
        return errcode
    end
    utils.appenderror("errcode", 0)
    return errcode
end

function delete()
    return dm.DeleteObject(data["ID"])
end

function update()
    local domain = data["ID"]
    local param = {}
    GenerateAddSetData(domain, data, param)
    local err,needreboot, paramerror = dm.SetParameterValues(param);
    if err ~= 0 then
        utils.responseErrorcode(err, paramerror, multinat_maps)
    end
    return err
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    local index1,index2 =  string.find(data["ID"],'.X_MultiNat')
    local interface = string.sub(data["ID"],0,index1-1)
    if interface ~= data["Interface"] then
        err = delete()
        err = create() 
    else
        err = update()
    end
elseif action == 'delete' then
    err = delete()
else
    return
end

utils.appenderror("errcode", err)
