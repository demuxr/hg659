local utils = require('utils')

local domain = "InternetGatewayDevice.Services.X_PVCSearch."

local maps = {
    List = "PVCSearchList"
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
