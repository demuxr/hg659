require('dm')
require('web')
require('json')
require('utils')

local maps = {
	DMZEnable="DMZEnable",
	DMZHostIPAddress = "DMZHostIPAddress"
}

local dmzobj = {}

local errcode, ipobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.X_DMZ.", 
    {"DMZEnable", "DMZHostIPAddress"});

local errcode, pppobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.X_DMZ.", 
    {"DMZEnable", "DMZHostIPAddress"});

for k,v in pairs(ipobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["DMZEnable"] = utils.toboolean(v["DMZEnable"])
    newObj["DMZHostIPAddress"] = v["DMZHostIPAddress"]
    table.insert(dmzobj, newObj)
end

for k,v in pairs(pppobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["DMZEnable"] = utils.toboolean(v["DMZEnable"])
    newObj["DMZHostIPAddress"] = v["DMZHostIPAddress"]
    table.insert(dmzobj, newObj)
end

web.print(json.encode(dmzobj))

