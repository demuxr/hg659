require('web')

local err = web.gmsgsend("xl2tpd", 1, {Trigger=data["Trigger"]})
utils.appenderror("errcode", err)

