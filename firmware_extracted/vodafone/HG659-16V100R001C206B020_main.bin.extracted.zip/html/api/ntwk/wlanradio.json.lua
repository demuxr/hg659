require('dm')
require('web')
require('json')
require('utils')

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand",
    }
);

local wlanRadio = {}

for k, v in pairs(wifiConf) do
    if "2.4GHz" == v["OperatingFrequencyBand"] then
        wlanRadio.Enable2G = utils.toboolean(v["Enable"])
    end
    if "5GHz" == v["OperatingFrequencyBand"] then
        wlanRadio.Enable5G = utils.toboolean(v["Enable"])
    end
end

web.print(json.encode(wlanRadio))
