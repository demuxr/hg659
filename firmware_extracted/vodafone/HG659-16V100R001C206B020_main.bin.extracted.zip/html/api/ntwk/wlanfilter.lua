local utils = require('utils')
local tostring = tostring

local maps = {
	MACAddressControlEnabled = "MACAddressControlEnabled",
	MacFilterPolicy = "X_WlanMacFilterpolicy",
}

function add_one_wlan_parameter(paras, name, value)
	if nil == value then
		return 
	end	
	table.insert(paras, {name, value})
end

local paras = {}
local errcodesubmit = 0

function submit_frequency_data(paras, data)
	if nil == data then
		return 
	end
	if nil == data["ID"] then
		return 
	end		
	add_one_wlan_parameter(paras, data["ID"].."MACAddressControlEnabled", data["MACAddressControlEnabled"])
	add_one_wlan_parameter(paras, data["ID"].."X_WlanMacFilterpolicy", data["MacFilterPolicy"])
	if true == data["MACAddressControlEnabled"] then
		local errcode,wlanMac = dm.GetParameterValues(data["ID"].."X_WlanMacFilter.{i}.",
    		{
        		"X_WlanSrcMacAddress"
    		}
		);
		if wlanMac ~= nil then 
    		for k,v in pairs(wlanMac) do
    			local findnew = false
    			for k1,v1 in pairs(data["MacFilters"]) do
					for k2, value in pairs(v1) do
						if value == v["X_WlanSrcMacAddress"] then
							findnew = true
						end	
        			end
        		end
        		if false == findnew then
        			dm.DeleteObject(k)
        		end		
    		end    
		end
		for k,v in pairs(data["MacFilters"]) do
			for k1, value in pairs(v) do
				local findold = false
				for k2,v2 in pairs(wlanMac) do 
					if value == v2["X_WlanSrcMacAddress"] then
						findold = true 
					end	
				end
				if false == findold then
					local param = {}
					local inputs = {}
					param["key"] = "X_WlanSrcMacAddress"
					param["value"] = value
					table.insert(inputs, param)
					local errcode1, instnum, NeedReboot, paramerr = dm.AddObjectWithValues(data["ID"].."X_WlanMacFilter.", inputs)
					if errcode1 ~= 0 then
						errcodesubmit = errcode1
					end	 
				end	
			end
		end	
	end	
end	

dm.StartTransaction()
submit_frequency_data(paras, data["config2g"])
submit_frequency_data(paras, data["config5g"])

errcode1, NeedReboot, paramerr = dm.SetParameterValues(paras)
if errcode1 ~= 0 then
	errcodesubmit = errcode1
end	
dm.EndTransaction()
utils.responseErrorcode(errcodesubmit, paramerr, maps)

