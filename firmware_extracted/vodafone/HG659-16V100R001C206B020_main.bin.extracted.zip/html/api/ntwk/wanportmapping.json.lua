require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber

local portmapping = {}


local errcode, ipobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.PortMapping.{i}.", 
    {"PortMappingEnabled", "RemoteHost", "ExternalPort", "ExternalPortEndRange", "InternalPort", 
     "PortMappingProtocol", "InternalClient", "PortMappingDescription"});

local errcode, pppobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.PortMapping.{i}.", 
    {"PortMappingEnabled", "RemoteHost", "ExternalPort", "ExternalPortEndRange", "InternalPort", 
     "PortMappingProtocol", "InternalClient", "PortMappingDescription"});

for k,v in pairs(ipobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["PortMappingEnabled"] = utils.toboolean(v["PortMappingEnabled"])
    newObj["RemoteHost"] = v["RemoteHost"]
    newObj["ExternalPort"] = v["ExternalPort"]
    newObj["ExternalPortEndRange"] = v["ExternalPortEndRange"]
    newObj["InternalPort"] = v["InternalPort"]
    newObj["PortMappingProtocol"] = v["PortMappingProtocol"]
    newObj["InternalClient"] = v["InternalClient"]
    newObj["PortMappingDescription"] = v["PortMappingDescription"]
    table.insert(portmapping, newObj)
end

for k,v in pairs(pppobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["PortMappingEnabled"] = utils.toboolean(v["PortMappingEnabled"])
    newObj["RemoteHost"] = v["RemoteHost"]
    newObj["ExternalPort"] = v["ExternalPort"]
    newObj["ExternalPortEndRange"] = v["ExternalPortEndRange"]
    newObj["InternalPort"] = v["InternalPort"]
    newObj["PortMappingProtocol"] = v["PortMappingProtocol"]
    newObj["InternalClient"] = v["InternalClient"]
    newObj["PortMappingDescription"] = v["PortMappingDescription"]
    table.insert(portmapping, newObj)
end

utils.multiObjSortByID(portmapping)

web.print(json.encode(portmapping))
