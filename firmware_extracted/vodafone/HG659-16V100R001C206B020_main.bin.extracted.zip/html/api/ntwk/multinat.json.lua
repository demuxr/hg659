require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber

local multinat = {}

local errcode, ipobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.X_MultiNat.{i}.", 
    {"Enabled","Type","LocalStartIP","LocalEndIP","PublicStartIP","PublicEndIP"});
    
local errcode, pppobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.X_MultiNat.{i}.", 
    {"Enabled","Type","LocalStartIP","LocalEndIP","PublicStartIP","PublicEndIP"});

if nil ~= ipobjs then
    for k,v in pairs(ipobjs) do
        local newObj = {}
        newObj["ID"] = k
        local index1,index2 =  string.find(newObj["ID"],'.X_MultiNat')
        local interface = string.sub(newObj["ID"],0,index1-1)
        newObj["Enable"] = utils.toboolean(v["Enabled"])
        newObj["Type"] = v["Type"]
        newObj["LocalStartIP"] = v["LocalStartIP"]
        newObj["LocalEndIP"] = v["LocalEndIP"]
        newObj["PublicStartIP"] = v["PublicStartIP"]
        newObj["PublicEndIP"] = v["PublicEndIP"]
        newObj["Interface"] = interface
        table.insert(multinat, newObj)
    end
end

if nil ~= pppobjs then
    for k,v in pairs(pppobjs) do
        local newObj = {}
        newObj["ID"] = k
        local index1,index2 =  string.find(newObj["ID"],'.X_MultiNat')
        local interface = string.sub(newObj["ID"],0,index1-1)
        newObj["Enable"] = utils.toboolean(v["Enabled"])
        newObj["Type"] = v["Type"]
        newObj["LocalStartIP"] = v["LocalStartIP"]
        newObj["LocalEndIP"] = v["LocalEndIP"]
        newObj["PublicStartIP"] = v["PublicStartIP"]
        newObj["PublicEndIP"] = v["PublicEndIP"]
        newObj["Interface"] = interface
        table.insert(multinat, newObj)
    end
end

utils.multiObjSortByID(multinat)
web.print(json.encode(multinat))