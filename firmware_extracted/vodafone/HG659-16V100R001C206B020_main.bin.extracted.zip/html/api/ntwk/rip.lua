local utils = require('utils')

err,needreboot, paramerror = dm.SetParameterValues({
    { data["domain"].."X_RIPOperation",    data["operation"] },
    { data["domain"].."X_RouteProtocolRx", data["protocol"]  }
});

utils.appenderror("errcode", err)
