local utils = require('utils')

local domain = "InternetGatewayDevice.Services.X_Mirror."

local maps = {
    Enable="Enable",
    CapturePort = "LanInterface",
    DestPort = "TypeInterface"
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
