local utils = require('utils')
require('dm')
local print = print

local pm_maps = {
    PortMappingEnabled="PortMappingEnabled",
    RemoteHost="RemoteHost",
    ExternalPort="ExternalPort",
    ExternalPortEndRange="ExternalPortEndRange",
    InternalPort="InternalPort",
    PortMappingProtocol="PortMappingProtocol",
    InternalClient="InternalClient",
    PortMappingDescription="PortMappingDescription"
}

function create()
    -- add
    local paras = utils.GenAddObjParamInputs(data, pm_maps)

    local errcode, instnum, NeedReboot, errs = dm.AddObjectWithValues(data["WanID"].."PortMapping.", paras);

    if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, pm_maps)
        return errcode
    end
    utils.appenderror("errcode", 0)
    return errcode
end

function delete()
    return dm.DeleteObject(data["ID"])
end

function update()
    local domain = data["ID"]
    local param = utils.GenSetObjParamInputs(domain, data, pm_maps)

    local err,needreboot, paramerror = dm.SetParameterValues(param);

    if err ~= 0 then
        utils.responseErrorcode(err, paramerror, pm_maps)
    end
    return err
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    err = update()
elseif action == 'delete' then
    err = delete()
else
    return
end

utils.appenderror("errcode", err)
