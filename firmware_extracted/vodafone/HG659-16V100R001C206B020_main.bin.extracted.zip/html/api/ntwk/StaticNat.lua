local utils = require('utils')

local maps = {
	StaticNatHostMACAddress="StaticNatHostMACAddress",
	StaticNatEnable = "StaticNatEnable"
}

print("StaticNatHostMACAddress = ", data["StaticNatHostMACAddress"])
print("StaticNatEnable = ", data["StaticNatEnable"])

local domain = "InternetGatewayDevice.Services.X_StaticNat."

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);

utils.responseErrorcode(err, paramerror, maps)