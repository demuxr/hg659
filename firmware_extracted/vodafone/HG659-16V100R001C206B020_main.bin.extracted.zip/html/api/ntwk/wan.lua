local utils = require('utils')
local tostring = tostring



if nil ~= data['DNSOverrideAllowed'] then
	data['DNSOverrideAllowed'] = utils.toboolean(data['DNSOverrideAllowed'])
	if true == data['DNSOverrideAllowed'] then
		data['DNSOverrideAllowed'] = false
	else
		data['DNSOverrideAllowed'] = true
	end
end

local err, wandevs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig", 
    {"WANAccessType", "PhysicalLinkStatus"});

local errcode,vlans = dm.GetParameterValues("InternetGatewayDevice.X_VLANTermination.{i}.", 
                {"LowerLayers", "VLANID", "802-1pMark"});

function get_default_wan()
	local errcode,pppCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.", 
    	{"ConnectionType", "X_LowerLayers", "X_Default"});
	local errcode,ipCon = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.", 
    	{"ConnectionType", "X_LowerLayers", "X_Default"});
	local dftWans = {}
	for k,v in pairs(pppCon) do
		if utils.toboolean(v["X_Default"]) then
			--local item = {}
			--item.k = v
			if "UMTS" ~= utils.get_access_type_by_wan(k) then
				--table.insert(dftWans, item);
				dftWans[k] = v
			end
		end
	end
	for k,v in pairs(ipCon) do
		if utils.toboolean(v["X_Default"]) then
			--local item = {}
			--item.k = v
			--table.insert(dftWans, item);
			dftWans[k] = v
		end
	end
	return dftWans
end

utils.appenderror("errcode", 9003)

if "pppreset" == action then
	local domain  = data['ID']
	
	local paras  = {{domain.."Reset", 1}}

	local Reset_maps = {    
	    Reset               = 'Reset'
	}

	local err,needreboot, paramerror = dm.SetParameterValues(paras);
	utils.responseErrorcode(err, paramerror, Reset_maps)

	return
end

if "trigger" == action then
	local errorcode = web.gmsgsend("wan", 1, {Trigger=data["Trigger"],Path=data["Path"]})
	utils.appenderror("errcode", 0)
	return
end

if "delete" == action then
	utils.safe_delete_wan(data["ID"])
	utils.appenderror("errcode", 0)
	return
end

if "create" == action then
	--- Add new WAN connection
	local linkdata = data["linkdata"]
	if linkdata then
		lowerlayer = utils.create_new_link(linkdata, wandevs)
		data["LowerLayer"] = lowerlayer
	else
		data["LowerLayer"] = ""
	end

	if "" == data["LowerLayer"] then
		-- Add new WAN must provide link data
		utils.appenderror("AccessType", "wan.too_many_err")
		return
	end

	-- Get WANConnectionDevice for this connection now ...
	local wanconndev = utils.get_wanconn_by_wanid(data["LowerLayer"])
	if "" == wanconndev then
		utils.appenderror("AccessType", "wan.too_many_err")
		return
	end

	local newId = utils.add_new_wan_to_wan_conn_dev(data, wanconndev, wandevs)
	if "" == newId then
		return
	end
	utils.appenderror("errcode", 0)
	utils.appenderror("ID", newId)
	return
end


local linkdata = data["linkdata"]
if linkdata then
	local wanconndev = utils.get_wanconn_by_wanid(linkdata["ID"])
	if "" == wanconndev then
		utils.appenderror("AccessType", "wan.too_many_err")
		return
	end

	local lowerlayer = utils.update_single_link(wanconndev, linkdata, wandevs, vlans, false)
	utils.luadbg("Update link return ["..tostring(lowerlayer).."]")
	if "" == lowerlayer then
		utils.appenderror("AccessType", "wan.too_many_err")
		return
	end
	if nil == lowerlayer then
		return
	end
	data["LowerLayer"] = lowerlayer

	-- Update wandevs
	err, wandevs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig", 
    		{"WANAccessType"});
end

local lowerlayer = utils.get_lowerlayer_by_wan(data["ID"])

-- Get current wan connection device
local wanconndev = utils.get_wanconn_by_wanid(data["LowerLayer"])
if "" == wanconndev then
	utils.appenderror("AccessType", "wan.too_many_err")
	return
end

local newWan = utils.update_single_wan(data, wanconndev, false, wandevs)
if "" == newWan then
	return
end

local startPos, endPos = string.find(newWan, ".WANConnectionDevice")
local dslModeID = string.sub(newWan, 1, startPos)
dslModeID = dslModeID.."WANDSLInterfaceConfig."

local dslmodemaps = {
    DSLMode = "X_ConfigMode"
}

print("dslModeID is:"..dslModeID)
local dslmodeparam = utils.GenSetObjParamInputs(dslModeID, data, dslmodemaps)
local err,needreboot, paramerror = dm.SetParameterValues(dslmodeparam)

utils.check_vlan_need_to_be_deleted(lowerlayer, nil, 0)

utils.luadbg("Update wan return id ["..newWan.."]")
utils.appenderror("errcode", 0)
utils.appenderror("ID", newWan)
