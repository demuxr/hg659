require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring



local status = {}

local errcode,smb = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.NetworkServer.", {"SMBEnable"})
local objsmb = smb["InternetGatewayDevice.Services.StorageService.1.NetworkServer."]
status.SmbEnable = utils.toboolean(objsmb["SMBEnable"])

local errcode,ftp = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.FTPServer.", {"Enable"})
local objFtp = ftp["InternetGatewayDevice.Services.StorageService.1.FTPServer."]
status.FtpEnable = utils.toboolean(objFtp["Enable"])

local errcode,domain = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.",
    {
        "DeviceName",
        "DomainName"
    }
)

local objdomain = domain["InternetGatewayDevice.LANDevice.1.LANHostConfigManagement."]

status.SmbLink = "file://"..objdomain["DeviceName"].."."..objdomain["DomainName"]

status.FtpLink = "ftp://"..objdomain["DeviceName"].."."..objdomain["DomainName"]
local errcode,Anonymous = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.FTPServer.AnonymousUser.",{"Enable"})
local objanon = Anonymous["InternetGatewayDevice.Services.StorageService.1.FTPServer.AnonymousUser."]
status.AnonymousEnable = utils.toboolean(objanon["Enable"]) 


local accounttrue = false
local errcode, usbaccount = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.UserAccount.{i}.", { "Enable"} )
if usbaccount ~= nil then
	for k,v in pairs(usbaccount) do
		if utils.toboolean(v["Enable"])  then
			accounttrue = true
		end
	end
end
status.AccountEnable = accounttrue

web.print(json.encode(status))