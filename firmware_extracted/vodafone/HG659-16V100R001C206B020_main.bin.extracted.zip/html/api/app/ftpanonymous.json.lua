require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.1.FTPServer.AnonymousUser.",
    {
        "Enable",
        "StartingFolder",
        "ReadOnlyAccess",
        "X_AllPath"
    }
);

local obj = values["InternetGatewayDevice.Services.StorageService.1.FTPServer.AnonymousUser."]

local anonymcfg = {}
anonymcfg.Path = ""

if obj["StartingFolder"] and string.len(obj["StartingFolder"]) ~= 0 then
	local LogicalVolumeCfg = obj["StartingFolder"].."."
	local errcode, sharepath = dm.GetParameterValues(LogicalVolumeCfg,
		{
			"Name"
		}
	);
	local pathobj = sharepath[LogicalVolumeCfg]
	anonymcfg.Path = pathobj["Name"]
end

anonymcfg.Enable = utils.toboolean(obj["Enable"])
anonymcfg.ReadOnly = obj["ReadOnlyAccess"]
anonymcfg.AllPath = obj["X_AllPath"]

web.print(json.encode(anonymcfg))