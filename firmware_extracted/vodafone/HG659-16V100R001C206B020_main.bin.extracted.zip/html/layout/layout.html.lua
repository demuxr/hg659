 web.print('<!DOCTYPE html>\
<!--[if lt IE 7 ]><html lang="en" class="ie6"><![endif]-->\
<!--[if IE 7 ]><html lang="en" class="ie7"><![endif]-->\
<!--[if IE 8 ]><html lang="en" class="ie8"><![endif]-->\
<!--[if IE 9 ]><html lang="en" class="ie9"><![endif]-->\
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->\
<head>\
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >\
<meta name="viewport" content="width=device-width, initial-scale=1.0">\
<meta name="description" content="">\
<meta name="author" content="">\
');  html.csrf_meta_tag()  web.print('\
<title>Vodafone Home Gateway HG659</title>\
');  html.link('/css/cat_public.css')  web.print('<!--[if lt IE 9]>\
');  html.rawscript('/js/html5.js')  web.print('\
<![endif]-->\
<!--[if lt IE 7]>\
');  html.rawscript('/lib/DD_belatedPNG_0.0.8a-min.js')  web.print('\
<![endif]-->\
<script language="JavaScript" type="text/javascript">\
'); web.print('var g_Lang = new Array();\r\
g_Lang[0] = {lang:"en", title:"English"};\r\
'); web.print('\
'); web.print('var g_Menus = [{"ID":"home", "Page":"/html/wizard/wizard.html", "Children":[{"ID":"internet_wizard", "Page":"/html/wizard/wizard.html", "show":true}]},{"ID":"internet_settings", "Page":"/html/advance.html", "Children":[{"ID":"internet", "Page":"/html/wan_setup_view.js", "show":true},{"ID":"parent_control", "Page":"/html/parent_control_view.js", "show":true},{"ID":"network_security", "Page":"/html/network_security_view.js", "show":true},{"ID":"qos", "Page":"/html/qos_view.js", "show":true},{"ID":"Network_services", "Page":"/html/network_service_view.js", "show":true},{"ID":"vpn", "Page":"/html/vpn_view.js", "show":true},{"ID":"nat", "Page":"/html/nat_view.js", "show":true},{"ID":"route", "Page":"/html/route_view.js", "show":true}]},{"ID":"homenetwork_settings", "Page":"/html/advance.html", "Children":[{"ID":"landevices", "Page":"/html/landevices_view.js", "show":true},{"ID":"lan", "Page":"/html/lan_setup_view.js", "show":true},{"ID":"wlan", "Page":"/html/wlan_setup_view.js", "show":true},{"ID":"wlan_access", "Page":"/html/wlan_access_view.js", "show":true},{"ID":"guest_network", "Page":"/html/guest_network_view.js", "show":true}]},{"ID":"sharing_settings", "Page":"/html/advance.html", "Children":[{"ID":"file_services", "Page":"/html/file_services_view.js", "show":true},{"ID":"dlna_sharing", "Page":"/html/dms_view.js", "show":true}]},{"ID":"telephone_settings", "Page":"/html/advance.html", "Children":[{"ID":"voip_provider", "Page":"/html/voip_provider_view.js", "show":true},{"ID":"fxsphone", "Page":"/html/fxsphone_view.js", "show":true},{"ID":"voipinfo", "Page":"/html/voipinfo_view.js", "show":true},{"ID":"call_list", "Page":"/html/call_list_view.js", "show":true},{"ID":"dail_plan", "Page":"/html/dial_plan_view.js", "show":true},{"ID":"voice_advalced", "Page":"/html/voip_advanced_view.js", "show":true}]},{"ID":"maintain_settings", "Page":"/html/advance.html", "Children":[{"ID":"device_info", "Page":"/html/device_info_view.js", "show":true},{"ID":"user_account", "Page":"/html/user_account_view.js", "show":true},{"ID":"device_mngt", "Page":"/html/device_mngt_view.js", "show":true},{"ID":"log", "Page":"/html/log_view.js", "show":true},{"ID":"diagnose_overview", "Page":"/html/diagnose_overview_view.js", "show":true},{"ID":"diagnose_tools", "Page":"/html/diagnose_view.js", "show":true},{"ID":"tr069", "Page":"/html/cwmp_view.js", "show":true},{"ID":"statistics", "Page":"/html/homenetwork_info_view.js", "show":true}]}];'); web.print('\
</script>\
</head>\
<body data-spy="scroll" data-target=".bs-docs-sidebar">\
<!-- Navbar top menu-->\
<div class="navbar navbar-fixed-top">\
    <div class="container top_div">\
        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" style="margin-top:17px;">\
            <span class="icon-bar"></span>\
            <span class="icon-bar"></span>\
            <span class="icon-bar"></span>\
        </a>\
        <ul class="nav pull-left logo_png">\
            <li class="pull-left"><div id="huaweilogo" class="ic-logo ie6image"></div></li>\
            <li id="width_product_title" class="pull-left product_title">Vodafone Home Gateway</li>\
        </ul>\
        <div id="lang"></div>\
    </div><!--/.container-->\
    <!--here for top menu-->\
    <div class="container shadow height_52 top_menu_back_img" id="menu_test">\
    </div>\
    <!--here for hide menu-->\
    <div class="hide min_height_52 width_100p top_menu_back_img" id="menu_for_hide">\
    </div>\
</div>\
<!--body-->\
<div id="submit_light" class="submit_white_content rounddiv"></div>\
<div id="submit_fade" class="submit_black_overlay hide" style="filter:alpha(opacity=50); opacity:0.5;"></div>\
<div class="main-container">    \
    <div class="container">\
        <div id="prompt_info"></div>\
        <div id="container"></div>\
    </div>\
</div>\
<script language="JavaScript" type="text/javascript">\
var g_userLevel = ');  local name,level = web.getuserinfo(); if level ~= nil then web.print(level) else web.print('0') end   web.print(';\
var g_userLang = "');  web.print(web.lang())    web.print('";\
</script>\
\
<script type="text/x-handlebars" data-template-name="lang">\
    <div class="nav-collapse collapse paddingtop_10">\
        {{view  Atp.ProductDividerLineView}}\
        <ul class="nav pull-right">\
            <li class="pull-left text_center paddingleft_10 ie6margintop_10"><a id="loginusername">');  local name = web.getuserinfo();if name ~= nil then name = string.gsub(name, "<", "&lt"); name = string.gsub(name, ">", "&gt"); web.print(name) end;   web.print('</a></li> \
            <li class="pull-left text_center paddingleft_10">\
            <button id="signout_ctrl" class="signout margintop_8 fontsize_10" type="button" {{action "postData" target="Atp.LoginOutController"}}>{{t Menu.Signout}}</button></li>\
                {{view Atp.LanguageDividerLineView}}\
                {{view Atp.LanguageBlock}}\
            <li class="marginright_5 text_center paddingleft_10">&nbsp;</li>\
        </ul>\
    </div>\
</script>\
\
<script type="text/x-handlebars" data-template-name="container">\
    ');  html.yield()  web.print('\
</script>\
\
<!-- Footer-->\
<div class="navbar navbar-fixed-bottom">\
    <footer>\
        <div id="foot">\
        <script type="text/x-handlebars" data-template-name="foot">\
           {{view Atp.footerview}}\
        </script>\
        </div>\
        <div id="heartbeat"></div>\
    </footer>\
</div>\
<div id="backgroundPopup" class="submit_black_overlay hide" style="filter:alpha(opacity=50); opacity:0.5;"></div>\
<div id="output_login" class="modal hide index_page_us_ps_div" style="z-index:1234;_margin-left:0px;"></div>\
<script type="text/x-handlebars" data-template-name="heartbeat">\
    {{view Atp.HeartbeatView}}\
</script>\
<!--[if lt IE 8 ]>');  html.rawscript('/lib/json.js')  web.print('<![endif]-->\
\
');  html.gzrawscript('/lib/cat_liblayout.js')  web.print('\
');  html.rawlang('menu_res.js')  web.print('\
\
');  html.gzrawscript('/lib/cat_exember.js')  web.print('\
\
');  html.script('/lib/base64.js')  web.print('\
');  html.yield('include')  web.print('\
');  html.scriptall()  web.print('\
\
');  html.yield('script_tag')  web.print('\
\
<script language="JavaScript" type="text/javascript">\
$(document).ready(function(){\
    load_sysmenu();\
    Ember.View.create({\
        templateName: \'container\'\
    }).appendTo(\'#container\');\
\
});\
</script>\
</body>\
</html>\
'); 