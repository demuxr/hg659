local assert, error, loadstring, char, find, format, sub = assert, error, loadstring, string.char, string.find, string.format,string.sub
local getfenv, loadstring, setfenv = getfenv, loadstring, setfenv
local open = io.open
local print = print
local pairs = pairs
local table = table
local web = require("web")
local utils = require("utils")

module (...)

-- support utf-8
local BOM = char(239) .. char(187) .. char(191)

local yield_file= nil
local yield_content = nil
local script_res = {}

function render(filename, env)
	local src = web.getfile(filename)

	if src:sub(1,3) == BOM then src = src:sub(4) end
  
	local prog, err = loadstring(src, filename)
    local _env
	if env then
		_env = getfenv (prog)
		setfenv (prog, env)
	end
	if not prog then error (err, 3) end
    
	prog() 
end

function setyieldfile(file)
	yield_file = file
    yield_content = nil
end

function setYieldContent(content)
    yield_content = content
    yield_file = nil
end    

function yield (p)
    local src = ''
    if yield_file ~= nil then
        src = web.getfile(yield_file)
    else
        src = yield_content
    end
	if src:sub(1,3) == BOM then src = src:sub(4) end

	if not p then
		-- find last 'content_end'
		local last = 0
		local i = 0
		local j
		while true do
			i, j = find(src, "--lua_content_end__", i+1)	
			if i == nil then break end
			last = j
		end
		if last ~= 0 then
			src = sub(src, last+1)
		end
	else
		local s,e = find(src, format("--lua_content_for__ %s begin", p))
        if not s then return end 
		local s1, e1 = find(src, format("--lua_content_end__"), e + 1)

		if not s and not s1 then error(err, 4) end
		src = sub(src, e+1, s1-1)
	end
	
	local prog, err = loadstring(src, yield_file)    
	if not prog then error (err, 3) end
    prog()    

end

function resource(res)
	local id = web.getresourceid()
	web.print(res.."?"..id)
end

function rawscript(res)
	local id = web.getresourceid()
	web.print('<script type="text/javascript" language="javascript" src="'..res..'?'..id..'"></script>')
end

function gzrawscript(res)
	local id = web.getresourceid()
	web.print('<script type="text/javascript" language="javascript" src="'..res..'.jgz?'..id..'"></script>')
end

function script(res)
	local id = web.getresourceid()
	local index = find(id, 'atp_virtual_web')
	if nil ~= index then
		web.print('<script type="text/javascript" language="javascript" src="'..res..'?'..id..'"></script>')
	else
		table.insert(script_res, res)
	end
end

function scriptall()
	local id = web.getresourceid()
	local index = find(id, 'atp_virtual_web')
	if nil ~= index then
		return 
	end

	local allres = "/atpscriptall_"
	for k, v in pairs(script_res) do
		allres = allres..v
	end
	web.print('<script type="text/javascript" language="javascript" src="'..allres..'?'..id..'"></script>')
	script_res = {}
end

function link(res)
	local id = web.getresourceid()
	local language = web.lang()
	local filename = res:sub(6)
	if language == "ar" then
		web.print('<link type="text/css" href="/css/ar_'..filename..'.cgz?'..id..'" rel="stylesheet">')
	else
		web.print('<link type="text/css" href="/css/'..filename..'.cgz?'..id..'" rel="stylesheet">')
	end
end

function csrf_meta_tag()
    local param,token = web.getcsrf()	
    local n,e      = web.getrsakey()
    web.print("<meta name=\"csrf_param\" content=\""..param.."\"/>\r\n")
    web.print("<meta name=\"csrf_token\" content=\""..token.."\"/>")
    web.print("<meta name=\"n\" content=\""..n.."\"/>\r\n")
    web.print("<meta name=\"e\" content=\""..e.."\"/>")
end

function lang(res)
	local lan = '/lang/'..web.lang()..'/'..res
	script(lan)
end

function rawlang(res)
	local lan = '/lang/'..web.lang()..'/'..res
	rawscript(lan)
end

function auth(level)
	return utils.has_authorization(level)
end