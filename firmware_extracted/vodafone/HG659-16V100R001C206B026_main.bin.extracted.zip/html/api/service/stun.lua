local utils = require('utils')
local web = require('web')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="STUNEnable",
    url = "STUNServerAddress",
    name = "STUNUsername",
    conname = "X_StunConnectionRequestUsername",
    port = "STUNServerPort",
    min = "STUNMinimumKeepAlivePeriod",
    max = "STUNMaximumKeepAlivePeriod",
}

if true == utils.toboolean(web.getparaenc()) then
    if nil ~= data["pwd"] then
        local newpara = web.decodepara(data["pwd"])
        if "" ~= newpara then
            data["pwd"] = newpara
        end
    end
    if nil ~=  data["conpwd"] then
        local newpara = web.decodepara(data["conpwd"])
        if "" ~= newpara then
            data["conpwd"] = newpara
        end
    end 
end

if data["pwd"] ~= _G["defaultPasswd"] then
	maps["pwd"] = "STUNPassword"
end

if data["conpwd"] ~= _G["defaultPasswd"] then
	maps["conpwd"] = "X_StunConnectionRequestPassword"
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
