local utils = require('utils')
local web = require('web')

local domain = "InternetGatewayDevice.ManagementServer."

local maps = {
    enable="EnableCWMP",
    acsurl = "URL",
    acsname = "Username",
    inform = "PeriodicInformEnable",
    interval = "PeriodicInformInterval",
    conname = "ConnectionRequestUsername",
    conport = "X_ConnReqPort",
    cert = "X_SSLCertEnable"
}

if true == utils.toboolean(web.getparaenc()) then
    if nil ~= data["acspwd"] then
        local newpara = web.decodepara(data["acspwd"])
        if "" ~= newpara then
            data["acspwd"] = newpara
        end
    end
    if nil ~= data["conpwd"] then  
        local newpara = web.decodepara(data["conpwd"])
        if "" ~= newpara then
            data["conpwd"] = newpara
        end
    end 
end

if data["acspwd"] ~= _G["defaultPasswd"] then
    maps["acspwd"] = "Password";
end
if data["conpwd"] ~= _G["defaultPasswd"] then
    maps["conpwd"] = "ConnectionRequestPassword";
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)
