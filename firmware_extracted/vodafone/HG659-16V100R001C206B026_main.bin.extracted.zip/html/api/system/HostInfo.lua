local utils = require('utils')
require('dm')

local maps = {
    ActualName="X_DeviceName",
    IconType = "X_DeviceType",
    MACAddress = "MACAddress"
}

function check_macaddr_unique(ID, MAC)
    local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.", 
        {"MACAddress"});

    for k,v in pairs(objs) do
        if k ~= ID and MAC == v["MACAddress"] then
            return true
        end
    end

    return false
end

function create()
    -- add 
    local paras = {{"X_DeviceName", data["ActualName"]}, 
        {"X_DeviceType", data["IconType"]},
        {"MACAddress", data["MACAddress"]},
        {"Active", false}}

    if check_macaddr_unique("", data["MACAddress"]) then
        utils.appenderror("landev.mac", "landev.mac_err")
        return 9006
    end
    local err,instnum,NeedReboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.LANDevice.1.Hosts.Host.", paras);
    utils.responseErrorcode(err, errs, maps)
    return err
end

function delete()
    local errcode,macfilters = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_WlanMacFilter.{i}.",
        {
            "X_WlanSrcMacAddress",
        }
    );

    local ret_del_macfilter
    if macfilters ~= nil then
        for kmac, vmac in pairs(macfilters) do
            if vmac["X_WlanSrcMacAddress"] == data["MACAddress"] then
                dm.DeleteObject(kmac)
            end
        end
    end
    return dm.DeleteObject(data["ID"])
end

function update()
    local domain = data["ID"]

    if check_macaddr_unique(domain, data["MACAddress"]) then
        utils.appenderror("landev.mac", "landev.mac_err")
        return 9006
    end
    
    local paras = {{domain.."X_DeviceName", data["ActualName"]}, 
        {domain.."X_DeviceType", data["IconType"]},
        {domain.."MACAddress", data["MACAddress"]}}

    local err,needreboot, paramerror = dm.SetParameterValues(paras);
    utils.responseErrorcode(err, paramerror, maps)
    return err
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    err = update()
elseif action == 'delete' then
    err = delete()
    
end
utils.appenderror("errcode", err)
