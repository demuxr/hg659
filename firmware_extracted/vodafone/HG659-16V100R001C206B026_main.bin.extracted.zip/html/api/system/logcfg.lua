local utils = require('utils')

local domain = "InternetGatewayDevice.X_SyslogConfig."
 local maps = {
    LogEnable="Enable",
    LogLevel = "Level"
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)