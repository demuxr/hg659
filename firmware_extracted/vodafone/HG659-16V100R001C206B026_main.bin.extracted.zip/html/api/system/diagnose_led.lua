local utils = require('utils')

local domain = "InternetGatewayDevice.X_LEDDiagnostics."

local maps = nil

if data["DiagnoseAction"] == 'Requested' then
	maps = {
		DiagnoseAction="DiagnosticsState",
	}
else
	maps = {
		Result = "Results"
	}
end

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)