require('dm')
require('web')
require('json')
local tostring = tostring

local errcode,temperature = dm.GetParameterValues("InternetGatewayDevice.DeviceInfo.TemperatureStatus.TemperatureSensor.{i}.",{"Name","Value"})

local temp = {}

for k,v in pairs(temperature) do
	local temper = {}
	temper.ID = k
    temper.TempName = v["Name"]
    temper.Temperature = v["Value"]
    table.insert(temp, temper)
end

web.print(json.encode(temp))