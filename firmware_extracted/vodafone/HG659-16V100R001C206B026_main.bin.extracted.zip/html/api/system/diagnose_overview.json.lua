require('dm')
require('utils')

local maps = {
	DiagnoseAction="DiagnosticsState",
	Result = "Results"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_LEDDiagnostics.", maps)

local obj = values["InternetGatewayDevice.X_LEDDiagnostics."]
utils.responseSingleObject(obj, maps)