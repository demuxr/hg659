local utils = require('utils')
local json = require('json')
local web  = require('web')

local categorys = {}

array = web.getlogcategory()
if array ~= nil then
    for i=1,table.getn(array),1 do
        table.insert(categorys, array[i])
    end
end

local jsonstr = json.encode(categorys)

web.print(jsonstr)