local utils = require('utils')

local domain = "InternetGatewayDevice.Services.X_Power.AutoPowerSave."

local maps = {
    CPUEnable = "CPUEnable",
    DSLEnable = "DSLEnable"
}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)