require('dm')
require('utils')

local maps = {
	DiagnoseAction="DiagnosticsState",
	Result = "Results"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_LEDDiagnostics.", maps)

local obj = values["InternetGatewayDevice.X_LEDDiagnostics."]

local ledresult = {}

ledresult.DiagnoseAction = obj["DiagnosticsState"]
ledresult.Result = obj["Results"]


web.print(json.encode(ledresult))