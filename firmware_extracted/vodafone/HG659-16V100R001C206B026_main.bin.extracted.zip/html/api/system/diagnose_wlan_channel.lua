local utils = require('utils')

local domain = "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_WLANDiagnostic."

local maps = {
		DiagnoseAction="DiagnosticsState",
	}

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);
utils.responseErrorcode(err, paramerror, maps)