require('dm')
require('web')
require('json')
require('utils')
local string = string
local tostring = tostring

local errcode,host = dm.GetParameterValues("InternetGatewayDevice.DeviceInfo.",
    {
        "ProductClass",
        "SerialNumber",
        "HardwareVersion",
        "SoftwareVersion",
        "ManufacturerOUI"
    }
);

local obj = host["InternetGatewayDevice.DeviceInfo."]

local Device = {}

Device.DeviceName = obj["ProductClass"]
Device.SerialNumber = obj["SerialNumber"]
Device.HardwareVersion = obj["HardwareVersion"]
Device.SoftwareVersion = obj["SoftwareVersion"]
Device.ManufacturerOUI = obj["ManufacturerOUI"]

local errcode,host = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.", {"MACAddress"})
local obj = host["InternetGatewayDevice.LANDevice.1.LANHostConfigManagement."]
Device.MacAddress = obj["MACAddress"]

Device.ReleaseDate, Device.BootloaderVersion, Device.ChipModel, Device.BatchNumber = web.getDeviceExternStatus()

web.exec("top -n 1 >/var/diagnose_top")
fh = io.open("/var/diagnose_top", "r")
line = fh.read(fh)
ip = string.find(line, "Mem:")
Device.Mem = string.sub(line, ip+5)

line = fh.read(fh)
ip = string.find(line, "CPU:")
Device.CPU = string.sub(line, ip+5)

io.close(fh)
web.exec("rm /var/diagnose_top")

web.print(json.encode(Device))
