require('dm')
require('utils')
require('json')
require('web')

local usb = {}

local maps = {
    Name  = "Name",
    Model = "ConnectionType",
    Capacity = "Capacity"
}

local errcode,usbPhysicalStorage = dm.GetParameterValues("InternetGatewayDevice.Services.StorageService.{i}.PhysicalMedium.{i}.", maps);

if usbPhysicalStorage ~= nil then
    for k, v in pairs(usbPhysicalStorage) do
        table.insert(usb, v)
    end
end

for k, v in pairs(usb) do
    v.DeviceType = 'Storage'
end

local maps = {
    Name="Name"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_Printer.", maps)
if values ~= nil then
    local obj = values["InternetGatewayDevice.Services.X_Printer."]
    local printer = {}
    if obj["Name"] ~= 'Unknown' then
        printer.Name = obj["Name"]
        printer.DeviceType = "Printer"
        table.insert(usb, printer)
    end
end

web.exec("cat /proc/proc_user_umts >/var/diagnose_umts")
fh = io.open("/var/diagnose_umts", "r")
line = fh:read("*a")
fh:close()
web.exec("rm /var/diagnose_umts")
ip = string.find(line, "modem")
if ip ~= nil then
    -- has datacard
    web.exec("atcmd ati display >/var/diagnose_umts")
    fh = io.open("/var/diagnose_umts", "r")
    line = fh:read("*a")
    fh:close()
    web.exec("rm /var/diagnose_umts")
    ip = string.find(line, "Model:")
    ep = string.find(line, "Revision:")

    local datacard = {}
    datacard.Name = string.sub(line, ip+string.len("Model:"), ep-1)
    datacard.DeviceType = "Datacard"
    table.insert(usb, datacard)
end
    
web.print(json.encode(usb))
