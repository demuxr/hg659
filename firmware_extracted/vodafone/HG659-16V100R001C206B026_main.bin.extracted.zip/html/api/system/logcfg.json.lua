require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local errcode,values = dm.GetParameterValues("InternetGatewayDevice.X_SyslogConfig.",
    {
        "Enable",
        "Level"
    }
);
local obj = values["InternetGatewayDevice.X_SyslogConfig."]

local logcfg = {}

logcfg.LogEnable = utils.toboolean(obj["Enable"])
logcfg.LogLevel = obj["Level"]
web.print(json.encode(logcfg))
