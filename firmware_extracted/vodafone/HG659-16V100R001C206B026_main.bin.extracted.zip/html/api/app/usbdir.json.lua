local utils = require('utils')
local json = require('json')
local web  = require('web')

if FormData["path"] ~= nil then
    scan_path = FormData["path"]
else
    scan_path = "/mnt"
end

local dirs = {}

array = web.readdir(scan_path)
if array ~= nil then
    result = 1
    for i=1,table.getn(array),2 do
        local file = {}
        file.Path = array[i+1]
        file.Base64Path = array[i]

        table.insert(dirs, file)
    end
else
    result = 0
end

local jsonstr = json.encodex(dirs)

web.print(jsonstr)
