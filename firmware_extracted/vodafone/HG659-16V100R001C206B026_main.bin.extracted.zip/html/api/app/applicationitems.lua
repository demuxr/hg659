local utils = require('utils')
require('dm')
local print = print
local tonumber = tonumber

function create_update_content(appdomain)
	local  domain = ''
	for k, v in pairs(data["ItemList"]) do
		local ID = v["ID"]
		if ID == "" then
			-- create
			domain = appdomain.."Content."

			local paras = {{"Protocol", v["Protocol"]}, 
		 		{"ExternalPort", tonumber(v["ExternalPort"])}, 
		 		{"ExternalPortEnd", tonumber(v["ExternalPortEnd"])}, 
		 		{"InternalPort", tonumber(v["InternalPort"])},
		 		{"InternalPortEnd", tonumber(v["InternalPortEnd"])}}

	 		local err = dm.AddObjectWithValues(domain, paras);
		else
			-- update
			domain = ID;
			local paras = {{domain.."Protocol", v["Protocol"]}, 
		 		{domain.."ExternalPort", tonumber(v["ExternalPort"])}, 
		 		{domain.."ExternalPortEnd", tonumber(v["ExternalPortEnd"])}, 
		 		{domain.."InternalPort", tonumber(v["InternalPort"])},
		 		{domain.."InternalPortEnd", tonumber(v["InternalPortEnd"])}}

	 		local err = dm.SetParameterValues(paras)
	 	end
			
	end

	return err
end

function create()
	-- add 
	local paras = {{"Name", data["Name"]}, 
		{"Type", data["Type"]}}

	local errcode, instnum, NeedReboot = dm.AddObjectWithValues("InternetGatewayDevice.Services.X_Application.", paras);

	return create_update_content("InternetGatewayDevice.Services.X_Application."..instnum..".")
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]

	local paras = {{domain.."Name", data["Name"]}, 
		{domain.."Type", data["Type"]}}

	local err = dm.SetParameterValues(paras)

	if err ~= 0 then
		return err
	end

	return create_update_content(domain)
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)

