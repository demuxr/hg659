local utils = require('utils')
require('dm')
local print = print
local tonumber = tonumber

local type_transcode = { 1, 2, 4, 8}
type_transcode[0] = 0

function get_type()
	local type = 0;
	if data["EnablePortmapping"] then
		type = type + 1
	end
	if data["EnablePorttrigger"] then
		type = type + 2
	end
	if data["EnableQos"] then
		type = type + 4
	end
	if data["EnableFilter"] then
		type = type + 8
	end

	return type
end

local applicationmaps = {
	Name = "Name",
	Type = "Type"
}

local itemmaps = {
	Protocol = "Protocol",
	ExternalPort = "ExternalPort",
	ExternalPortEnd = "ExternalPortEnd",
	InternalPort = "InternalPort",
	InternalPortEnd = "InternalPortEnd"
}

function create_update_content(appdomain)
	local  domain = ''
	for k, v in pairs(data["ItemList"]) do
		if v["ExternalPortEnd"] == '' then
			v["ExternalPortEnd"] = 0
		end
	
		if v["InternalPortEnd"] == '' or v["InternalPortEnd"] == null  then
			v["InternalPortEnd"] = 0
		end

		if v["ExternalPort"] == '' then
			v["ExternalPort"] = 0
		end
	
		if v["InternalPort"] == ''  then
			v["InternalPort"] = 0
		end

		local ID = v["ID"]
		if ID == "" then
			-- create
			domain = appdomain.."Content."

			local paras = {{"Protocol", v["Protocol"]}, 
		 		{"ExternalPort", tonumber(v["ExternalPort"])}, 
		 		{"ExternalPortEnd", tonumber(v["ExternalPortEnd"])}, 
		 		{"InternalPort", tonumber(v["InternalPort"])},
		 		{"InternalPortEnd", tonumber(v["InternalPortEnd"])}}

	 		local err, InstanceNumber, NeedReboot, paramErrs = dm.AddObjectWithValues(domain, paras);
	 		utils.responseErrorcode(err, paramErrs, itemmaps)
		else
			-- update
			domain = ID;
			local paras = {{domain.."Protocol", v["Protocol"]}, 
		 		{domain.."ExternalPort", tonumber(v["ExternalPort"])}, 
		 		{domain.."ExternalPortEnd", tonumber(v["ExternalPortEnd"])}, 
		 		{domain.."InternalPort", tonumber(v["InternalPort"])},
		 		{domain.."InternalPortEnd", tonumber(v["InternalPortEnd"])}}

	 		local err, instnum, paramErrs = dm.SetParameterValues(paras)
	 		utils.responseErrorcode(err, paramErrs, itemmaps)
	 	end
			
 		if err ~= 0 then
 			return err
 		end
	end

	return 0
end

function create()
	-- add 
	local paras = {{"Name", data["Name"]},
		{"Type", get_type()}}

	local errcode, instnum, NeedReboot, paramErrs = dm.AddObjectWithValues("InternetGatewayDevice.Services.X_Application.", paras);
	if errcode ~= 0 then
		utils.responseErrorcode(errcode, paramErrs, applicationmaps)
		return errcode
	end
	errcode = create_update_content("InternetGatewayDevice.Services.X_Application."..instnum..".")
	if errcode ~= 0 then
		dm.DeleteObject("InternetGatewayDevice.Services.X_Application."..instnum..".")
	end
	return errcode
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]
	local paras  = nil

	paras = {{domain.."Name", data["Name"]}, 
		{domain.."Type", get_type()}}

	local err, NeedReboot, paramErrs = dm.SetParameterValues(paras)
	if err ~= 0 then
		utils.responseErrorcode(err, paramErrs, applicationmaps)
		return err
	end

	return create_update_content(domain)
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end
utils.appenderror("errcode", err)

