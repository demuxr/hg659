require('dm')
require('web')
require('json')
require('utils')

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.IpFilter.{i}.",
    {"Name", "Status", "Protocol", "SourceIPStart", "SourceIPEnd", "DestIPStart", "DestIPEnd", "SourcePortStart", "SourcePortEnd", "DestPortStart", "DestPortEnd", "Interface"});

local ipfilter = {}

if objs ~= nil then
    for k,v in pairs(objs) do
        local newObj = {}
        newObj["ID"] = k
        newObj["Name"] = v["Name"]
        newObj["Status"] = v["Status"]
        newObj["Protocol"] = v["Protocol"]
        newObj["SourceIPStart"] = v["SourceIPStart"]
        newObj["SourceIPEnd"] = v["SourceIPEnd"]
        newObj["DestIPStart"] = v["DestIPStart"]
        newObj["DestIPEnd"] = v["DestIPEnd"]
        newObj["SourcePortStart"] = v["SourcePortStart"]
        newObj["SourcePortEnd"] = v["SourcePortEnd"]
        newObj["DestPortStart"] = v["DestPortStart"]
        newObj["DestPortEnd"] = v["DestPortEnd"]
        newObj["Interface"] = v["Interface"]
        table.insert(ipfilter, newObj)
    end
end

utils.multiObjSortByID(ipfilter)
web.print(json.encode(ipfilter))