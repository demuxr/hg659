local utils = require('utils')
local web = require('web')
local tostring = tostring

local errcode,all_ddns= dm.GetParameterValues("InternetGatewayDevice.Services.X_DDNSConfiguration.{i}.",
        {"Enable"})

-- Return domainname of first ddns entry
function get_first_ddns_entry(all_ddns)
	if not all_ddns then
		return ""
	end

	for k,v in pairs(all_ddns) do
		return k
	end
	return ""
end

function add_one_ddns_parameter(paras, name, value, ddnsdomain)
	local newName = ddnsdomain..name
	table.insert(paras, {newName, value})
end

function build_ddns_parameters(data, ddnsdomain)
	local paras = {}

	add_one_ddns_parameter(paras, "Enable", utils.toboolean(data["Enable"]), ddnsdomain)
	if not utils.toboolean(data["Enable"]) then
		return paras
	end

	add_one_ddns_parameter(paras, "Provider", data["Provider"], ddnsdomain)
	add_one_ddns_parameter(paras, "HostName", data["HostName"], ddnsdomain)
	add_one_ddns_parameter(paras, "DomainName", data["DomainName"], ddnsdomain)

	add_one_ddns_parameter(paras, "Username", data["Username"], ddnsdomain)
        if true == utils.toboolean(web.getparaenc()) then
            if nil ~= data["Password"] then
                local newpara = web.decodepara(data["Password"])
                if "" ~= newpara then
                    data["Password"] = newpara
                end
            end      
        end 
	if data["Password"] ~= _G["defaultPasswd"] then
		add_one_ddns_parameter(paras, "Password", data["Password"], ddnsdomain)
	end
	if "TZO.com" == data["Provider"] then
		add_one_ddns_parameter(paras, "Protocol", "TZO", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "cgi.tzo.com", ddnsdomain)
	end
	if (("DynDNS.org" == data["Provider"]) or ("Dyn.com" == data["Provider"])) then
		add_one_ddns_parameter(paras, "Protocol", "dyndns", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "DynDNS.org", ddnsdomain)
	end
	if ("No-IP.com" == data["Provider"]) then
		add_one_ddns_parameter(paras, "Protocol", "no-ip.com", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "No-IP.com", ddnsdomain)
	end
	if ("DtDNS.com" == data["Provider"]) then
		add_one_ddns_parameter(paras, "Protocol", "dtdns.com", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "DtDNS.com", ddnsdomain)
	end
	if ("Zoneedit.com" == data["Provider"]) then
		add_one_ddns_parameter(paras, "Protocol", "zoneedit.com", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "Zoneedit.com", ddnsdomain)
	end	
	if ("Selfhost.de" == data["Provider"]) then
		add_one_ddns_parameter(paras, "Protocol", "selfhost.de", ddnsdomain)
		add_one_ddns_parameter(paras, "Server", "Selfhost.de", ddnsdomain)
	end				
	return paras
end

local ddnsdomain = get_first_ddns_entry(all_ddns)
local paras = build_ddns_parameters(data, ddnsdomain)
local maps = {
    Provider = "Provider",
    HostName = "HostName",
    DomainName = "DomainName",
    Username = "Username",
    Password = "Password",
    Status = "Status"
}

local errcode = 0
if "" == ddnsdomain then
	-- Add ddns entry
	errcode,instId,needreboot,errs = dm.AddObjectWithValues("InternetGatewayDevice.Services.X_DDNSConfiguration.", paras)
	if errcode ~= 0 then
        utils.responseErrorcode(errcode, errs, maps)
        return errcode
    end
    utils.appenderror("errcode", 0)
else
	-- Update ddns entry
	errcode,needreboot, paramerror = dm.SetParameterValues(paras);
	utils.responseErrorcode(errcode, paramerror, maps)
end
