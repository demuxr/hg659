
    require('dm')
    require('web')
    require('json')
    require('utils')
    local tostring = tostring

    local errcode,radvdst = dm.GetParameterValues("InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.", 
            {"RouterAdvertisementEnable", "UseAllocatedWAN", "Prefix", "PrefixLength", "Preferredlifetime",
             "Validlifetime","ULAAllocatedMode","ULAPrefix","ULAPrefixLength","ULAPreferredlifetime","ULAValidlifetime","MOFlagAutoMode","ManagedFlag","OtherConfigFlag"});

    local radvdserver = {}
	for k,v in pairs(radvdst) do
        radvdserver.ID = k
        radvdserver.RouterAdvertisementEnable = utils.toboolean(v["RouterAdvertisementEnable"]) 
        radvdserver.UseAllocatedWAN = v["UseAllocatedWAN"] 
        radvdserver.AssociatedConnection = v["AssociatedConnection"]
        radvdserver.Prefix = v["Prefix"]
        radvdserver.PrefixLength = v["PrefixLength"]
        radvdserver.Preferredlifetime = v["Preferredlifetime"]
        radvdserver.Validlifetime = v["Validlifetime"]
        radvdserver.Interface = ""
        radvdserver.MaxRtrAdvInterval = ""
        radvdserver.MinRtrAdvInterval = ""
        radvdserver.DefaultLifetime = ""
        radvdserver.MOFlagAutoMode = v["MOFlagAutoMode"]
        radvdserver.ManagedFlag = v["ManagedFlag"]
        radvdserver.OtherConfigFlag = v["OtherConfigFlag"]
        radvdserver.MobileAgentFlag = ""
        radvdserver.PreferredRouterFlag = ""
        radvdserver.NDProxyFlag = ""
        radvdserver.LinkMTU = ""
        radvdserver.ReachableTime = ""
        radvdserver.RetransTimer = ""
        radvdserver.CurHopLimit = ""
        radvdserver.ULAAllocatedMode = v["ULAAllocatedMode"]
        radvdserver.ULAPrefix = v["ULAPrefix"]
        radvdserver.ULAPrefixLength = v["ULAPrefixLength"] 
        radvdserver.ULAPreferredlifetime = v["ULAPreferredlifetime"] 
        radvdserver.ULAValidlifetime = v["ULAValidlifetime"]
    end

 web.print(json.encode(radvdserver))