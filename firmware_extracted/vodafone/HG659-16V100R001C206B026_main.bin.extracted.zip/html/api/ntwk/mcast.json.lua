
require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,igmp= dm.GetParameterValues("InternetGatewayDevice.Services.X_IPTV.",
    {"IGMPProxyEnable", "IGMPSnoopingEnable", "WanList"})
igmp_obj = igmp["InternetGatewayDevice.Services.X_IPTV."];

local errcode,mld= dm.GetParameterValues("InternetGatewayDevice.Services.X_IPTV6.",
     {"MLDProxyEnable", "MLDSnoopingEnable", "Wan6List"})
mld_obj = mld["InternetGatewayDevice.Services.X_IPTV6."];

local mcast = {}
mcast.IGMPSnoopingEnable = utils.toboolean(igmp_obj["IGMPSnoopingEnable"]);
mcast.IGMPProxyEnable = utils.toboolean(igmp_obj["IGMPProxyEnable"]);
mcast.IGMPWan = igmp_obj["WanList"];
mcast.MLDSnoopingEnable = utils.toboolean(mld_obj["MLDSnoopingEnable"]);
mcast.MLDProxyEnable = utils.toboolean(mld_obj["MLDProxyEnable"]);
mcast.MLDWan = mld_obj["Wan6List"];

web.print(json.encode(mcast))
