require('dm')
require('web')
require('json')
require('utils')

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.ACL.{i}.", {"X_Service","X_Direction","X_StartIpAddr","X_MacAddr","X_EndIpAddr"})

local errcode, hostobjs = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.Hosts.Host.{i}.", {"MACAddress"});

function parsemacs(key, srcmac)
    local start = 1
    local devices = {}
    while true do
        ip, fp = string.find(srcmac, "|", start)
        if not ip then
            local mac = {}
            mac[key] = string.sub(srcmac, start)
            table.insert(devices, mac)
            break
        end
        local mac = {}
        mac[key] = string.sub(srcmac, start, ip-1)
        table.insert(devices, mac)
        start = fp +1
    end
    return devices
end

--return mac address list in host
function getmacinHost(key, srcmac)
    local start = 1
    local devices = {}
    while true do
        ip, fp = string.find(srcmac, "|", start)
        if not ip then
            local mac = {}
            mac[key] = string.sub(srcmac, start)
            for k,v in pairs(hostobjs) do
                if v["MACAddress"] == mac[key] then
                    table.insert(devices, mac)
                end 
            end
            break
        end
        local mac = {}
        mac[key] = string.sub(srcmac, start, ip-1)
        for kk,vv in pairs(hostobjs) do
            if vv["MACAddress"] == mac[key] then
                table.insert(devices, mac)
            end 
        end
        start = fp +1
    end
    return devices
end

--return mac address not in host mac list
function isMenualSetACLMac(hostobj,aclmac)
    --first get all mac address in aclmac
    local menusetmac = ""
    
    if aclmac == "" then
        return false
    end
    local allAclMacAddr = parsemacs("MACAddress",aclmac)
    --second get one aclmac not in  allAclMacAddr
    local exitflag = false
    --if true explain not in host
    for kk,vv in pairs(allAclMacAddr) do
        for k,v in pairs(hostobj) do
            if vv["MACAddress"] == v["MACAddress"] then
                exitflag = true
                break
            end
        end
    end
    return true
end

local login_user, login_level = web.getuserinfo()

local acllist = {}

for k,v in pairs(objs) do
    local aclitem = {}
    aclitem["ID"] = k
    aclitem["ServiceType"] = v["X_Service"]
    aclitem["AccessDirection"] = v["X_Direction"]
    aclitem["StartIpAddr"] = v["X_StartIpAddr"]
    aclitem["EndIpAddr"] = v["X_EndIpAddr"]
    --get lan host in hosts nodes
    aclitem["MacAddrinHost"] = getmacinHost("MACAddress",v["X_MacAddr"])
    --get user if setmenual setmac address and mac address
    aclitem["isMenualSetMac"] = isMenualSetACLMac(hostobjs,v["X_MacAddr"])
    -- Not display default wan side http acl rule, can not del or modify
    if (("HTTP" == aclitem["ServiceType"]) and ("WAN" == aclitem["AccessDirection"]) and 
        (("202.73.206.161" == aclitem["StartIpAddr"]) or ("202.73.198.161" == aclitem["StartIpAddr"]) or 
        ("116.89.224.160" == aclitem["StartIpAddr"]) or ("203.144.40.160" == aclitem["StartIpAddr"]))) then
        -- Default wan side http acl rule, not display
    else
        table.insert(acllist, aclitem)
    end
end
web.print(json.encode(acllist))