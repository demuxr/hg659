local utils = require('utils')
require('dm')
local string = string

local maps = {
    Name="Name",
    Status = "Status",
    Protocol = "Protocol",
    SourceIPStart = "SourceIPStart",
    SourceIPEnd = "SourceIPEnd",
    DestIPStart = "DestIPStart",
    DestIPEnd = "DestIPEnd",
    SourcePortStart = "SourcePortStart",
    SourcePortEnd = "SourcePortEnd",
    DestPortStart = "DestPortStart",
    DestPortEnd = "DestPortEnd",
    Interface = "Interface"
}

function create()
    -- add 
    local paras = utils.GenAddObjParamInputs(data, maps)
    local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.X_FireWall.IpFilter.", paras);
    utils.responseErrorcode(errcode, paramerr, maps)

    return errcode
end

function delete()
    return dm.DeleteObject(data["ID"])
end

function update()
    local domain = data["ID"]
    local paras = utils.GenSetObjParamInputs(domain, data, maps)

    local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
    utils.responseErrorcode(errcode, paramerr, maps)

    return errcode
end

if action == 'create' then
    err = create()
elseif action == 'update' then
    err = update()
elseif action == 'delete' then
    err = delete()
else
    return
end

utils.appenderror("errcode", err)