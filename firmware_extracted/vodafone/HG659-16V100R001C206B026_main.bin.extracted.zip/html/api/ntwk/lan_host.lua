local utils = require('utils')
require('web')

--local data = utils.getRequestFormData()
if "" == data["DevName"] then
    utils.appenderror("DevName", "Menu.domain_err")
else
    local maps = {
    	FristIP = "IPInterfaceIPAddress",
    	FirstMac = "IPInterfaceSubnetMask"
    }

    function add_one_lan_host_parameter(paras, name, value)
        table.insert(paras, {name, value})
    end

    function build_lan_host_parameters()
        local paras = {}
        add_one_lan_host_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.IPInterfaceIPAddress", data["FristIP"])
        add_one_lan_host_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1.IPInterfaceSubnetMask", data["FirstMac"])
        if data["ShowLanDomainEnable"] then
            add_one_lan_host_parameter(paras, "InternetGatewayDevice.Services.X_LanDomainManage.Enable", utils.booleantoint(data["LanDomainEnable"]))
        end
        return paras
     end

    local paras = build_lan_host_parameters()

    local errcode = 0
    errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
    if errcode ~= 0 then
        utils.responseErrorcode(errcode, paramerr, maps)
    end

    local devmaps = {
        DevName = "DeviceName"
    }

    local devparas = {}
    table.insert(devparas, {"InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.DeviceName", data["DevName"]})
    err,needreboot, paramerror = dm.SetParameterValues(devparas)
    utils.responseErrorcode(err, paramerror, devmaps)

    if data["needReboot"] then
        web.rebootdevice()
    end
end