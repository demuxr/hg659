require('dm')
require('web')
require('json')
require('utils')

local errcode, ipif_objs = dm.GetParameterValues("InternetGatewayDevice.LANDevice.{i}.LANHostConfigManagement.IPInterface.{i}.", {"IPInterfaceIPAddress", "IPInterfaceSubnetMask"})

local ipifs = {}
if ipif_objs ~= nil then
    for k,v in pairs(ipif_objs) do
        local newObj = {}
        newObj["ID"] = k
        if k ~= "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.IPInterface.1." then
            newObj["ipifaddr"] = v["IPInterfaceIPAddress"]
            newObj["ipifmask"] = v["IPInterfaceSubnetMask"]
            table.insert(ipifs, newObj)
        end
    end
    utils.multiObjSortByID(ipifs)
end


web.print(json.encode(ipifs))