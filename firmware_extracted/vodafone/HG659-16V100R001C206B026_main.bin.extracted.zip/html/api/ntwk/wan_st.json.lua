
local print = print
require('dm')
require('utils')
require('web')
require('json')
function table_is_empty(t)

        return _G.next( t ) == nil

end
function GetWanAllList(wanAllList,wanList)
	if table_is_empty(wanList) then
		return
	end
	for k,v in pairs(wanList) do
		local wanitem = {}
		local startIndex = string.find(k,"Stats.")
		local perfixDomain = string.sub(k,1,startIndex-1)
		local errcode, wanName = dm.GetParameterValues(perfixDomain,{"X_WanAlias"})

		for kk,vv in pairs(wanName) do
			wanitem["Name"] = vv["X_WanAlias"]
		end
		if ((nil == wanitem["Name"]) or ('' == wanitem["Name"])) then
			local errcode, wanName = dm.GetParameterValues(perfixDomain,{"Name"})
		
			for kk,vv in pairs(wanName) do
				wanitem["Name"] = vv["Name"]
			end
		end
		wanitem["ID"] = k
		wanitem["sendbytes"] = v["EthernetBytesSent"]
		wanitem["receivebytes"] = v["EthernetBytesReceived"]
		wanitem["sendpacket"] = v["EthernetPacketsSent"]
		wanitem["receivepacket"] = v['EthernetPacketsReceived']
		wanitem["senderror"] = v["EthernetErrorsSent"]
		wanitem["receiveerror"] = v["EthernetErrorsReceived"]
		wanitem["senddiscard"] = v["EthernetDiscardPacketsSent"]
		wanitem["receivediscard"] = v["EthernetDiscardPacketsReceived"]
		table.insert(wanAllList, wanitem)
	end
end
local maps = {"EthernetBytesSent","EthernetBytesReceived","EthernetPacketsSent",'EthernetPacketsReceived',"EthernetErrorsSent","EthernetErrorsReceived","EthernetDiscardPacketsSent","EthernetDiscardPacketsReceived"}
local wanAllst ={}
local errcode, wanIPSt = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}." .. "Stats.",
    maps)
GetWanAllList(wanAllst,wanIPSt)

local errcode, wanPPPSt = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}." .. "Stats.",
   maps)
GetWanAllList(wanAllst,wanPPPSt)

web.print(json.encode(wanAllst))