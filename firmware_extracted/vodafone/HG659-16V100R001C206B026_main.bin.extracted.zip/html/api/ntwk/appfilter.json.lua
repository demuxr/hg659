require('dm')
require('web')
require('json')
require('utils')

function parsemacs(key, srcmac)
	local start = 1
	local devices = {}
	while true do
		ip, fp = string.find(srcmac, "|", start)
		if not ip then
			local mac = {}
			mac[key] = string.sub(srcmac, start)
			table.insert(devices, mac)
			break
		end
		local mac = {}
		mac[key] = string.sub(srcmac, start, ip-1)
		table.insert(devices, mac)
		start = fp +1
	end

	return devices
end

local errcode, objs = dm.GetParameterValues("InternetGatewayDevice.X_FireWall.DevRule.{i}.", 
    {"Name", "Enable", "ApplicationIDs", "DevMac"});

local appfilter = {}

if objs ~= nil then
	for k,v in pairs(objs) do
	    local newObj = {}
	    newObj["ID"] = k
	    newObj["RuleName"] = v["Name"]
	    newObj["Enable"] = utils.toboolean(v["Enable"])
	    newObj["Devices"] = parsemacs("MACAddress", v["DevMac"])
	    newObj["Applications"] = parsemacs("ID", v["ApplicationIDs"])
		table.insert(appfilter, newObj)
	end
end
utils.multiObjSortByID(appfilter)
web.print(json.encode(appfilter))
