require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local tonumber = tonumber

local type = 'all'
local showpass = true

if FormData["frequency"] ~= nil then
    type = FormData["frequency"]
end

if FormData["showpass"] ~= nil and FormData["showpass"] == "false" then
    showpass = false
end

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand"
    }
);

function get_WifiEnable(frequency)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return utils.toboolean(v["Enable"])
        end
    end

    return false
end

local errcode,wlanBasic = dm.GetParameterValues("InternetGatewayDevice.LANDevice.2.WLANConfiguration.{i}.",
    {
        "Enable",
        "X_OperatingFrequencyBand",
        "SSID",
        "BeaconType",
        "BasicEncryptionModes",
        "BasicAuthenticationMode",
        "WPAEncryptionModes",
        "IEEE11iEncryptionModes",
        "X_MixedEncryptionModes",             
    }
);

local wlanCfgs = {}
function calc_min(frequency)
    local array = {}
    i = 1
    if wlanBasic ~= nil then 
        for k,v in pairs(wlanBasic) do
            if frequency == v["X_OperatingFrequencyBand"] then
                wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end    
        end
        table.sort(array)
        if 1 == i  then
            return -1    
        else
            return array[1]
        end    
    end    
    return -1
end

wlan_index = calc_min("2.4GHz")
find_index = false
local enable = false
local wifienable = false

wlan_5gindex = calc_min("5GHz")
find_5gindex = false
local enable5g = false
local wifienable5g = false

local wlanInstance = {}
for k,v in pairs(wlanBasic) do
    wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
    if wlan_index == tonumber(wlan_instance_id)  or wlan_5gindex == tonumber(wlan_instance_id)  then
        wpakey_conf_str = k.."PreSharedKey.1."
        local err_wpakey, wap_key_data = dm.GetParameterValues(wpakey_conf_str, { "PreSharedKey", "KeyPassphrase" });
        for kk, vv in pairs(wap_key_data) do
                WpaPreSharedKey = vv["KeyPassphrase"]
            break
        end
        if wlan_index == tonumber(wlan_instance_id) then
            wlanInstance["ssid2g"] = v["SSID"]
            if "11i" == v["BeaconType"] and "AESEncryption" == v["IEEE11iEncryptionModes"] then
                wlanInstance["SecOpt2g"] = "aes" 
            elseif "WPAand11i" == v["BeaconType"] and "TKIPandAESEncryption" == v["X_MixedEncryptionModes"]  then
                wlanInstance["SecOpt2g"] = "tkip"
            else
                wlanInstance["SecOpt2g"] = "none"
            end  
            wlanInstance["WpaPreSharedKey2g"] = WpaPreSharedKey 
        end 
        if wlan_5gindex == tonumber(wlan_instance_id) then
            wlanInstance["ssid5g"] = v["SSID"]
            if "11i" == v["BeaconType"] and "AESEncryption" == v["IEEE11iEncryptionModes"] then
                wlanInstance["SecOpt5g"] = "aes" 
            elseif "WPAand11i" == v["BeaconType"] and "TKIPandAESEncryption" == v["X_MixedEncryptionModes"]  then
                wlanInstance["SecOpt5g"] = "tkip"
            else
                wlanInstance["SecOpt5g"] = "none"
            end  
            wlanInstance["WpaPreSharedKey5g"] = WpaPreSharedKey 
        end
        local WifiEnable = get_WifiEnable(v["X_OperatingFrequencyBand"]) 
        if wlan_index == tonumber(wlan_instance_id) then
            wifienable = WifiEnable
        else
            wifienable5g = WifiEnable
        end    
        local SsidEnable = utils.toboolean(v["Enable"])
        if true == WifiEnable and true == SsidEnable then
            if wlan_index == tonumber(wlan_instance_id) then
                enable = true
            else
                enable5g = true
            end    
        else
            if wlan_index == tonumber(wlan_instance_id) then
                enable = false
            else               
                enable5g = false
            end          
        end    
    end   
end     
local wlanCfgs = {}
function make_guest_network_data(frequency)
    if frequency == "2.4GHz" then
        wlanCfgs.EnableFrequency = enable
        wlanCfgs.WifiSsid = wlanInstance["ssid2g"]
        wlanCfgs.SecOpt = wlanInstance["SecOpt2g"]
        if showpass == true then
            wlanCfgs.WpaPreSharedKey = wlanInstance["WpaPreSharedKey2g"]
        else
            wlanCfgs.WpaPreSharedKey = _G["defaultPasswd"]
        end
        wlanCfgs.ID = "InternetGatewayDevice.LANDevice.2.WLANConfiguration."..tostring(wlan_index).."."
        wlanCfgs.FrequencyBand = "2.4GHz"
        wlanCfgs.CanEnableFrequency = wifienable
    else
        wlanCfgs.EnableFrequency = enable5g
        wlanCfgs.WifiSsid = wlanInstance["ssid5g"]
        wlanCfgs.SecOpt = wlanInstance["SecOpt5g"]
        if showpass == true then
            wlanCfgs.WpaPreSharedKey = wlanInstance["WpaPreSharedKey5g"]
        else
            wlanCfgs.WpaPreSharedKey = _G["defaultPasswd"]
        end
        wlanCfgs.ID = "InternetGatewayDevice.LANDevice.2.WLANConfiguration."..tostring(wlan_5gindex).."."
        wlanCfgs.FrequencyBand = "5GHz"
        wlanCfgs.CanEnableFrequency = wifienable5g
    end    

end

if "2.4GHz" == type then
    make_guest_network_data("2.4GHz")
    web.print(json.encode(wlanCfgs))
end
if "5GHz" == type then
    make_guest_network_data("5GHz")
    web.print(json.encode(wlanCfgs))
end 
if "all" == type then
    local guestdata = {}
    make_guest_network_data("2.4GHz")
    table.insert(guestdata, wlanCfgs)
    wlanCfgs = {}
    make_guest_network_data("5GHz")
    table.insert(guestdata, wlanCfgs)
    web.print(json.encode(guestdata))
end 


