require('web')

local err = web.gmsgsend("wlancms", 1, {})
utils.appenderror("errcode", err)