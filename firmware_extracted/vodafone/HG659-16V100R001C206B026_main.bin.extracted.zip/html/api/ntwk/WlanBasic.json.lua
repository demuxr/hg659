require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring
local tonumber = tonumber

local showpass = true

if FormData["frequency"] ~= nil then
    frequency = FormData["frequency"]
end

if FormData["showpass"] ~= nil and FormData["showpass"] == "false" then
    showpass = false
end

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
    {
        "Enable",
        "OperatingFrequencyBand"
    }
);

function get_WifiEnable(frequency)
    for k, v in pairs(wifiConf) do
        if frequency == v["OperatingFrequencyBand"] then
            return utils.toboolean(v["Enable"])
        end
    end

    return false
end

local domain = "InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}."

local errcode,wlanBasic = dm.GetParameterValues(domain,
    {
        "Enable",
        "X_OperatingFrequencyBand",
        "RegulatoryDomain",
        "Channel",
        "AutoChannelEnable",
        "X_WlanStandard",
        "MaxBitRate",
        "TransmitPower",
        "SSID",
        "SSIDAdvertisementEnabled",
        "X_WlanIsolateControl",
        "WMMEnable",
        "X_Wlan11NHtMcs",
        "X_Wlan11NBWControl",
        "X_Wlan11NGIControl",
        "X_AssociateDeviceNum",
        "BeaconType",
        "BasicEncryptionModes",
        "BasicAuthenticationMode",
        "WEPEncryptionLevel",
        "WEPKeyIndex",
        "WPAEncryptionModes",
        "IEEE11iEncryptionModes",
        "X_MixedEncryptionModes",     
        "X_Wlan11NTxRxStream"
    }
);

local wlanCfgs = {}
function calc_min(frequency)
    local array = {}
    i = 1
    if wlanBasic ~= nil then 
        for k,v in pairs(wlanBasic) do
            if frequency == v["X_OperatingFrequencyBand"] then
                wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
                array[i] = tonumber(wlan_instance_id)
                i = i+1
            end    
        end
        table.sort(array)
        if 1 == i  then
            return -1    
        else
            return array[1]
        end    
    end    
    return -1
end

wlan_index = calc_min("2.4GHz")

wlan_5gindex = calc_min("5GHz")

function isValidIndex(k)
    local  wlan_instance_id, wlan_suffix = utils.findLastPoint(k)
    if wlan_index == tonumber(wlan_instance_id)  or wlan_5gindex == tonumber(wlan_instance_id)  then
        return true
    end

    return false
end

local domainFonap = "InternetGatewayDevice.Services.X_FonAP."
local errFonap,valuesFonap = dm.GetParameterValues(domainFonap, {"Enabled"})

local objFonap = valuesFonap[domainFonap]

for k,v in pairs(wlanBasic) do
    
   if isValidIndex(k) then
        local WepKey = {}
        wepkey_conf_str = k.."WEPKey."..tostring(v["WEPKeyIndex"]).."."
        local err_wep, wep_data = dm.GetParameterValues(k.."WEPKey.{i}.", { "WEPKey" });
        for kk, vv in pairs(wep_data) do
            wep_instance_id, wep_suffix = utils.findLastPoint(kk)
            if showpass == true then
                WepKey[wep_instance_id] = vv["WEPKey"]
            else
                WepKey[wep_instance_id] = _G["defaultPasswd"]
            end
        end
		local X_WlanRadius = {}
        local err_radius, radius_data = dm.GetParameterValues(k.."X_WlanRadius.{i}.", { "RadiusServer","RadiusPort","RadiusKey"});
        for kk, vv in pairs(radius_data) do
			local Radius_info = {}
			radius_instance_id, radius_suffix = utils.findLastPoint(kk)
			Radius_info.ID = k.."X_WlanRadius."..radius_instance_id.."."
            Radius_info.RadiusServer = vv["RadiusServer"]
            Radius_info.RadiusPort = vv["RadiusPort"]
            if showpass == true then 
                Radius_info.RadiusKey = vv["RadiusKey"]
            else
                Radius_info.RadiusKey = _G["defaultPasswd"]
            end
			table.insert(X_WlanRadius,Radius_info);
		end	
        utils.multiObjSortByID(X_WlanRadius)	
        wpakey_conf_str = k.."PreSharedKey.1."
        local err_wpakey, wap_key_data = dm.GetParameterValues(wpakey_conf_str, { "PreSharedKey", "KeyPassphrase" });
        for kk, vv in pairs(wap_key_data) do
            if showpass == true then 
                WpaPreSharedKey = vv["KeyPassphrase"]   
            else
                WpaPreSharedKey = _G["defaultPasswd"]
            end
            break
        end

        local wlanInstance = {}

        wlanInstance.ID = k
        wlanInstance.fonenable = objFonap["Enabled"]
        wlanInstance.FrequencyBand = v["X_OperatingFrequencyBand"]
        wlanInstance.WifiEnable = get_WifiEnable(v["X_OperatingFrequencyBand"])
        wlanInstance.RegulatoryDomain = v["RegulatoryDomain"]
        if utils.toboolean(v["AutoChannelEnable"]) == true then 
            wlanInstance.Channel = 0
        else
            wlanInstance.Channel = v["Channel"]
        end    
        wlanInstance.ChannelOldValue = wlanInstance.Channel
        wlanInstance.WlanStandard = v["X_WlanStandard"]
        wlanInstance.WlanStandardOldValue = wlanInstance.WlanStandard
        if "Auto" == v["MaxBitRate"] then
            wlanInstance.MaxBitRate = "0"
        else
            wlanInstance.MaxBitRate = v["MaxBitRate"]
        end    
        wlanInstance.MaxBitRateOldValue = wlanInstance.MaxBitRate
        wlanInstance.TransmitPower = v["TransmitPower"]
        wlanInstance.TransmitPowerOldValue = wlanInstance.TransmitPower
        wlanInstance.WifiSsidEnable = utils.toboolean(v["Enable"])
        wlanInstance.WifiSsid = v["SSID"]
        wlanInstance.WifiHideBroadcast = utils.opsiteBoolVal(v["SSIDAdvertisementEnabled"])
        wlanInstance.X_WlanIsolateControl = utils.toboolean(v["X_WlanIsolateControl"])
        wlanInstance.WMMEnable = utils.toboolean(v["WMMEnable"])
        wlanInstance.WMMEnableOldValue = wlanInstance.WMMEnable
        if 33 == v["X_Wlan11NHtMcs"] then
            wlanInstance.X_Wlan11NHtMcs = "auto"
        else    
            wlanInstance.X_Wlan11NHtMcs = v["X_Wlan11NHtMcs"]
        end
        wlanInstance.X_Wlan11NHtMcsOldValue = wlanInstance.X_Wlan11NHtMcs
        if "20/40" == v["X_Wlan11NBWControl"] then
            wlanInstance.X_Wlan11NBWControl = "20_40"
        else    
            wlanInstance.X_Wlan11NBWControl = v["X_Wlan11NBWControl"]
        end    
        wlanInstance.X_Wlan11NBWControlOldValue = wlanInstance.X_Wlan11NBWControl
        wlanInstance.X_Wlan11NGIControl = v["X_Wlan11NGIControl"]
        wlanInstance.X_Wlan11NGIControlOldValue = wlanInstance.X_Wlan11NGIControl
        wlanInstance.X_AssociateDeviceNum = v["X_AssociateDeviceNum"]
        wlanInstance.X_Wlan11NTxRxStream = v["X_Wlan11NTxRxStream"]
        if "Basic" == v["BeaconType"] and "None" == v["BasicEncryptionModes"] then
            wlanInstance.BeaconType = "None"
        else
            wlanInstance.BeaconType = v["BeaconType"]
        end    
        wlanInstance.BasicEncryptionMode = v["BasicEncryptionModes"]
        wlanInstance.BasicAuthMode = v["BasicAuthenticationMode"]
        if "40-bit" == v["WEPEncryptionLevel"] then
            wlanInstance.WepKeyLen = 64
        end
        if "104-bit" == v["WEPEncryptionLevel"] then
            wlanInstance.WepKeyLen = 128  
        end 
        wlanInstance.WepKeyIndex = v["WEPKeyIndex"]
        wlanInstance.WepKey = WepKey
        wlanInstance.WpaPreSharedKey = WpaPreSharedKey
        if "TKIPEncryption" == v["WPAEncryptionModes"] then
            wlanInstance.WpaEncryptionMode = "TKIP"
        end
        if "AESEncryption" == v["WPAEncryptionModes"] then
            wlanInstance.WpaEncryptionMode = "AES"
        end    
        if "TKIPandAESEncryption" == v["WPAEncryptionModes"] then
            wlanInstance.WpaEncryptionMode = "TKIP+AES"
        end    
        if "TKIPEncryption" == v["IEEE11iEncryptionModes"] then
            wlanInstance.IEEEiEncryptionMode = "TKIP"
        end
        if "AESEncryption" == v["IEEE11iEncryptionModes"] then
            wlanInstance.IEEEiEncryptionMode = "AES"
        end    
        if "TKIPandAESEncryption" == v["IEEE11iEncryptionModes"] then
            wlanInstance.IEEEiEncryptionMode = "TKIP+AES"
        end 
        if "TKIPEncryption" == v["X_MixedEncryptionModes"] then
            wlanInstance.MixedEncryptionModes = "TKIP"
        end
        if "AESEncryption" == v["X_MixedEncryptionModes"] then
            wlanInstance.MixedEncryptionModes = "AES"
        end    
        if "TKIPandAESEncryption" == v["X_MixedEncryptionModes"] then
            wlanInstance.MixedEncryptionModes = "TKIP+AES"
        end 
        wlanInstance.X_WlanRadius = X_WlanRadius
        table.insert(wlanCfgs, wlanInstance)
    end   
end

utils.multiObjSortByID(wlanCfgs)

local i2G = 1
local i5G = 1
for k, v in pairs(wlanCfgs) do
    if v['FrequencyBand'] == '5GHz' then
        v['SSIDIndex'] = i5G
        i5G = i5G + 1
    else
        v['SSIDIndex'] = i2G
        i2G = i2G + 1
    end
end

web.print(json.encode(wlanCfgs))