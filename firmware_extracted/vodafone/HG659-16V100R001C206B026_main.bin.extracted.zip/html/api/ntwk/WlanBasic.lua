local utils = require('utils')
local print = print
local tostring = tostring

local maps = {
    wepkey = "WEPKey",
    wpakey = "KeyPassphrase",
    WifiEnable = "Enable",
    WifiSsid = "SSID",
    BeaconType = "BeaconType",
    BasicEncryptionMode = "BasicEncryptionModes",
    BasicAuthMode = "BasicAuthenticationMode",
    WpaEncryptionMode = "WPAEncryptionModes",
    IEEEiEncryptionMode = "IEEE11iEncryptionModes",
    MixedEncryptionModes = "X_MixedEncryptionModes",
    RadiusServer = "X_RadiusServer",
    Radiusport = "X_RadiusPort"
};

local sendsetting_maps = {
    RegulatoryDomain = "RegulatoryDomain",
    TransmitPower = "TransmitPower",
    X_WlanIsolateControl = "X_WlanIsolateControl",
    WifiHideBroadcast = "SSIDAdvertisementEnabled",
    WlanStandard = "X_WlanStandard",
    X_Wlan11NHtMcs = "X_Wlan11NHtMcs",
    X_Wlan11NBWControl = "X_Wlan11NBWControl",
    X_Wlan11NTxRxStream = "X_Wlan11NGIControl",
    MaxBitRate = "MaxBitRate",
    WMMEnable = "WMMEnable",
    Channel = "Channel"
};

function add_one_wlan_parameter(paras, name, value)
    if nil == value then 
        return
    end     
    table.insert(paras, {name, value})
end

function getindexwepkey(curdata)
    local index = 0
    local wepkeys = {}
    if nil ~= curdata["wepkey"] then
        index = curdata["wepkeyindex"]       
        return curdata["wepkey"][tostring(index)]
    end
    return nil
end
function SetRadiusValue(paras,wlancfg,curdata)
	if nil ~= curdata["X_WlanRadius"] then
		for k, v in pairs(curdata["X_WlanRadius"]) do
            
			if nil ~= v["ID"] then
				if 0 ~= v["ID"] then
					local radiusid = v["ID"]
					add_one_wlan_parameter(paras, radiusid.."RadiusServer", v["RadiusServer"])
					add_one_wlan_parameter(paras, radiusid.."RadiusPort", v["RadiusPort"])
                                        if nil ~= v["RadiusKey"] then
                                            if v["RadiusKey"] ~= _G["defaultPasswd"] then
                                                add_one_wlan_parameter(paras, radiusid.."RadiusKey", v["RadiusKey"])
                                            end
                                        end
				end
			end
		end
	end
end

function submit_ssidsetting_data(paras, curdata)
    if nil == curdata then
        return
    end
    if nil == curdata["ID"] then 
        return 
    end    
    if 0 ~= curdata["ID"] then
        local wlancfg = curdata["ID"]
        add_one_wlan_parameter(paras, wlancfg.."SSID", curdata["ssid"])
        add_one_wlan_parameter(paras, wlancfg.."Enable", curdata["ssidenable"])
        add_one_wlan_parameter(paras, wlancfg.."BeaconType", curdata["beacontype"])
        if curdata["mode"] ~= nil then
            add_one_wlan_parameter(paras, wlancfg.."X_WlanStandard", curdata["mode"])
        end
        if curdata["beacontype"] == "Basic" then
            add_one_wlan_parameter(paras, wlancfg.."BasicEncryptionModes", curdata["basicencmode"])
            if curdata["basicencmode"] == "WEPEncryption" then
                add_one_wlan_parameter(paras, wlancfg.."BasicAuthenticationMode", curdata["basicauthmode"])
                add_one_wlan_parameter(paras, wlancfg.."WEPKeyIndex", curdata["wepkeyindex"])
                if _G["defaultPasswd"] ~= getindexwepkey(curdata) then
                    add_one_wlan_parameter(paras, wlancfg.."WEPKey."..tostring(curdata["wepkeyindex"])..".WEPKey", getindexwepkey(curdata))
                end
            else
                add_one_wlan_parameter(paras, wlancfg.."BasicAuthenticationMode", "None")
            end
        end
        if curdata["beacontype"] == "WPA" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "TKIPandAESEncryption")
            end
            if curdata["wpakey"] ~= _G["defaultPasswd"] then
                if nil ~= curdata["wpakey"] then
                    if 64 == string.len(curdata["wpakey"]) then
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.PreSharedKey", curdata["wpakey"])
                    else
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.KeyPassphrase", curdata["wpakey"])
                    end
                end
            end
        end
        if curdata["beacontype"] == "11i" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "TKIPandAESEncryption")
            end
            if curdata["wpakey"] ~= _G["defaultPasswd"] then
                if nil ~= curdata["wpakey"] then
                    if 64 == string.len(curdata["wpakey"]) then
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.PreSharedKey", curdata["wpakey"])
                    else
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.KeyPassphrase", curdata["wpakey"])
                    end
                end
            end
        end
        if curdata["beacontype"] == "WPAand11i" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "TKIPandAESEncryption")
            end
            if curdata["wpakey"] ~= _G["defaultPasswd"] then
                if nil ~= curdata["wpakey"] then
                    if 64 == string.len(curdata["wpakey"]) then
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.PreSharedKey", curdata["wpakey"])
                    else
                        add_one_wlan_parameter(paras, wlancfg.."PreSharedKey.1.KeyPassphrase", curdata["wpakey"])
                    end
                end
            end
        end
        if curdata["beacontype"] == "8021X" then
            add_one_wlan_parameter(paras, wlancfg.."BasicEncryptionModes", curdata["basicencmode"])
            add_one_wlan_parameter(paras, wlancfg.."BasicAuthenticationMode", curdata["basicauthmode"])
            add_one_wlan_parameter(paras, wlancfg.."WEPKeyIndex", curdata["wepkeyindex"])
            if _G["defaultPasswd"] ~= getindexwepkey(curdata) then
                add_one_wlan_parameter(paras, wlancfg.."WEPKey."..tostring(curdata["wepkeyindex"])..".WEPKey", getindexwepkey(curdata))
            end
			SetRadiusValue(paras,wlancfg,curdata)
        end
        if curdata["beacontype"] == "WPA-EAP" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."WPAEncryptionModes", "TKIPandAESEncryption")
            end
            SetRadiusValue(paras,wlancfg,curdata)
        end
        if curdata["beacontype"] == "WPA2-EAP" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."IEEE11iEncryptionModes", "TKIPandAESEncryption")
            end
            SetRadiusValue(paras,wlancfg,curdata)
        end
        if curdata["beacontype"] == "WPAWPA2-EAP" then
            if curdata["wpaencmode"] == "TKIP" then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "TKIPEncryption")
            end
            if curdata["wpaencmode"] == "AES" then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "AESEncryption")
            end
            if curdata["wpaencmode"] == "TKIP+AES"  then
                add_one_wlan_parameter(paras, wlancfg.."X_MixedEncryptionModes", "TKIPandAESEncryption")
            end
            SetRadiusValue(paras,wlancfg,curdata)
        end
    end
end


function submit_sendsetting_data(paras, curdata, is5g)
    if nil == curdata then
        return
    end
    if nil == curdata["ID"] then
        return 
    end    
    if 0 ~= curdata["ID"] then
        local wlancfg = curdata["ID"]

        add_one_wlan_parameter(paras, wlancfg.."RegulatoryDomain", curdata["country"])
        add_one_wlan_parameter(paras, wlancfg.."TransmitPower", curdata["power"])
        add_one_wlan_parameter(paras, wlancfg.."X_WlanIsolateControl", curdata["isolate"])
        add_one_wlan_parameter(paras, wlancfg.."SSIDAdvertisementEnabled", curdata["advertisement"])
        add_one_wlan_parameter(paras, wlancfg.."X_WlanStandard", curdata["mode"])
        if "b/g/n" == curdata["mode"] or "a/n/ac" == curdata["mode"] or "a/n" == curdata["mode"] then
            if "auto" == curdata["nmcs"] then
                add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NHtMcs", 33)
            else
                add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NHtMcs", curdata["nmcs"])
            end
            add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NGIControl", curdata["ngi"])
            if curdata["nbw"] == "20_40"  then
                add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NBWControl", "20/40")
            else
                add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NBWControl", curdata["nbw"])
            end
                add_one_wlan_parameter(paras, wlancfg.."MaxBitRate", "Auto")
        else
            if "0" == curdata["rate"] then
                add_one_wlan_parameter(paras, wlancfg.."MaxBitRate", "Auto")
            else
                add_one_wlan_parameter(paras, wlancfg.."MaxBitRate", curdata["rate"])
            end
            add_one_wlan_parameter(paras, wlancfg.."X_Wlan11NHtMcs", 33)
        end
        add_one_wlan_parameter(paras, wlancfg.."WMMEnable", curdata["wmm"])
        if curdata["channel"] == 0 then
            add_one_wlan_parameter(paras, wlancfg.."AutoChannelEnable", 1)
            if 0 == is5g then
                add_one_wlan_parameter(paras, wlancfg.."Channel", 6)
            else
                if curdata["country"] == "JP" then
                    add_one_wlan_parameter(paras, wlancfg.."Channel", 36)
                else
                    if curdata["country"] == "CN" then
                        add_one_wlan_parameter(paras, wlancfg.."Channel", 157)
                    else
                        if curdata["country"] == "US" or curdata["country"] == "CA" or curdata["country"] == "MX" then
                            add_one_wlan_parameter(paras, wlancfg.."Channel", 48)
                        else
                            add_one_wlan_parameter(paras, wlancfg.."Channel", 100)
                        end
                    end
                end
            end    
        else
            add_one_wlan_parameter(paras, wlancfg.."AutoChannelEnable", 0)
            add_one_wlan_parameter(paras, wlancfg.."Channel", curdata["channel"])
        end
    end
end

local errcode,wifiConf = dm.GetParameterValues("InternetGatewayDevice.X_WiFi.Radio.{i}.",
{
    "OperatingFrequencyBand"
}
);

local paras = {}

if action == "BasicSettings" then
    for k, v in pairs(wifiConf) do
        if "2.4GHz" == v["OperatingFrequencyBand"] then
            curdata = data["config2g"]
            if curdata ~= nil then
                add_one_wlan_parameter(paras, k.."Enable", curdata["enable"])
            end
        else
            if "5GHz" == v["OperatingFrequencyBand"] then
                curdata = data["config5g"]
                if curdata ~= nil then
                    add_one_wlan_parameter(paras, k.."Enable", curdata["enable"])
                end
            end
        end
    end
end

if action == "SsidSettings" then
    curdata = data["config2g"]
    submit_ssidsetting_data(paras, curdata)
    curdata = data["config5g"]
    submit_ssidsetting_data(paras, curdata)
end

if action == "SendSettings" then
        curdata = data["config2g"]
        submit_sendsetting_data(paras, curdata, 0)
        curdata = data["config5g"]
        submit_sendsetting_data(paras, curdata, 1)
end


function submit_change_wpsstate(paras, curdata)
    if nil == curdata then
        return
    end
    if nil == curdata["ID"] then
        return 
    end    
    if 0 ~= curdata["ID"] then
        local wlancfg = curdata["ID"]
        if action == "SsidSettings" or action == "AllSsidSettings" then
            if curdata["beacontype"] == "Basic" or curdata["beacontype"] == "WPA" then
                add_one_wlan_parameter(paras, wlancfg.."WPS.Enable", false)
            end    
            if curdata["beacontype"] == "WPA-EAP" or curdata["beacontype"] == "WPAWPA2-EAP" or curdata["beacontype"] == "WPA2-EAP" or curdata["beacontype"] == "8021X" then
                add_one_wlan_parameter(paras, wlancfg.."WPS.Enable", false)
            end
            if curdata["beacontype"] == "11i" or curdata["beacontype"] == "WPAand11i" then
                if curdata["wpaencmode"] == "TKIP" then    
                    add_one_wlan_parameter(paras, wlancfg.."WPS.Enable", false)
                end
            end        
        end 
        if action == "SendSettings" then
            if curdata["advertisement"] == 0 then    
                add_one_wlan_parameter(paras, wlancfg.."WPS.Enable", false)
            end
        end  
    end    
end

curdata = data["config2g"]
if nil ~= curdata then 
    submit_change_wpsstate(paras, curdata)
end    
curdata = data["config5g"]
if nil ~= curdata then
    submit_change_wpsstate(paras, curdata)
end    

if "AllSsidSettings" == action then
    for k, v in pairs(data) do
        submit_ssidsetting_data(paras, v)
        submit_change_wpsstate(paras, v)
    end
end

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

if action == "SendSettings" then
    utils.responseErrorcode(errcode, paramerr, sendsetting_maps)
else
    utils.responseErrorcode(errcode, paramerr, maps)
end
