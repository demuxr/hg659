require('dm')
require('web')
require('json')
require('utils')

local tonumber = tonumber

local porttrigger = {}


local errcode, ipobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.X_PortTrigger.{i}.", 
    {"PortTriggerEnable", "TriggerPort", "TriggerPortEnd", "TriggerProtocol", "OpenPort", 
     "OpenPortEnd", "PortTriggerDescription"});

local errcode, pppobjs = dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.X_PortTrigger.{i}.", 
    {"PortTriggerEnable", "TriggerPort", "TriggerPortEnd", "TriggerProtocol", "OpenPort", 
     "OpenPortEnd", "PortTriggerDescription"});

for k,v in pairs(ipobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["PortTriggerEnable"] = utils.toboolean(v["PortTriggerEnable"])
    newObj["TriggerPort"] = v["TriggerPort"]
    newObj["TriggerPortEnd"] = v["TriggerPortEnd"]
    newObj["TriggerProtocol"] = v["TriggerProtocol"]
    newObj["OpenPort"] = v["OpenPort"]
    newObj["OpenPortEnd"] = v["OpenPortEnd"]
    newObj["PortTriggerDescription"] = v["PortTriggerDescription"]
    table.insert(porttrigger, newObj)
end

for k,v in pairs(pppobjs) do
    local newObj = {}
    newObj["ID"] = k
    newObj["PortTriggerEnable"] = utils.toboolean(v["PortTriggerEnable"])
    newObj["TriggerPort"] = v["TriggerPort"]
    newObj["TriggerPortEnd"] = v["TriggerPortEnd"]
    newObj["TriggerProtocol"] = v["TriggerProtocol"]
    newObj["OpenPort"] = v["OpenPort"]
    newObj["OpenPortEnd"] = v["OpenPortEnd"]
    newObj["PortTriggerDescription"] = v["PortTriggerDescription"]
    table.insert(porttrigger, newObj)
end

utils.multiObjSortByID(porttrigger)

web.print(json.encode(porttrigger))
