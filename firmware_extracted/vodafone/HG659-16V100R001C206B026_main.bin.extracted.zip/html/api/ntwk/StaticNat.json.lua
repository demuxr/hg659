require('dm')
require('web')
require('json')
require('utils')

local maps = {
	StaticNatHostMACAddress="StaticNatHostMACAddress",
	StaticNatEnable = "StaticNatEnable"
}

local domain = "InternetGatewayDevice.Services.X_StaticNat."

local errcode, values = dm.GetParameterValues(domain, maps)

local obj
if values ~= nil then
	obj = values[domain]
	obj.StaticNatEnable = utils.toboolean(obj.StaticNatEnable)
end

utils.responseSingleObject(obj, maps)