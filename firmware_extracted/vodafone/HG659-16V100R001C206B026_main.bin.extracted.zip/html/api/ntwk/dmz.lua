local utils = require('utils')

local maps = {
	HostIPAddress="DMZHostMACAddress",
	Enable = "DMZEnable"
}

local domain = "InternetGatewayDevice.Services.X_DMZ."

local param = utils.GenSetObjParamInputs(domain, data, maps)
local err,needreboot, paramerror = dm.SetParameterValues(param);

utils.responseErrorcode(err, paramerror, maps)
