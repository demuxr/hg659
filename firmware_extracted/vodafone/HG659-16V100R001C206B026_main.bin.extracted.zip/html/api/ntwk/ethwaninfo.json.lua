require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType"})

local ethWan = ""
for k,v in pairs(accessdevs) do
    if "Ethernet" == v["WANAccessType"] then
    	ethWan = k
    end
end

local info = {}
if "" == ethWan then
	web.print(json.encode(info))
	return
end

local start = string.find(ethWan, ".WANCommonInterfaceConfig.")
if start then
    ethWan = string.sub(ethWan, 0, start)
end

ethWan = ethWan.."WANEthernetInterfaceConfig."

local errcode,objs= dm.GetParameterValues(ethWan,
        {"Enable", "Status", "MaxBitRate", "DuplexMode"})

local obj=objs[ethWan]
info.Enable = obj["Enable"]
info.Status = obj["Status"]
info.MaxBitRate = obj["MaxBitRate"]
info.DuplexMode = obj["DuplexMode"]

web.print(json.encode(info))
