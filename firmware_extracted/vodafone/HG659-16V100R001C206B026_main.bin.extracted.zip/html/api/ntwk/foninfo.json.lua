require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_Fon.",
    {
        "SSID"
    }
);

local obj = values["InternetGatewayDevice.Services.X_Fon."]
local foninfo = {}
foninfo.FonSsid = obj["SSID"]
web.print(json.encode(foninfo))