require('dm')
require('utils')

local maps = {
	BytesSent="BytesSent",
	BytesReceived = "BytesReceived",
	PacketsSent = "PacketsSent",
	PacketsReceived = "PacketsReceived"
}

local errcode,values = dm.GetParameterValues("InternetGatewayDevice.WANDevice.4.X_WANUMTSInterfaceConfig.Stats.", maps)
local obj = values["InternetGatewayDevice.WANDevice.4.X_WANUMTSInterfaceConfig.Stats."]

local umts = web.gmsgget('wanumtscms', 1, {})
obj.DownstreamRate = umts.DownstreamRate
obj.UpstreamRate = umts.UpstreamRate
obj.HasDatacard  = utils.has_datacard()
local maps = {
	BytesSent="BytesSent",
	BytesReceived = "BytesReceived",
	PacketsSent = "PacketsSent",
	PacketsReceived = "PacketsReceived",
	UpstreamRate = "UpstreamRate",
	DownstreamRate = "DownstreamRate",
	HasDatacard    = "HasDatacard"
}
utils.responseSingleObject(obj, maps)