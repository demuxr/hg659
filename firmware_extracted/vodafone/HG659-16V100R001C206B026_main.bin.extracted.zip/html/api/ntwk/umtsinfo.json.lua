require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,accessdevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType"})

local umtsWan = ""
for k,v in pairs(accessdevs) do
    if "UMTS" == v["WANAccessType"] then
    	umtsWan = k
    end
end

local info = {}
if "" == umtsWan then
	web.print(json.encode(info))
	return
end

local start = string.find(umtsWan, ".WANCommonInterfaceConfig.")
if start then
    umtsWan = string.sub(umtsWan, 0, start)
end

umtsWan = umtsWan.."X_WANUMTSInterfaceConfig."

local errcode,objs= dm.GetParameterValues(umtsWan,
        {"Enable", "Mode", "Order", "Band", "Roam",
         "Domain", "UpstreamMaxRate", "DownstreamMaxRate",
         "SignalQuality", "ServiceStatus", "ServiceDomain",
         "RoamStatus", "SystemMode", "SIMStatus", "SysSubMode","UpLoadData","DownLoadData","CurrentUpstreamRate","CurrentDownstreamRate"})

local obj=objs[umtsWan]
info.Enable = obj["Enable"]
info.Mode = obj["Mode"]
info.Order = obj["Order"]
info.Band = obj["Band"]
info.Roam = obj["Roam"]
info.Domain = obj["Domain"]
info.UpstreamMaxRate = obj["UpstreamMaxRate"]..'bps'
info.DownstreamMaxRate = obj["DownstreamMaxRate"]..'bps'
info.SignalQuality = obj["SignalQuality"]
info.ServiceStatus = obj["ServiceStatus"]
info.ServiceDomain = obj["ServiceDomain"]
info.RoamStatus = obj["RoamStatus"]
info.SystemMode = obj["SystemMode"]
info.SIMStatus = obj["SIMStatus"]
info.SysSubMode = obj["SysSubMode"]
info.UpLoadData = obj["UpLoadData"]
info.DownLoadData = obj["DownLoadData"]
info.CurrentUpstreamRate = obj["CurrentUpstreamRate"]
info.CurrentDownstreamRate = obj["CurrentDownstreamRate"]
info.HasDatacard = utils.has_datacard()

web.print(json.encode(info))
