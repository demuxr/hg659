local utils = require('utils')

--local data = utils.getRequestFormData()

local maps = {
    RouterAdvertisementEnable ="RouterAdvertisementEnable",
    UseAllocatedWAN = "UseAllocatedWAN",
    ULAAllocatedMode = "ULAAllocatedMode",
    Prefix = "Prefix",
    PrefixLength = "PrefixLength",
    Preferredlifetime = "Preferredlifetime",
    Validlifetime = "Validlifetime",
    MOFlagAutoMode = "MOFlagAutoMode",
    ULAPrefix = "ULAPrefix",
    ULAPrefixLength = "ULAPrefixLength",
    ULAPreferredlifetime = "ULAPreferredlifetime",
    ULAValidlifetime = "ULAValidlifetime",
    OtherConfigFlag = "OtherConfigFlag",
    ManagedFlag = "ManagedFlag"
}

function add_one_lan_radvd_parameter(paras, name, value)
    table.insert(paras, {name, value})
end

function build_lan_radvd_parameters()
    local paras = {}
    add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.RouterAdvertisementEnable", data["RouterAdvertisementEnable"])
    if true == data["RouterAdvertisementEnable"] then
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.UseAllocatedWAN", data["UseAllocatedWAN"])
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ULAAllocatedMode", data["ULAAllocatedMode"])
    end 

    if true == data["RouterAdvertisementEnable"] and "Normal" == data["UseAllocatedWAN"] then
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.Prefix", data["Prefix"])   
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.PrefixLength", data["PrefixLength"])   
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.Preferredlifetime", data["Preferredlifetime"])   
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.Validlifetime", data["Validlifetime"])   
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.MOFlagAutoMode", data["MOFlagAutoMode"])   
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ManagedFlag", data["ManagedFlag"])  
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.OtherConfigFlag", data["OtherConfigFlag"])  
    end
    if true == data["RouterAdvertisementEnable"] and "Manual" == data["ULAAllocatedMode"] then
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ULAPrefix", data["ULAPrefix"])
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ULAPrefixLength", data["ULAPrefixLength"])  
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ULAPreferredlifetime", data["ULAPreferredlifetime"])  
        add_one_lan_radvd_parameter(paras, "InternetGatewayDevice.LANDevice.1.LANHostConfigManagement.X_SLAAC.ULAValidlifetime", data["ULAValidlifetime"])     
    end     
    return paras    
 end

local paras = build_lan_radvd_parameters()

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
