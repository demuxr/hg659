require('dm')
require('json')
require('utils')

local tostring = tostring
local errcode,values = dm.GetParameterValues("InternetGatewayDevice.Services.X_ALGAbility.", 
    {"PPTPEnable", "H323Enable", "RTSPEnable","SIPEnable","SIPPort","SIPWanPath"
    });

local obj = values["InternetGatewayDevice.Services.X_ALGAbility."]

local alg = {}
alg.PPTPEnable = utils.toboolean(obj["PPTPEnable"])
alg.H323Enable = utils.toboolean(obj["H323Enable"])
alg.RTSPEnable = utils.toboolean(obj["RTSPEnable"])
alg.SIPEnable  = utils.toboolean(obj["SIPEnable"])
alg.SIPPort = obj["SIPPort"]
alg.SIPWan = obj["SIPWanPath"]

web.print(json.encode(alg)) 
