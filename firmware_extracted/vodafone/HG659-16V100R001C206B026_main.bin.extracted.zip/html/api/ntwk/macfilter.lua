local utils = require('utils')
require('dm')
local string = string

local maps = {
	RuleName="Name",
	Enable = "Enable",
	TimeMode = "TimeMode",
	Devices = "DevMac",
	WeekTimeStart = "WeekTimeStart",
	WeekTimeEnd = "WeekTimeEnd"
}

function GetMacAddress()
	local mac = ''
	for k,v in pairs(data["Devices"]) do
		for k1, value in pairs(v) do
			if value ~= "" then
				mac = mac..value..'|'
			end
		end
	end
	return string.sub(mac, 1, string.len(mac)-1)
end

local weekday = {
	[0]="Daily", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
}

function createtime()
	if tonumber(data["TimeMode"]) == 0 then
		data["TimeMode"] = 0
		data["WeekTimeStart"] = data["DailyFrom"]
		data["WeekTimeEnd"] = data["DailyTo"]
	else
		data["TimeMode"] = 1
		data["WeekTimeStart"] = data["MondayFrom"]
		data["WeekTimeEnd"] = data["MondayTo"]
		for i=2, 7 do
			data["WeekTimeStart"] = data["WeekTimeStart"].."|"..data[weekday[i]..'From']
			data["WeekTimeEnd"] = data["WeekTimeEnd"].."|"..data[weekday[i]..'To']
		end
	end
end

function create()
	-- add 
	data["Devices"] = GetMacAddress()
	data["Enable"] = utils.booleantoint(data["Enable"])
	createtime()

	local paras = utils.GenAddObjParamInputs(data, maps)
	local errcode, instnum, NeedReboot, paramerr= dm.AddObjectWithValues("InternetGatewayDevice.X_FireWall.TimeRule.", paras);
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

function delete()
	return dm.DeleteObject(data["ID"])
end

function update()
	local domain = data["ID"]

	data["Devices"] = GetMacAddress()
	data["Enable"] = utils.booleantoint(data["Enable"])
	createtime()

	local paras = utils.GenSetObjParamInputs(domain, data, maps)

	local errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)
	utils.responseErrorcode(errcode, paramerr, maps)

	return errcode
end

if action == 'create' then
	err = create()
elseif action == 'update' then
	err = update()
elseif action == 'delete' then
	err = delete()
else
	return
end

utils.appenderror("errcode", err)

