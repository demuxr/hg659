require('dm')
require('web')
require('json')
require('utils')
local tostring = tostring
local errcode,wanconndevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.",
        {"WANPPPConnectionNumberOfEntries"})
local errcode,wandevs= dm.GetParameterValues("InternetGatewayDevice.WANDevice.{i}.WANCommonInterfaceConfig.",
        {"WANAccessType"})
local errcode,vlans = dm.GetParameterValues("InternetGatewayDevice.X_VLANTermination.{i}.", 
            {"LowerLayers", "VLANID", "802-1pMark"});

function get_access_type_by_wanconndev(wanconndev, wandevs)
    local start = string.find(wanconndev, ".WANConnectionDevice.")
    local wandev = string.sub(wanconndev, 1, start)
    wandev = wandev.."WANCommonInterfaceConfig."
    for k,v in pairs(wandevs) do
        if wandev == k then
            return v["WANAccessType"]
        end
    end
    return ""
end

function get_wandev_by_link_intf(intf)
    local start = string.find(intf, ".WANCommonInterfaceConfig.")
    return string.sub(intf, 1, start)
end

function get_dsl_params_by_wanconndev(wanconndev, link, accesstype)
    local getValues = nil;
    local linkconfig = ""
    if "DSL" == accesstype then
        local errcode
        linkconfig = get_wandev_by_link_intf(wanconndev).."WANDSLLinkConfig."
        errcode,getValues= dm.GetParameterValues(linkconfig,
        {"LinkType", "DestinationAddress", "ATMQoS", "ATMPeakCellRate",
         "ATMSustainableCellRate", "ATMMaximumBurstSize", "ATMEncapsulation"})
    end
    link.AccessType = accesstype
    if nil == getValues then
        link.PVC = ""
        link.LinkType = "EoA"
        link.EncapMode = "LLC"
        link.AtmQoS = "UBR"
        link.PeakRate = 0
        link.SupportRate = 0
        link.MaxBurstRate = 0
        return
    end
    local obj = getValues[linkconfig]
    link.PVC = obj["DestinationAddress"]
    link.LinkType = obj["LinkType"]
    link.EncapMode = obj["ATMEncapsulation"]
    link.AtmQoS = obj["ATMQoS"]
    link.PeakRate = obj["ATMPeakCellRate"]
    link.SupportRate = obj["ATMSustainableCellRate"]
    link.MaxBurstRate = obj["ATMMaximumBurstSize"]
end

local links = {}
for k,v in pairs(wanconndevs) do
    local link = {}
    link.LowerLayer = ""
    link.ID = k
    get_dsl_params_by_wanconndev(k, link, get_access_type_by_wanconndev(k, wandevs))
    link.Name = ""
    link.VLANEnable = false
    link.VLANId = 1
    link.VLAN1p = 0
    table.insert(links, link)
end

for k,v in pairs(vlans) do
    local link = {}
    link.ID = k
    link.LowerLayer = v["LowerLayers"].."."
    get_dsl_params_by_wanconndev(link.LowerLayer, link, get_access_type_by_wanconndev(link.LowerLayer, wandevs))
    link.VLANEnable = true
    link.Name = ""
    link.VLANId = v["VLANID"]
    link.VLAN1p = v["802-1pMark"]
    table.insert(links, link)
end

web.print(json.encode(links))
