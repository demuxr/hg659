local utils = require('utils')

function add_one_wlan_parameter(paras, name, value)
	if nil == value then
		return 
	end
	table.insert(paras, {name, value})
end
local maps = {
}

local paras = {}

function submit_frequency_data(paras, data)
	if data == nil then
		return  
	end	
	if data["ID"] == nil then
		return  
	end	
	local wlan_str = data["ID"]
	add_one_wlan_parameter(paras, wlan_str.."Enable", data["Enable"])
	add_one_wlan_parameter(paras, wlan_str.."SSID", data["WifiSsid"])
	if "none" == data["SecOpt"] then
		add_one_wlan_parameter(paras, wlan_str.."BeaconType", "Basic")
		add_one_wlan_parameter(paras, wlan_str.."BasicEncryptionModes", "None")
		add_one_wlan_parameter(paras, wlan_str.."BasicAuthenticationMode", "None")
	end
	if "aes" == data["SecOpt"] then
		add_one_wlan_parameter(paras, wlan_str.."BeaconType", "11i")
		add_one_wlan_parameter(paras, wlan_str.."IEEE11iEncryptionModes", "AESEncryption")
		if _G["defaultPasswd"] ~= data["WpaPreSharedKey"] then
		    add_one_wlan_parameter(paras, wlan_str.."PreSharedKey.1.KeyPassphrase", data["WpaPreSharedKey"])
	        end
	end

	if "tkip" == data["SecOpt"] then
		add_one_wlan_parameter(paras, wlan_str.."BeaconType", "WPAand11i")
		add_one_wlan_parameter(paras, wlan_str.."X_MixedEncryptionModes", "TKIPandAESEncryption")
		if _G["defaultPasswd"] ~= data["WpaPreSharedKey"] then
		    add_one_wlan_parameter(paras, wlan_str.."PreSharedKey.1.KeyPassphrase", data["WpaPreSharedKey"])
		end
	end
end

submit_frequency_data(paras, data["config2g"])
submit_frequency_data(paras, data["config5g"])

local errcode = 0
errcode, NeedReboot, paramerr = dm.SetParameterValues(paras)

utils.responseErrorcode(errcode, paramerr, maps)
