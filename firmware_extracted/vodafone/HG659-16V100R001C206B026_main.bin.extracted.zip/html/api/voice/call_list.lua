local utils = require('utils')
require('web')

local log_type = 106496
if data == nil then
    utils.appenderror("errcode", err);
end
