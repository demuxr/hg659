require('dm')
require('web')
require('json')
require('utils')

local tostring = tostring

local debug_level = "Debug"
local voice_query_type = 106496
local loginfo = {}

local ret = web.getlogcontent(debug_level, voice_query_type, 0)

f = io.open("/var/logtemp", "r")
if f == nil then
    loginfo.LogContent = ""
    io.close()
else
    file = f:read("*a")
    loginfo.LogContent = string.gsub(file, "\r\n", "\n")
    f:close()
    os.remove("/var/logtemp")
end

web.print(json.encode(loginfo))
