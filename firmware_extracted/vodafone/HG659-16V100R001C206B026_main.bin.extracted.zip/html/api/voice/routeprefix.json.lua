local dm  = require('dm')
local web = require('web')
local json = require('json')
local GetParameterValues = dm.GetParameterValues
			
local Prefixdata = {}
local errcode,prefixlist = GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.RouteprefixInfo.{i}.",{"PrefixRange","Account","Description","OutgoingRoute"});
if prefixlist ~= nil then
	for k,v in pairs(prefixlist) do
		local prefixitem = {}
		prefixitem["ID"] = k
		if v["PrefixRange"]~= "" then
			prefixitem["Prefix"] =string.sub(v["PrefixRange"], 3, -1) 
		else
			prefixitem["Prefix"] = ""
		end
		if v["OutgoingRoute"] == 2 then
			prefixitem["PrefixNumber"] = "CS"
		else
			prefixitem["PrefixNumber"] = v["Account"]
		end
		prefixitem["PrefixDescription"] = v["Description"]
		table.insert(Prefixdata,prefixitem)
	end 
end
web.print(json.encode(Prefixdata))
