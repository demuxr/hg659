require('dm')
require('web')
require('json')

local ID = nil

local voice_number = {}
if FormData["ID"] ~= nil then
    ID = FormData["ID"]
end

if ID == nil then
    web.print(json.encode(voice_number))
    return 
end


local numbertems = {}
local maxinstid = 0
local stc = 0

local err, Commonvalues = dm.GetParameterValues("InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig.", {"X_STC"})
if Commonvalues ~= nil then
    local  Common_obj = Commonvalues["InternetGatewayDevice.Services.VoiceService.1.X_CommonConfig."]
    stc = Common_obj["X_STC"]
end

if stc == 1 then
    local SipNum_obj = {}
    SipNum_obj.ID = "0"
    SipNum_obj.Head = true
    SipNum_obj.Status = "Status"
    SipNum_obj.Number = "Number"
    SipNum_obj.LineSeq = 0
    SipNum_obj.MaxInstId = 0
    SipNum_obj.Enable = true
    SipNum_obj.Username = "UserName"
    SipNum_obj.Password = ""

    table.insert(numbertems, SipNum_obj)
end

local errcode, line_values = dm.GetParameterValues(ID.."Line.{i}.", {"Status", "DirectoryNumber", "X_LineSeq", "Enable"});
if nil ~= line_values then
    for kk, vv in pairs(line_values) do
        local SipNum_obj = {}
	local words = {}
        SipNum_obj.ID = kk
        if stc == 1 then
	        SipNum_obj.Head = false
	    end
        SipNum_obj.Status = vv["Status"]
        SipNum_obj.Number = vv["DirectoryNumber"]
        SipNum_obj.LineSeq = vv["X_LineSeq"]

	for w in string.gfind(kk, "(%d+)") do
		table.insert(words, w)
	end
	if words[3] ~= nil then
		maxinstid = words[3]
	end
	SipNum_obj.MaxInstId = maxinstid
        if vv["Enable"] == "Enabled" then
            SipNum_obj.Enable = true
        else
            SipNum_obj.Enable = false
        end
        
        local errcode, each_line_sip = dm.GetParameterValues(kk.."SIP.", {"AuthUserName", "AuthPassword"});
        local each_line_sip_obj = each_line_sip[kk.."SIP."]
        SipNum_obj.Username = each_line_sip_obj["AuthUserName"]
        SipNum_obj.Password = utils.getdefaultPasswd(each_line_sip_obj['AuthPassword'])
        table.insert(numbertems, SipNum_obj)
    end
end
table.sort(numbertems, function (a, b) return a.LineSeq < b.LineSeq end)

web.print(json.encode(numbertems))
