require('web')
require('dm')
local utils = require('utils')

local voip_voipinfo_maps = {
	Number="DirectoryNumber",
	DTMFMode="X_DTMFMethod",
	CLIP="X_ClipEnable",
	FaxOption="X_FaxOption"
}

local voip_codec_maps = {
	Codec="Codec",
	Priority="Priority"
}

local setting_paras = utils.GenSetObjParamInputs(data["ID"], data, voip_voipinfo_maps)
local err,needreboot, paramerror = dm.SetParameterValues(setting_paras)

if err ~= 0 then
	utils.responseErrorcode(err, paramerror, voip_voipinfo_maps)
	return
end

local CoDecArray = utils.split(data["CoDecList"], ",")

for id1,Codec1 in pairs(CoDecArray) do
	for id2,Codec2 in pairs(CoDecArray) do
		if Codec1 == Codec2  and id1 ~= id2  and Codec1 ~= "NULL" then
			utils.appenderror("Priority", "advance.linecodecerr")
			utils.appenderror("errcode", 9003)
			return
		end
	end
end

--codec_obj��Codec��CoDecArray���Ҳ���˵���˱���뱻ȥʹ����
function setPriority(codec)
	for kk,vv in pairs(CoDecArray) do
		if vv == codec then
			return kk
		end
	end
	return 0
end

local codec_obj = data["Codec"]
local codecid = ""
local codeclistid = ""
for k,codecinfo in pairs(codec_obj) do
	codecid = codecinfo["ID"]
	codeclistid = string.sub(codecid, 1,-3)
	break
end
local bfind = 0
local err, codeclistvalues = dm.GetParameterValues(codeclistid.."{i}.", {"Codec"})
if codeclistvalues ~= nil then
	for id, codeclistInfo in pairs(codeclistvalues) do
		bfind = 0
		for id1,Codec1 in pairs(CoDecArray) do
			if codeclistInfo["Codec"] == Codec1 then
				bfind = 1
				setValues = 
				{
					{id.."Priority", id1 },
					{id.."Enable", "1"}
				}
				 err,needreboot, paramerror = dm.SetParameterValues( setValues )
				 utils.responseErrorcode(err, paramerror, voip_codec_maps)
				 break
			end
		end
		if bfind == 0 then
			local priority = 7
			for id1,Codec1 in pairs(CoDecArray) do
				if Codec1 == "NULL" then
					priority = id1
					CoDecArray[id1] = ""
					break
				end
			end
			setValues = 
			{
				{id.."Priority", priority },
				{id.."Enable", "0"}
			}
			 err,needreboot, paramerror = dm.SetParameterValues( setValues )
			 utils.responseErrorcode(err, paramerror, voip_codec_maps)
		end
	end
end
--[[
for k,codecinfo in pairs(codec_obj) do

	local priorityorder = setPriority(codecinfo["Codec"])
	if priorityorder ~= 0 then
		codecinfo["Priority"] = priorityorder
	else
		utils.responseErrorcode(400, paramerror, voip_codec_maps)
		return
	end
	local setting = utils.GenSetObjParamInputs(codecinfo["ID"], codecinfo, voip_codec_maps)
	local err,needreboot, paramerror = dm.SetParameterValues(setting)
	if err ~= 0 then
		print(err)
		utils.responseErrorcode(err, paramerror, voip_codec_maps)
		return
	else
		print("Codec item set ok")
	end
end
--]]
utils.responseErrorcode(0, paramerror, voip_codec_maps)
