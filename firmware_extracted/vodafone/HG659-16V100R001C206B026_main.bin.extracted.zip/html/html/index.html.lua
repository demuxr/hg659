 web.print('<!DOCTYPE html>\r\
<!--[if lt IE 7 ]><html lang="en" class="ie6"><![endif]-->\r\
<!--[if IE 7 ]><html lang="en" class="ie7"><![endif]-->\r\
<!--[if IE 8 ]><html lang="en" class="ie8"><![endif]-->\r\
<!--[if IE 9 ]><html lang="en" class="ie9"><![endif]-->\r\
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->\r\
<head>\r\
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\
<meta name="viewport" content="width=device-width, initial-scale=1.0">\r\
<meta name="description" content="">\r\
<meta name="author" content="">\r\
');  html.csrf_meta_tag()  web.print('\r\
<title>Vodafone Home Gateway HG659</title>\r\
');  html.link('/css/cat_public.css')  html.link('/css/login.css')  web.print('\r\
<!--[if lt IE 9]>\r\
');  html.rawscript('/js/html5.js')  web.print('\r\
<![endif]-->\r\
<!--[if lt IE 7]>\r\
');  html.rawscript('/lib/DD_belatedPNG_0.0.8a-min.js')  web.print('\r\
<![endif]-->\r\
<script language="JavaScript" type="text/javascript">\r\
'); web.print('var g_Lang = new Array();\r\
g_Lang[0] = {lang:"en", title:"English"};\r\
'); web.print('\r\
'); web.print('var g_Menus = [{"ID":"home", "Page":"/html/wizard/wizard.html", "Children":[{"ID":"internet_wizard", "Page":"/html/wizard/wizard.html", "show":true}]},{"ID":"internet_settings", "Page":"/html/advance.html", "Children":[{"ID":"internet", "Page":"/html/wan_setup_view.js", "show":true},{"ID":"parent_control", "Page":"/html/parent_control_view.js", "show":true},{"ID":"network_security", "Page":"/html/network_security_view.js", "show":true},{"ID":"qos", "Page":"/html/qos_view.js", "show":true},{"ID":"Network_services", "Page":"/html/network_service_view.js", "show":true},{"ID":"vpn", "Page":"/html/vpn_view.js", "show":true},{"ID":"nat", "Page":"/html/nat_view.js", "show":true},{"ID":"route", "Page":"/html/route_view.js", "show":true}]},{"ID":"homenetwork_settings", "Page":"/html/advance.html", "Children":[{"ID":"landevices", "Page":"/html/landevices_view.js", "show":true},{"ID":"lan", "Page":"/html/lan_setup_view.js", "show":true},{"ID":"wlan", "Page":"/html/wlan_setup_view.js", "show":true},{"ID":"wlan_access", "Page":"/html/wlan_access_view.js", "show":true},{"ID":"guest_network", "Page":"/html/guest_network_view.js", "show":true}]},{"ID":"sharing_settings", "Page":"/html/advance.html", "Children":[{"ID":"file_services", "Page":"/html/file_services_view.js", "show":true},{"ID":"dlna_sharing", "Page":"/html/dms_view.js", "show":true}]},{"ID":"telephone_settings", "Page":"/html/advance.html", "Children":[{"ID":"voip_provider", "Page":"/html/voip_provider_view.js", "show":true},{"ID":"fxsphone", "Page":"/html/fxsphone_view.js", "show":true},{"ID":"voipinfo", "Page":"/html/voipinfo_view.js", "show":true},{"ID":"call_list", "Page":"/html/call_list_view.js", "show":true},{"ID":"dail_plan", "Page":"/html/dial_plan_view.js", "show":true},{"ID":"voice_advalced", "Page":"/html/voip_advanced_view.js", "show":true}]},{"ID":"maintain_settings", "Page":"/html/advance.html", "Children":[{"ID":"device_info", "Page":"/html/device_info_view.js", "show":true},{"ID":"user_account", "Page":"/html/user_account_view.js", "show":true},{"ID":"device_mngt", "Page":"/html/device_mngt_view.js", "show":true},{"ID":"log", "Page":"/html/log_view.js", "show":true},{"ID":"diagnose_overview", "Page":"/html/diagnose_overview_view.js", "show":true},{"ID":"diagnose_tools", "Page":"/html/diagnose_view.js", "show":true},{"ID":"tr069", "Page":"/html/cwmp_view.js", "show":true},{"ID":"statistics", "Page":"/html/homenetwork_info_view.js", "show":true}]}];'); web.print('\r\
</script>\r\
</head>\r\
<body data-spy="scroll" data-target=".bs-docs-sidebar">\r\
<!-- Navbar======================top menu============================ -->\r\
<div class="navbar navbar-fixed-top">\r\
    <div class="container top_div">\r\
        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" style="margin-top:17px;">\r\
            <span class="icon-bar"></span>\r\
            <span class="icon-bar"></span>\r\
            <span class="icon-bar"></span>\r\
        </a>\r\
        <ul class="nav pull-left logo_png">\r\
            <li class="pull-left"><div id="huaweilogo" class="ic-logo ie6image"></div></li>\r\
            <li id="width_product_title" class="pull-left product_title">Vodafone Home Gateway</li>\r\
        </ul>\r\
        <div id="lang"></div>\r\
    </div><!--/.container-->\r\
    <!--here for top menu-->\r\
    <div class="container shadow height_52 top_menu_back_img" id="menu_test">\r\
    </div>\r\
    <!--here for hide menu-->\r\
    <div class="hide min_height_52 width_100p top_menu_back_img" id="menu_for_hide">\r\
    </div>\r\
</div>\r\
<!--body-->\r\
<div id="content">\r\
    <div class="main-container">\r\
        <div class="container">\r\
            <div class="row-fluid">\r\
                <div class="setconfig_height rounddiv_index paddingbottom_10" align="center">\r\
                    <div class="width_100p height_120 index_login_top_back rounddiv_index_top">&nbsp;</div>\r\
                    <div id="login_window" class="width_500 min_height_300 margintop_n50 index_page_us_ps_div rounddiv"></div>\r\
                    <div id="gate_info" class="accordion width_500 margintop_30 marginbottom_15 rounddiv"></div>\r\
                </div>\r\
                <!--output window-->\r\
                <div id="firstTimeLogin"></div>\r\
                <div id="loginblank" class="loginshadow hide"></div>\r\
            </div>\r\
        </div>\r\
    </div>\r\
</div>\r\
<!-- Footer================================================= -->\r\
<div class="navbar navbar-fixed-bottom">\r\
        <footer>\r\
        <div id="foot">\r\
        <script type="text/x-handlebars" data-template-name="foot">\r\
           {{view Atp.footerview}}\r\
        </script>\r\
        </div>\r\
        </footer>\r\
</div>\r\
<script language="JavaScript" type="text/javascript">\r\
var g_userLevel = ');  local name,level = web.getuserinfo(); if level ~= nil then web.print(level) else web.print('0') end   web.print(';\r\
var g_userLang = "');  web.print(web.lang())    web.print('";\r\
</script>\r\
<script type="text/x-handlebars" data-template-name="lang">\r\
    <div class="nav-collapse collapse paddingtop_10">\r\
        {{view  Atp.ProductDividerLineView}}\r\
        <ul class="nav pull-right">\r\
                {{view Atp.LanguageBlock}}\r\
            <li class="marginright_5 text_center paddingleft_10">&nbsp;</li>\r\
        </ul>\r\
    </div>\r\
</script>\r\
\r\
<!--load needed js and css files-->\r\
');  html.gzrawscript('/lib/cat_liblayout.js')  web.print('\r\
');  html.rawlang('menu_res.js')  web.print('\r\
\r\
');  html.gzrawscript('/lib/cat_exember.js')  web.print('\r\
');  html.gzrawscript('/lib/cat_enc.js')  web.print('\r\
');  html.lang('device_info_res.js')  web.print('\r\
');  html.lang('user_login_res.js')  web.print('\r\
');  html.lang('wizard_res.js')  web.print('\r\
');  html.script('/lib/base64.js')  web.print('\r\
');  html.script('/js/user_login.js')  web.print('\r\
\r\
');  html.scriptall()  web.print('\r\
<script type="text/javascript">\r\
function loginWindowWidth(){\r\
    var wwidth = $(window).width();\r\
    if (wwidth < 544) {\r\
        $("#login_window").removeClass("width_500");\r\
        $("#login_window").addClass("width_100p");\r\
        $("#gate_info").removeClass("width_500");\r\
        $("#gate_info").addClass("width_100p");\r\
        $("#input_username_pass").removeClass("width_400");\r\
        $("#input_username_pass").addClass("width_100p");\r\
    }\r\
    else {\r\
        $("#login_window").removeClass("width_100p");\r\
        $("#login_window").addClass("width_500");\r\
        $("#gate_info").removeClass("width_100p");\r\
        $("#gate_info").addClass("width_500");\r\
        $("#input_username_pass").removeClass("width_100p");\r\
        $("#input_username_pass").addClass("width_400");\r\
    }\r\
}\r\
\r\
$(document).ready(function() {\r\
    if (g_userLevel > 0){\r\
        Atp.LoginOutController.postData();\r\
    }\r\
    // Load menu\r\
    load_sysmenu();\r\
    if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {}\r\
    else {\r\
        setInterval("loginWindowWidth()",50);\r\
    }\r\
    utilLoadJavascript("/js/device_info.js", true);\r\
    utilLoadJavascript("/js/wizard.js");\r\
});\r\
</script>\r\
</body>\r\
</html>\r\
'); 