Atp.LoadHelper.appendLangRes("call_list_res.js");
Atp.LoadHelper.appendJs("/js/call_list.js");

Atp.LoadHelper.loadAll();

Atp.CallListContainerView = Atp.PageContainerView.extend ({
    prefixName: 'CallList',
    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.CallListView }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.CallListContainerView, "call_list");