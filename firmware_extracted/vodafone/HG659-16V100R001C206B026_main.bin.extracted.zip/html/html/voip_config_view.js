Atp.LoadHelper.appendLangRes('voip_config_res.js');

utilLoadJavascript('/lib/jquery.form.min.js');
Atp.LoadHelper.appendJs('/js/voip_config.js');

Atp.LoadHelper.loadAll();

Atp.VoiceMngtContainerView = Atp.PageContainerView.extend ({
    prefixName: 'vcecfg',

    dataView: Em.View.extend ({
        template: Em.Handlebars.compile(' \
            {{ view Atp.VoiceConfigFileView }} \
            {{ view Atp.ModalView controllerBinding="Atp.VoiceMngtModalController" }} \
        ')
    })
});

Atp.MenuController.createSubmenuView(Atp.VoiceMngtContainerView, "voip_config");